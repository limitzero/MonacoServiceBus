﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Monaco.Messages.For.Timeouts;

namespace Monaco.Sagas
{
    /// <summary>
    /// Base implementation of a long-running process.
    /// </summary>
    [Serializable]
    public abstract class Saga : ISaga
    {
        [XmlIgnore]
        public IServiceBus Bus { get; set; }

		[XmlIgnore]
		public IDictionary<Type,  Func<IMessage, bool>> Correlations { get; private set; }

    	/// <summary>
    	/// Gets or sets the instance identifier for the saga instance.
    	/// </summary>
    	public Guid InstanceId { get; set; }

    	/// <summary>
    	/// Gets or sets the flag to indicate whether or not the process has completed.
    	/// </summary>
    	public bool IsCompleted { get; set; }

		protected  Saga()
		{
			this.Correlations = new Dictionary<Type, Func<IMessage, bool>>();
		}

    	/// <summary>
		/// This will mark the saga as "completed" and signal the removal of the instance
		/// from the persistance store.
		/// </summary>
        public void MarkAsCompleted()
        {
            IsCompleted = true;
        }

		/// <summary>
		/// This will delay the delivery of a given message for a specified interval.
		/// </summary>
		/// <param name="message">Message to deliver</param>
		/// <param name="delay">Time to wait before delivery</param>
		public void DelayDelivery(IMessage message, TimeSpan delay)
		{
			var scheduledTimeout = new ScheduleTimeout {Duration = delay, MessageToDeliver = message};
			Bus.Send(scheduledTimeout);
		}

    	/// <summary>
		/// This will create an expression used to correlate a message to the saga instance.
		/// </summary>
		/// <typeparam name="TMessage">Current message type to correlate</typeparam>
		/// <param name="correlation">Expression used to determine if the message can be correlated.</param>
		public void Correlate<TMessage>(Func<TMessage, bool> correlation)
		{
			this.Correlations.Add(typeof(TMessage),
				theCorrelation => correlation((TMessage)theCorrelation));
		}
    }

    /// <summary>
    /// Base implementation of a long-running process with a defined persisted 
    /// data entity for keeping data between long-running process calls.
    /// </summary>
    /// <typeparam name="TDATA">Type of the data to keep persisted between calls.</typeparam>
    [Serializable]
    public abstract class Saga<TDATA> : Saga, ISaga<TDATA> where TDATA : class, ISagaData, new()
    {
    	/// <summary>
		/// Gets or sets the data associated with the saga.
		/// </summary>
        public TDATA Data { get; set; }

    }
}