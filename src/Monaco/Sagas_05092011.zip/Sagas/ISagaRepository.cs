using System;

namespace Monaco.Sagas
{
    /// <summary>
    /// Contract for retrieving and saving saga instances to the persistance store.
    /// </summary>
    public interface ISagaRepository
    {
        ISaga Find(Guid instanceId);
        void Save(ISaga saga);
        void Remove(Guid instanceId);
    }
}