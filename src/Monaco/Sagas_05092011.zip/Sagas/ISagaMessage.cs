using System;

namespace Monaco.Sagas
{
	/// <summary>
	/// Contract for a message that will be participating in long running processes.
	/// </summary>
	public interface ISagaMessage : IMessage
	{
		/// <summary>
		/// Gets or sets the correlation id which corresponds to 
		///  the <seealso cref="ISaga.InstanceId">identifier of an active instance of a saga</seealso>
		///  if the message is participating in an on-going process. 
		/// </summary>
		Guid CorrelationId { get; set; }
	}
}