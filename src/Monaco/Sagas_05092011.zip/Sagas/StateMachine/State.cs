﻿using System;

namespace Monaco.Sagas.StateMachine
{
	/// <summary>
	/// Abstract class that represents a state in the saga where it is reflecting the occurence of an event (i.e. message receipt and processing). 
	/// All state declarations must be a simple class with no defined properties or behavior.
	/// 
	/// </summary>
	[Serializable]
	public abstract class State
	{
	}
}