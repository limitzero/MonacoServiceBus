﻿using System;
using System.Collections.Generic;
using Monaco.Messages.For.Timeouts;

namespace Monaco.Sagas.StateMachine
{
	public class SagaEventTriggerCondition 
	{
		private readonly SagaStateMachine _sagaStateMachine;

		/// <summary>
		/// Gets the set of message actions that will be taken by the state machine.
		/// </summary>
		public ICollection<MessageAction> MessageActions { get; private set; }

		/// <summary>
		/// Gets or sets the state that the saga instance has transitioned into.
		/// </summary>
		public State State { get; set; }

		public SagaEventTriggerCondition(SagaStateMachine sagaStateMachine, IMessage message, Action when)
		{
			_sagaStateMachine = sagaStateMachine;
			this.MessageActions = new List<MessageAction>();
			this.CreateSagaAction(SagaMessageActionType.When, message, when);
		}

		/// <summary>
		/// This will signal that the saga state machine can execute some custom code after a message 
		/// is received.
		/// </summary>
		/// <param name="action">Custom code to execute</param>
		/// <returns></returns>
		public SagaEventTriggerCondition Do(Action action)
		{
			this.CreateSagaAction(SagaMessageActionType.Do, null, action);
			return this;
		}

		/// <summary>
		/// This will signal that the saga instance will publish a message to one or more message consumers.
		/// </summary>
		/// <typeparam name="TMessage">Concrete type of the message to publish</typeparam>
		/// <param name="publish">Function to create the message to publish</param>
		/// <returns></returns>
		public SagaEventTriggerCondition Publish<TMessage>(Func<TMessage, TMessage> publish)
			where TMessage : IMessage, new()
		{
			var message = publish(new TMessage());
			this.CreateSagaAction(SagaMessageActionType.Publish, message,
			                      () => this._sagaStateMachine.Bus.Publish(message));
			return this;
		}

		/// <summary>
		/// This will signal that the saga instance will send a message to a consumer on the local bus 
		/// instance.
		/// </summary>
		/// <typeparam name="TMessage">Concrete type of the message to send</typeparam>
		/// <param name="send">Function to create the message to send</param>
		/// <returns></returns>
		public SagaEventTriggerCondition Send<TMessage>(Func<TMessage, TMessage> send)
			where TMessage : IMessage, new()
		{
			var message = send(new TMessage());
			this.CreateSagaAction(SagaMessageActionType.Send, message,
			                      () => this._sagaStateMachine.Bus.Send(message));
			return this;
		}

		/// <summary>
		/// This will signal that the saga instance will send a message to a consumer on the local bus 
		/// instance.
		/// </summary>
		/// <typeparam name="TMessage">Concrete type of the message to send</typeparam>
		/// <param name="endpoint">The uri semantic for a location that will process the message</param>
		/// <param name="send">Function to create the message to send</param>
		/// <returns></returns>
		public SagaEventTriggerCondition SendToEndpoint<TMessage>(Uri endpoint,
		                                                          Func<TMessage, TMessage> send)
			where TMessage : IMessage, new()
		{
			var message = send(new TMessage());

			var messageAction = new MessageAction(SagaMessageActionType.SendToEndpoint,
			                                      message, () => this._sagaStateMachine.Bus.Send(endpoint, message));
			messageAction.Endpoint = endpoint.OriginalString;

			this.MessageActions.Add(messageAction);

			return this;
		}

		/// <summary>
		/// This will signal that the saga instance will send a reply for the current message being 
		/// processed.
		/// </summary>
		/// <typeparam name="TMessage">Type of the message representing the reply</typeparam>
		/// <param name="reply">Function to return the new reply message</param>
		/// <returns></returns>
		public SagaEventTriggerCondition Reply<TMessage>(Func<TMessage, TMessage> reply)
			where TMessage : IMessage, new()
		{
			var message = reply(new TMessage());
			this.CreateSagaAction(SagaMessageActionType.Reply, message,
			                      () => this._sagaStateMachine.Bus.Reply(message));
			return this;
		}

		/// <summary>
		/// This will signal that a message will be delayed for publication after a given interval.
		/// </summary>
		/// <typeparam name="TMessage">Concrete message to schedule for delayed delivery</typeparam>
		/// <param name="duration">Time to wait before delivery</param>
		/// <param name="delay">Function to create the message for delivery</param>
		/// <returns></returns>
		public SagaEventTriggerCondition Delay<TMessage>(TimeSpan duration, Func<TMessage, TMessage> delay)
			where TMessage : IMessage, new()
		{
			var message = delay(new TMessage());
			var timeout = new ScheduleTimeout(duration, message);

			var action = new MessageAction(SagaMessageActionType.Delay, message,
			                               () => this._sagaStateMachine.Bus.Send(timeout));
			action.Delay = duration;

			this.MessageActions.Add(action);

			return this;
		}

		/// <summary>
		/// This will signal for the current saga to complete its processing.
		/// </summary>
		/// <returns></returns>
		public SagaEventTriggerCondition Complete()
		{
			this.CreateSagaAction(SagaMessageActionType.Complete, null,
				() => _sagaStateMachine.MarkAsCompleted());
			return this;
		}

		/// <summary>
		/// This will signal that the current saga will transition to a pre-defined state and wait
		/// for a new event to be triggered for re-starting the processing
		/// </summary>
		/// <typeparam name="TState">The concrete state to set on the saga</typeparam>
		/// <returns></returns>
		public SagaEventTriggerCondition TransitionTo<TState>() where TState : State, new()
		{
			this.State = new TState();
			this.CreateSagaAction(SagaMessageActionType.Transition, null,
				() => { this._sagaStateMachine.CurrentState = this.State; }, this.State);
			return this;
		}

		private void CreateSagaAction(SagaMessageActionType sagaActionType, 
		                              IMessage message, Action action, State state = null)
		{
			var messageAction = new MessageAction(sagaActionType, message, action);
			messageAction.State = state;
			this.MessageActions.Add(messageAction);
		}
	}
}