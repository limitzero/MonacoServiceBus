﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Monaco.Sagas.StateMachine
{
	/// <summary>
	/// State machine that will control the long-running processes that are typically associated with a saga.
	/// </summary>
	public abstract class SagaStateMachine : ISaga
	{
		[XmlIgnore]
		private SagaEventTriggerCondition _sagaEventTriggerCondition;

		[XmlIgnore]
		public IServiceBus Bus { get; set; }

		[XmlIgnore]
		public IDictionary<Type, Func<IMessage, bool>> Correlations { get; private set; }

		[XmlIgnore]
		public IDictionary<SagaStage, SagaMessageActionConfiguration> Configuration { get; set; }

		/// <summary>
		/// Gets the set of trigger conditions that can happen on the saga instance when a message is received.
		/// </summary>
		[XmlIgnore]
		public IDictionary<SagaStage, SagaEventTriggerCondition> TriggerConditions { get; private set; }

		/// <summary>
		/// Gets or sets the name for the saga state machine.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the instance identifier for the saga instance.
		/// </summary>
		public Guid InstanceId { get; set; }

		/// <summary>
		/// Gets or sets the flag to indicate whether or not the process has completed.
		/// </summary>
		public bool IsCompleted { get; set; }

		/// <summary>
		/// Gets or sets the current state of the saga state machine.
		/// </summary>
		public State CurrentState { get; set; }

		/// <summary>
		/// Gets or sets the message that the saga is currently consuming.
		/// </summary>
		public IMessage CurrentMessage { get; set; }

		protected SagaStateMachine()
		{
			this.Correlations = new Dictionary<Type, Func<IMessage, bool>>();
			this.TriggerConditions = new Dictionary<SagaStage, SagaEventTriggerCondition>();
		}

		/// <summary>
		/// This is the marker for defining the state machine and its events.
		/// </summary>
		public abstract void Define();

		/// <summary>
		/// This will mark the begining of the saga instance, which usually maps to the <seealso cref="StartedBy{T}"/>
		/// contract for message consumption.
		/// </summary>
		/// <param name="condition"></param>
		public  void Initially(SagaEventTriggerCondition condition)
		{
			// add the event trigger condition to the collection and mark it as "Initially";
			this.TriggerConditions.Add(SagaStage.Initially, _sagaEventTriggerCondition);
		}

		/// <summary>
		/// This will mark the subsequent processing of the saga instance, which usually maps 
		/// to the <seealso cref="Orchestrates{T}"/> contract for message consumption after a 
		/// particular state has been reached.
		/// </summary>
		/// <param name="condition"></param>
		public void While<TState>(SagaEventTriggerCondition condition)
			where TState : State, new()
		{
			// add the event trigger condition to the collection, set the state, and mark it as "While";
			_sagaEventTriggerCondition.State = new TState();
			this.TriggerConditions.Add(SagaStage.While, _sagaEventTriggerCondition);
		}

		/// <summary>
		/// This signals an event where a message is received on the saga state machine 
		/// and processing will begin in accordance to what the message means.
		/// </summary>
		/// <typeparam name="TMessage"></typeparam>
		/// <param name="when"></param>
		/// <returns></returns>
		public SagaEventTriggerCondition When<TMessage>(Event<TMessage> when)
			where TMessage : IMessage, new()
		{
			// force the saga to consume the current message that matches the event condition:
			_sagaEventTriggerCondition = new SagaEventTriggerCondition(this, new TMessage(),
			   () => ((Consumes<TMessage>)this).Consume((TMessage)this.CurrentMessage));
			return _sagaEventTriggerCondition;
		}

		/// <summary>
		/// This will create an expression used to correlate a message to the saga instance.
		/// </summary>
		/// <typeparam name="TMessage">Current message type to correlate</typeparam>
		/// <param name="correlation">Expression used to determine if the message can be correlated.</param>
		public void Correlate<TMessage>(Func<TMessage, bool> correlation)
			where TMessage : IMessage
		{
			this.Correlations.Add(typeof(TMessage),
			                      theCorrelation => correlation((TMessage)theCorrelation));
		}

		/// <summary>
		/// This will mark the saga as "completed" and signal the removal of the instance
		/// from the persistance store.
		/// </summary>
		public void MarkAsCompleted()
		{
			IsCompleted = true;
		}

		/// <summary>
		/// This will allow the current state machine to be forced to transition to a new state.
		/// </summary>
		/// <typeparam name="TState"></typeparam>
		public void MarkTransitionTo<TState>() where TState : State, new()
		{
			this.CurrentState = new TState();
		}
	}

	/// <summary>
	/// Base implementation of a long-running process with a defined persisted 
	/// data entity for keeping data between long-running process calls.
	/// </summary>
	/// <typeparam name="TData">Type of the data to keep persisted between calls.</typeparam>
	[Serializable]
	public abstract class SagaStateMachine<TData> : Saga, ISaga<TData> 
		where TData : class, ISagaData, new()
	{
		/// <summary>
		/// Gets or sets the data associated with the saga state machine.
		/// </summary>
		public TData Data { get; set; }
	}

}