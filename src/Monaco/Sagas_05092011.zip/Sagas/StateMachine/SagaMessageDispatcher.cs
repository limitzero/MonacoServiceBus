﻿using System;
using System.Linq;
using System.Reflection;
using Castle.MicroKernel;
using Monaco.Exceptions;
using Monaco.Internals.Reflection;

namespace Monaco.Sagas.StateMachine
{
	public class SagaMessageDispatcher
	{
		private readonly IKernel _kernel;
		private readonly ISagaRepository _sagaRepository;

		public SagaMessageDispatcher(IKernel kernel, ISagaRepository sagaRepository)
		{
			_kernel = kernel;
			_sagaRepository = sagaRepository;
		}

		public void Dispatch(SagaStateMachine saga, IMessage message)
		{
			// define the state machine with the current instance if the service bus:
			saga.Bus = _kernel.Resolve<IServiceBus>();
			saga.Define();

			if (IsStartOfNewSaga(saga, message))
			{
				Guid instanceId = Guid.NewGuid();
				saga.InstanceId = instanceId;
				ConsumeMessage(saga, message, true);
			}
			else
			{
				/*
				ISaga sagaFromPersistance = _sagaRepository.Find(((ISaga)saga).InstanceId);

				if (sagaFromPersistance == null) return; // should be there..

				CheckForSagaMessageCorrelation(saga, message);

				RetreivePersistedSagaDataAndInsertToActiveSaga(saga, message);

				if (sagaFromPersistance != null)
				{
					saga = sagaFromPersistance as SagaStateMachine;
				}
				*/

				ConsumeMessage(saga, message);
			}

			// do the persistance here...
		}

		private static bool IsStartOfNewSaga(object theSaga, IMessage message)
		{
			bool isStartingNewSaga = false;

			Type theStartedByInterfaceType = (from contract in theSaga.GetType().GetInterfaces()
											  where contract.IsGenericType == true
													&&
													contract.GetGenericArguments()[0] == message.GetType()
													&&
													contract.FullName.StartsWith(typeof(StartedBy<>).FullName)
											  select contract).FirstOrDefault();

			if (theStartedByInterfaceType != null)
			{
				isStartingNewSaga = true;
			}

			return isStartingNewSaga;
		}

		private void RetreivePersistedSagaDataAndInsertToActiveSaga(SagaStateMachine saga, IMessage message)
		{
			var dataProperty = GetSagaDataProperty(saga);

			if (dataProperty == null) return;

			// need to inject the proper data into the saga for consistency across multiple instances of the saga:
			var theSagaDataFinderType = typeof(ISagaDataFinder<,>)
				.MakeGenericType(dataProperty.PropertyType.GetType(), message.GetType());

			// resolve the data finder from the type created above in the container:
			object theSagaDataFinder = null; // Kernel.Resolve(theSagaDataFinderType);

			if (theSagaDataFinder == null) return;

			// var theSavedSagaData =  reflection.InvokeSagaDataFinderFindMethod(theSagaDataFinder, message);

			// we found our data, insert it into the saga:
			// dataProperty.SetValue(saga, theSavedSagaData);
		}

		private static void CheckForSagaMessageCorrelation(SagaStateMachine saga, IMessage message)
		{
			if (saga.Correlations.Count == 0) return;

			var correlation = saga.Correlations[message.GetType()];

			if (correlation == null) return;

			var result = correlation(message);

			if (result == false)
				throw new SagaMessageCouldNotBeCorrelatedToOngoingSagaException(message.GetType(),
																				saga.GetType());
		}

		private void PersistSaga(object theSaga)
		{
			Guid instanceId = ((ISaga)theSaga).InstanceId;
			bool isCompleted = ((ISaga)theSaga).IsCompleted;

			PropertyInfo theSagaDataProperty = GetSagaDataProperty(theSaga);
			bool isDataPropertyAvailable = (theSagaDataProperty != null);

			ISagaData theSagaData = null;
			object theSagaDataRepository = null;

			if (isDataPropertyAvailable == true)
			{
				theSagaData = theSagaDataProperty.GetValue(theSaga, null) as ISagaData;
				theSagaDataRepository = this.CreateSagaDataRepositoryFromDataType(theSagaDataProperty.PropertyType);
			}

			if (isCompleted == true)
			{
				_sagaRepository.Remove(instanceId);

				if (isDataPropertyAvailable == true)
				{
					_kernel.Resolve<IReflection>().InvokeRemoveForSagaDataRepository(theSagaDataRepository, instanceId);
				}
			}
			else
			{
				_sagaRepository.Save(theSaga as ISaga);

				if (isDataPropertyAvailable == true)
				{
					_kernel.Resolve<IReflection>().InvokeSaveForSagaDataRepository(theSagaDataRepository, theSagaData);
				}
			}
		}

		private object CreateSagaDataRepositoryFromDataType(Type theSagaDataType)
		{
			object theSagaDataRepository = null;

			Type theType = typeof(ISagaDataRepository<>).MakeGenericType(theSagaDataType);

			if (theType != null)
			{
				theSagaDataRepository = _kernel.Resolve(theType);
			}

			return theSagaDataRepository;
		}

		private static PropertyInfo GetSagaDataProperty(object theSaga)
		{
			PropertyInfo theDataProperty = null;

			if (ContainsInterface(theSaga, typeof(ISaga<>)) != null)
			{
				theDataProperty = (from property in theSaga.GetType().GetProperties()
								   where property.Name.Trim().ToLower() == "data"
								   select property).FirstOrDefault();
			}
			return theDataProperty;
		}

		private static Type ContainsInterface(object theComponent, Type interfaceType)
		{
			Type theInterface = (from contract in theComponent.GetType().GetInterfaces()
								 where contract.IsGenericType == true
									   &&
									   contract.FullName.StartsWith(interfaceType.FullName)
								 select contract).FirstOrDefault();

			return theInterface;
		}

		private static void ConsumeMessage(SagaStateMachine saga, IMessage message, bool isStarting = false)
		{
			// set the current message that the state machine is consuming:
			saga.CurrentMessage = message;
			SagaEventTriggerCondition condition = null;

			if (isStarting)
			{
				condition = saga.TriggerConditions[SagaStage.Initially];
			}
			else
			{
				// subsequent stages in the saga, need to get the configuration by current state of saga for "While":

				var triggerCondtions = saga.TriggerConditions.Where(x => x.Key == SagaStage.While).ToList();
				if (triggerCondtions.Count() > 0)
				{
					condition = (from config in triggerCondtions
								 let theConfig = config.Value
								 where theConfig.State.GetType() == saga.CurrentState.GetType()
								 select theConfig).SingleOrDefault();
				}
			}

			// nothing matches for the stage/state combination (send warning???):
			if (condition == null) return;

			foreach (var messageAction in condition.MessageActions)
			{
				messageAction.Action();
			}


		}
	}
}