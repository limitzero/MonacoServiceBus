﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace Monaco.Sagas.StateMachine
{
	/// <summary>
	/// Class to inspect the current saga state machine and create the scenario text describing its behavior
	/// </summary>
	public class SagaVerbalizer
	{
		public string Verbalize<TSagaStateMachine>() where TSagaStateMachine : SagaStateMachine, new()
		{
			return this.Verbalize(new TSagaStateMachine());
		}

		public string Verbalize<TSagaStateMachine>(TSagaStateMachine sagaStateMachine)
			where TSagaStateMachine : SagaStateMachine
		{
			string results = string.Empty;
			sagaStateMachine.Define();

			using (var stream = new MemoryStream())
			{
				string name = sagaStateMachine.Name ?? sagaStateMachine.GetType().Name;
				var trace = new System.Diagnostics.TextWriterTraceListener(stream);
				var preamble = "Configuration for saga state machine : " + name;
				var separator = string.Empty;
				foreach (var c in preamble)
					separator += "=";

				trace.IndentSize = 2;
				trace.IndentLevel = 0;

				trace.WriteLine(preamble);
				trace.WriteLine(separator);

				// define the portion for "Initially" segment:
				var initially = sagaStateMachine.TriggerConditions[SagaStage.Initially];
				WriteInitiallyPart(trace, initially);

				// define the portions for the "While" segment:
				var whileParts = sagaStateMachine.TriggerConditions.Where(x => x.Key == SagaStage.While).ToList();

				foreach (var part in whileParts)
				{
					WriteWhilePart(trace, part.Value);
				}

				trace.Flush();
				stream.Seek(0, SeekOrigin.Begin);

				using (TextReader reader = new StreamReader(stream))
				{
					results = reader.ReadToEnd();
				}
			}

			return results;
		}

		private static void WriteInitiallyPart(TextWriterTraceListener trace,
		                                       SagaEventTriggerCondition condition)
		{
			/* Initially when (message arrives) it will 
			 *		{call the appropriate code} 
			 *		[publish, send, reply, delay, complete]  
			 *	  and  transition to [state]					
			 */

			foreach (var messageAction in condition.MessageActions)
			{
				switch (messageAction.ActionType)
				{
					case (SagaMessageActionType.When):
						trace.IndentLevel = 0;
						trace.WriteLine(string.Format("Initially when the '{0}' message arrives, it will ", messageAction.Message.GetType().Name));
						break;

					case (SagaMessageActionType.Publish):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and publish the message '{0}' ", messageAction.Message.GetType().Name));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.Send):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and send the message '{0}' ", messageAction.Message.GetType().Name));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.SendToEndpoint):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and send the message '{0}' to endpoint '{1}'",
						                              messageAction.Message.GetType().Name,
						                              messageAction.Endpoint));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.Reply):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and reply with the message '{0}' ", messageAction.Message.GetType().Name));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.Delay):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and delay publishing of the message '{0}' by '{1}' days, '{2}' hours, '{3}' minutes, and '{4}' seconds",
						                              messageAction.Message.GetType().Name,
						                              messageAction.Delay.Days,
						                              messageAction.Delay.Hours,
						                              messageAction.Delay.Minutes,
						                              messageAction.Delay.Seconds
						                	));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.Transition):
						trace.IndentLevel = 0;
						trace.WriteLine(string.Format("and transition to state '{0}' ", messageAction.State.GetType().Name));
						break;

					case (SagaMessageActionType.Complete):
						trace.IndentLevel = 0;
						trace.WriteLine("and complete");
						break;
				}
			}


		}

		private static void WriteWhilePart(TextWriterTraceListener trace,
										   SagaEventTriggerCondition condition)
		{
			/* While in state {state},  when (message arrives) it will 
			 *		[do, publish, send, reply, delay, complete]  
			 *	  and  transition to [state]					
			 */

			trace.WriteLine(string.Empty);

			foreach (var messageAction in condition.MessageActions)
			{
				switch (messageAction.ActionType)
				{
					case (SagaMessageActionType.When):
						trace.IndentLevel = 0;
						trace.WriteLine(string.Format("While in state '{0}', when the '{1}' message arrives, it will ",
						                              condition.State.GetType().Name,
						                              messageAction.Message.GetType().Name));
						
						break;

					case (SagaMessageActionType.Do):
						trace.IndentLevel = 1;
						trace.WriteLine("{execute some custom code}");
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.Publish):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and publish the message '{0}' ", messageAction.Message.GetType().Name));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.Send):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and send the message '{0}' ", messageAction.Message.GetType().Name));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.SendToEndpoint):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and send the message '{0}' to endpoint '{1}'",
						                              messageAction.Message.GetType().Name,
						                              messageAction.Endpoint));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.Reply):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and reply with the message '{0}' ", messageAction.Message.GetType().Name));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.Delay):
						trace.IndentLevel = 1;
						trace.WriteLine(string.Format("and delay publishing of the message '{0}' by '{1}' days, '{2}' hours, '{3}' minutes, and '{4}' seconds",
						                              messageAction.Message.GetType().Name,
						                              messageAction.Delay.Days,
						                              messageAction.Delay.Hours,
						                              messageAction.Delay.Minutes,
						                              messageAction.Delay.Seconds
						                	));
						trace.IndentLevel = 0;
						break;

					case (SagaMessageActionType.Transition):
						trace.IndentLevel = 0;
						trace.WriteLine(string.Format("and transition to state '{0}' ", messageAction.State.GetType().Name));
						break;

					case (SagaMessageActionType.Complete):
						trace.IndentLevel = 0;
						trace.WriteLine("and complete");
						break;
				}
			}
		}
	}
}