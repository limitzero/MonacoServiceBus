﻿using System;

namespace Monaco.Sagas.StateMachine
{
	/// <summary>
	/// Actions that can be taken on a saga for a given message.
	/// </summary>
	public class MessageAction
	{
		/// <summary>
		/// Gets the type of action to be taken on the message by the bus for the saga.
		/// </summary>
		public SagaMessageActionType ActionType { get; private set; }

		/// <summary>
		/// Gets the message that will be acted upon in the saga.
		/// </summary>
		public IMessage Message { get; private set; }

		/// <summary>
		/// Gets the executable action to be taken on the message by the bus for the saga.
		/// </summary>
		public Action Action { get; private set; }

		/// <summary>
		/// Gets or sets the state of the current message action.
		/// </summary>
		public State State { get; set; }

		/// <summary>
		/// Gets or sets the endpoint location where one or more messges will be sent.
		/// </summary>
		public string Endpoint { get; set; }

		/// <summary>
		/// Gets or sets the delay interval for a message to be submitted.
		/// </summary>
		public TimeSpan Delay { get; set; }

		public MessageAction(SagaMessageActionType actionType, IMessage message, Action action)
		{
			ActionType = actionType;
			Message = message;
			Action = action;
		}
	}
}