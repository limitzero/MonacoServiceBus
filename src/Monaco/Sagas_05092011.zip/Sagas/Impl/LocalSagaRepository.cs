using System;
using System.Linq;
using Monaco.Exceptions;
using Monaco.Internals.Collections;
using Monaco.Internals.Serialization;
using Monaco.Messages;

namespace Monaco.Sagas.Impl
{
    /// <summary>
    /// Volatile instance of repository for storing saga instances.
    /// </summary>
    public class LocalSagaRepository : ISagaRepository, IDisposable
    {
        private bool _disposing;
        private readonly ISerializationProvider _serializer;
        private static readonly object _threads_lock = new object();
    	private static IThreadSafeDictionary<Guid, ISaga> _threads;

        public LocalSagaRepository(ISerializationProvider serializer)
        {
            _serializer = serializer;

            if(_threads == null)
            {
                _threads = new ThreadSafeDictionary<Guid, ISaga>();
            }
        }

        public void Dispose()
        {
        	this.Dispose(true);
			GC.SuppressFinalize(this);
        }

		public virtual void Dispose(bool disposing)
		{
			this._disposing = disposing;

			if(this._disposing == true)
			{
				if (_threads != null)
				{
					_threads.Clear();
					_threads = null;
				}
			}
		}

    	public ISaga Find(Guid instanceId)
        {
            ISaga theSaga = null;

			if (this._disposing == true) return theSaga;

            lock(_threads_lock)
            {
            	_threads.TryGetValue(instanceId, out theSaga);
                return theSaga;
            }
        }

        public void Save(ISaga saga)
        {
			if (this._disposing == true) return;

            lock (_threads_lock)
            {
				if(_threads.ContainsKey(saga.InstanceId))
				{
					_threads.Remove(saga.InstanceId);
					_threads.Add(saga.InstanceId, saga);
				}
            }
        }

        public void Remove(Guid instanceId)
        {
			if (this._disposing == true) return;

            lock(_threads_lock)
            {
            	_threads.Remove(instanceId);
            }
        }

        private SagaThread CreateThread(ISaga saga, SagaThread previousThread)
        {
            SagaThread theThread =new SagaThread();

            if(previousThread != null)
            {
                theThread.CreatedOn = previousThread.CreatedOn;
            }
            else
            {
                theThread.CreatedOn = DateTime.Now;
            }

			theThread.InstanceId = saga.InstanceId;
            theThread.Instance = _serializer.SerializeToBytes(saga);
            theThread.SagaName = saga.GetType().FullName;

            return theThread;
        }
    }
}