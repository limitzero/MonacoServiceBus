namespace Monaco.Sagas
{
	/// <summary>
	/// Contract on how to associate the persisted data for a saga to an active instance.
	/// </summary>
	/// <typeparam name="TSagaData"></typeparam>
	/// <typeparam name="TMessage"></typeparam>
	public interface ISagaDataFinder<TSagaData, TMessage> 
		where TSagaData : ISagaData
		where TMessage : IMessage
	{
		TSagaData Find(TMessage message);
	}
}