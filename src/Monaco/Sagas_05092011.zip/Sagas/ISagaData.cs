using System;

namespace Monaco.Sagas
{
    /// <summary>
    /// Contract that represents the data that is saved between 
    /// calls for a saga that can be persisted to an external store.
    /// </summary>
    public interface ISagaData : IMessage
    {
        /// <summary>
        /// Gets or sets the unique identifier that corresponds to the 
        /// <seealso cref="ISaga.InstanceId">identifier for the active saga instance</seealso>.
        /// </summary>
        Guid CorrelationId { get; set; }
    }
}