using System;
using System.Collections.Generic;
using Monaco.Internals.Callbacks;
using Rhino.Mocks;
using Rhino.Mocks.Constraints;

namespace Monaco.Sagas.Testing
{
    public class SagaTestScenario : IDisposable
    {
        private readonly MockRepository _mockRepository;
        private readonly Saga _theSaga;
        private readonly IServiceBus _theServiceBus;
        private ICallback _callback;
    	private readonly List<string> _traceMessages;

        public delegate void PublishDelegate(IMessage message);

        public SagaTestScenario(MockRepository mockRepository, Saga theSaga, IServiceBus theMessageBus)
        {
            _mockRepository = mockRepository;

            _theSaga = theSaga;

            _theServiceBus = theMessageBus;

			_traceMessages = new List<string>();
        }

        public void Dispose()
        {
           
        }

        /// <summary>
        /// This will represent a point on the saga where a message can be received on the saga for processing.
        /// </summary>
        /// <param name="action">The functon on the saga that will consume the message</param>
        /// <returns></returns>
		public void WhenItConsumes<TMessage>(Action action) where TMessage : IMessage
        {
			string message = string.Format("When '{0}' consumes the message '{1}'",
										   CleanSagaName(),
										   typeof(TMessage).Name);
			this.InsertTraceMessage(message);
			
            _mockRepository.ReplayAll();

            action();

			this.WriteTraceMessages();

            _mockRepository.VerifyAll();
        }

        /// <summary>
        /// This will execute a series of logical steps in the saga without 
        /// publishing a message.
        /// </summary>
        /// <param name="theAction">The custom code to execute.</param>
        /// <returns></returns>
        public SagaTestScenario ItWillExecute(Action theAction)
        {
			string message = string.Format("\tthen '{0}' will execute some custom code",  _theSaga.GetType().Name);
			this.InsertTraceMessage(message);

            theAction();
            return this;
        }

		public SagaTestScenario ItWillComplete()
		{
			string message = string.Format("\tthen '{0}' will mark itself as 'completed'", CleanSagaName());
			this.InsertTraceMessage(message);

			_theSaga.MarkAsCompleted();
		
			return this;
		}

    	/// <summary>
        /// This will indicate within the saga that it has transitioned 
        /// to a particular state.
        /// </summary>
        /// <param name="state">Name of the state to transition to.</param>
        /// <returns></returns>
        public SagaTestScenario ItWillMarkATransitionTo(string state)
        {
            //_theSaga.TransitionTo(state);
            LastCall.Repeat.AtLeastOnce()
                .Message(string.Format("The saga should indicate that has transitioned to state '{0}'.", state));
            return this;
        }

        /// <summary>
        /// This will mark a point where the saga will send a message and 
        /// expect back a response via a callback.
        /// </summary>
        /// <typeparam name="TMessage"></typeparam>
        /// <param name="sendAction"></param>
        /// <returns></returns>
        [Obsolete]
        private SagaTestScenario ItWillSendWithCallback<TMessage>(Func<TMessage> sendAction)
            where TMessage : class, IMessage
        {
            _callback = _mockRepository.DynamicMock<ICallback>();
            TMessage theSentMessage = sendAction();

			//Expect.Call(_theServiceBus.SendWithCallback(theSentMessage))
			//    .Repeat.AtLeastOnce()
			//    .Return(_callback)
			//    .Message(
			//    "The saga should send a message and register a callback to handle the subsequent reply message.");

            return this;
        }

		/// <summary>
		/// This will mark a point where the saga will send a message.
		/// </summary>
		/// <typeparam name="TMessage"></typeparam>
		/// <param name="sendAction"></param>
		/// <returns></returns>
		 public SagaTestScenario ExpectToSend<TMessage>(Func<TMessage, TMessage> sendAction)
            where TMessage : class, IMessage, new()
        {
			string message = string.Format("\t'{0}' will send the message '{1}'",
				CleanSagaName(),
				typeof(TMessage).Name);

			this.InsertTraceMessage(message);

            TMessage theSentMessage = sendAction(new TMessage());

			_theSaga.Bus.Send(theSentMessage);

			LastCall.Constraints(Is.TypeOf<TMessage>())
				.Repeat.AtLeastOnce()
				.Message(
                "The saga should send the message " +  theSentMessage.GetType().Name +  " directly to the message owner.");

            return this;
        }

		 /// <summary>
		 /// This will represent a point on the saga where the message will be consumed and 
		 /// another distinct message will be produced via the custom logic in the corresponding 
		 /// method and sent out for consumption by other consumers via the message bus.
		 /// </summary>
		 /// <param name="endpointUri">Uri that the message will be published out to.</param>
		 /// <param name="sendAction">Logic that will executed and send a set of messages</param>
		 /// <returns></returns>
		 public SagaTestScenario ExpectToSendToDestination<TMessage>(string endpointUri,
																	   Func<TMessage, TMessage> sendAction)
			   where TMessage : class, IMessage, new()
		 {
			  TMessage theMessage = sendAction( new TMessage());

			 string message = string.Format("\tthen '{0}' will send the message '{1}' to endpoint '{2}'",
			 CleanSagaName(),
				 theMessage.GetType().Name,
			 endpointUri);

			 this.InsertTraceMessage(message);

			 _theSaga.Bus.Send(new Uri(endpointUri), theMessage);

			 LastCall.Constraints(Is.TypeOf<TMessage>())
				 .Repeat.AtLeastOnce()
				 .Message(
				 string.Format("The saga should send the message '{0}' to the location '{1}' .",
							  theMessage.GetType().Name, endpointUri));
			 return this;
		 }

        public SagaTestScenario ExpectReply<TMessage>(Func<TMessage, TMessage> replyAction)
            where TMessage : class, IMessage, new()
        {
			string message = string.Format("\tthen '{0}' will reply with the message '{1}'",
				CleanSagaName(),
				typeof(TMessage).Name);

			this.InsertTraceMessage(message);

            TMessage theReplyMessage = replyAction( new TMessage());

            _theSaga.Bus.Reply(theReplyMessage);

            LastCall.Constraints(Is.TypeOf<TMessage>())
                .Message(
                string.Format("The saga should reply back to the caller with the message '{0}' after the custom logic has been executed.",
                              typeof(TMessage).FullName));
            return this;
        }

        /// <summary>
        /// This will represent a point on the saga where the message will be consumed and 
        /// another distinct message will be produced via the custom logic in the corresponding 
        /// method and published out for consumption by other consumers via the message bus.
        /// </summary>
        /// <typeparam name="TMessage"></typeparam>
        /// <param name="publishAction">Logic that will executed and publish a message</param>
        /// <returns></returns>
        public SagaTestScenario ExpectToPublish<TMessage>(Func<TMessage, TMessage> publishAction)
            where TMessage : class, IMessage, new()
        {
			string message = string.Format("\tthen '{0}' will publish the message '{1}'",
				CleanSagaName(),
				typeof(TMessage).Name);

			this.InsertTraceMessage(message);

            TMessage publishMessage = publishAction(new TMessage());

			_theSaga.Bus.Publish(publishMessage);

			LastCall.Constraints(Is.TypeOf<TMessage>())
				.Repeat.AtLeastOnce()
                .Message(
                string.Format("The saga should publish the message '{0}'", typeof(TMessage).FullName));

            return this;
        }

        /// <summary>
        /// This will represent a point on the saga where the message will be consumed and 
        /// a set of distinct messages will be produced via the custom logic in the corresponding 
        /// method and published out for consumption by other consumers via the message bus.
        /// </summary>
        /// <param name="publishAction"></param>
        /// <returns></returns>
        [Obsolete]
        public SagaTestScenario ExpectToPublishMessages(Func<IMessage[], IMessage[]> publishAction)
        {
            IMessage[] thePublishedMessages = publishAction( new IMessage[] {});

            var theMessages = string.Empty;
            foreach (var theMessage in theMessages)
            {
                theMessages = string.Concat(theMessage.GetType().FullName, ", ");
            }
            theMessages.TrimEnd(new char[] { ',', ' ' });

			string message = string.Format("\tthen '{0}' will publish the messages '{1}'",
				CleanSagaName(),
				theMessages);

			this.InsertTraceMessage(message);

            _theSaga.Bus.Publish(thePublishedMessages);

            LastCall.Constraints(Is.Same(thePublishedMessages))
				.Repeat.AtLeastOnce()
                .Message(
                string.Format("The saga should publish the messages '{0}' after the custom logic has been executed.",
                              theMessages));
            return this;
        }

		private string CleanSagaName()
		{
			string name = string.Empty;

			if (_theSaga.GetType().Name.Contains("Proxy"))
			{
				int proxyPosition = _theSaga.GetType().Name.IndexOf("Proxy");
				name =  _theSaga.GetType().Name.Substring(0, proxyPosition);
			}
			else
			{
				name = _theSaga.GetType().Name;
			}

			return name;
		}

		private void InsertTraceMessage(string message)
		{
			_traceMessages.Add(message);
		}

		private void WriteTraceMessages()
		{
			var messages = _traceMessages.ToArray();
			Array.Reverse(messages);

			foreach (var message in messages)
			{
				System.Diagnostics.Debug.WriteLine(message);
			}
			
			_traceMessages.Clear();
		}
    }
}