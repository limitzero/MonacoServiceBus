using System.Collections.Generic;
using System.IO;
using System.Text;
using Monaco.Internals.Collections;

namespace Monaco.Transport.Impl
{
    public class Envelope : IEnvelope
    {
        private readonly IThreadSafeDictionary<string, object> _headers;

        private object _payload;

        public byte[] BodyStream { get; private set; }

        public Envelope(object payload)
        {
            _payload = payload;

            this.CreateBodyStream();

            _headers = new ThreadSafeDictionary<string, object>();
            SetDefaultHeaders(_payload);
        }

        public TPAYLOAD GetPayload<TPAYLOAD>()
        {
            TPAYLOAD payload = default(TPAYLOAD);

            try
            {
                payload = (TPAYLOAD)_payload;
            }
            catch
            {

            }

            return payload;
        }

        public void AddHeader(string key, object data)
        {
            try
            {
                object value = this.GetHeader(key);

                if(value !=null)
                {
                    _headers.Remove(key);
                }

                _headers.Add(key, data);
            }
            catch
            {
               
            }
        }

        public object GetHeader(string key)
        {
            object data = null;
            _headers.TryGetValue(key, out data);
            return data;
        }

        public TDATA GetHeader<TDATA>(string key)
        {
            TDATA result = default(TDATA);

            try
            {
                result = (TDATA)this.GetHeader(key);
            }
            catch
            {
            }

            return result;
        }

        public void ChangePayload(object payload)
        {
            _payload = payload;
            SetDefaultHeaders(_payload);
        }

        public void CopyHeaders(IEnvelope envelope)
        {
            foreach (KeyValuePair<string, object> pair in _headers)
            {
                envelope.AddHeader(pair.Key, pair.Value);
            }
        }

        /// <summary>
        /// This will set the default header information on a message
        /// if it is derived from <seealso cref="IMessage"/>.
        /// </summary>
        /// <param name="payload"></param>
        private void SetDefaultHeaders(object payload)
        {
            if (typeof(IMessage).IsAssignableFrom(payload.GetType()))
            {
                AddHeader(Headers.MESSAGE_NAME, payload.GetType().Name);
                AddHeader(Headers.MESSAGE_TYPE, payload.GetType().FullName);
            }
        }

        private void CreateBodyStream()
        {
            if (_payload is Stream)
            {
                try
                {
                    MemoryStream theStream = _payload as MemoryStream;
                    var textconverter = new UTF8Encoding();
                    string retval = textconverter.GetString(theStream.ToArray());
                    this.BodyStream = textconverter.GetBytes(retval);
                }
                catch
                {
                    this.BodyStream = new byte[] {};
                }
            }
        }

    }

}