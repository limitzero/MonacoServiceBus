namespace Monaco.Transport.Impl
{
    public class NullEnvelope : Envelope
    {
        public NullEnvelope()
            :this(null)
        {
        }

        public NullEnvelope(object payload) : 
            base(null)
        {
        }
    }
}