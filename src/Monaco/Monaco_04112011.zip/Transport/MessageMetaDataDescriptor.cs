namespace Monaco.Transport
{
    /// <summary>
    /// Metadata descriptor tags for the current message being delivered.
    /// </summary>
    public enum MessageMetaDataDescriptor
    {
        /// <summary>
        /// The name of the message
        /// </summary>
        MESSAGE_NAME, 

        /// <summary>
        /// The fully qualified .NET type of the message including namespace
        /// </summary>
        MESSAGE_TYPE, 

        /// <summary>
        /// The size of the message.
        /// </summary>
        MESSAGE_SIZE
    }
}