﻿using System.IO;

namespace Monaco.Transport
{
    public class TransportMessage : IMessage
    {
        public Stream Contents { get; set; }
    }
}
