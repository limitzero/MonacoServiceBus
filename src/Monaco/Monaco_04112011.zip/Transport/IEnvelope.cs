using System.Collections.Generic;
using Monaco.Internals.Collections;
using Monaco.Transport.Impl;

namespace Monaco.Transport
{
    /// <summary>
    /// Common transport envelope that has the message that is received from the endpoint.
    /// </summary>
    public interface IEnvelope
    {
        /// <summary>
        /// Gets the stream instance of the original payload 
        /// received from the endpoint location.
        /// </summary>
        byte[] BodyStream { get; }

        /// <summary>
        /// This wil retrieve the internal payload of the envelope by type.
        /// </summary>
        /// <typeparam name="TPAYLOAD"></typeparam>
        /// <returns></returns>
        TPAYLOAD GetPayload<TPAYLOAD>();

        /// <summary>
        /// This will change the contents of the envelope payload
        /// from one object to another.
        /// </summary>
        /// <param name="payload">Object that represents the new payload.</param>
        void ChangePayload(object payload);

        /// <summary>
        /// This will add a header to the envelope describing 
        /// either the payload or additional meta-data.
        /// </summary>
        /// <param name="key">Unique key to identify the data.</param>
        /// <param name="data">Value attached to the key.</param>
        void AddHeader(string key, object data);

        /// <summary>
        /// This will extract the value for a given header
        /// </summary>
        /// <param name="key">Unique key to identify the data.</param>
        /// <returns></returns>
        object GetHeader(string key);

        /// <summary>
        /// This will extract the value for a given header
        /// </summary>
        /// <typeparam name="TDATA">Well-known type to cast the data to after extraction.</typeparam>
        /// <param name="key">Unique key to identify the data.</param>
        /// <returns>
        /// Object cast to well-known type or null if it can not be cast.
        /// </returns>
        TDATA GetHeader<TDATA>(string key);
    }

    /// <summary>
    /// Common transport envelope that has the message that is received from the endpoint.
    /// </summary>
    /// <typeparam name="TPAYLOAD">specific payload to initialize with</typeparam>
    public interface IEnvelope<TPAYLOAD>
    {
        IEnvelopeHeader Header { get; }
        IEnvelopeBody<TPAYLOAD> Body { get; }
        IEnvelope ConvertAsUnTyped();
    }

    /// <summary>
    /// Common transport envelope that has the message that is received from the endpoint.
    /// </summary>
    public interface IEnvelope2 : IEnvelope<object>
    {

    }


    public interface  IEnvelopeHeader
    {
        void Add(string key, object value);
        TDATA Get<TDATA>(string key);
        object Get(string key);
        IThreadSafeDictionary<string, object> GetAllHeaders();
        void Copy(IEnvelopeHeader header);
    }

    public class EnvelopeHeader : IEnvelopeHeader
    {
        private readonly IThreadSafeDictionary<string, object> _headers = new ThreadSafeDictionary<string, object>();

        public void Add(string key, object value)
        {
            try
            {
                object data = this.Get(key);

                if (data != null)
                {
                    _headers.Remove(key);
                }

                _headers.Add(key, value);
            }
            catch
            {

            }
        }

        public TDATA Get<TDATA>(string key)
        {
            TDATA result = default(TDATA);

            try
            {
                result = (TDATA)this.Get(key);
            }
            catch
            {
            }

            return result;
        }

        public object Get(string key)
        {
            object data = null;
            _headers.TryGetValue(key, out data);
            return data;
        }

        public IThreadSafeDictionary<string, object> GetAllHeaders()
        {
            return _headers;
        }

        public void Copy(IEnvelopeHeader header)
        {
            foreach (KeyValuePair<string, object> kvp in header.GetAllHeaders())
            {
                this.Add(kvp.Key, kvp.Value);
            }
        }
    }

    public interface IEnvelopeBody<TPAYLOAD>
    {
        /// <summary>
        /// This wil retrieve the internal payload of the envelope by type.
        /// </summary>
        /// <typeparam name="TPAYLOADTYPE"></typeparam>
        /// <returns></returns>
        TPAYLOADTYPE GetPayload<TPAYLOADTYPE>();

        /// <summary>
        /// This will change the contents of the envelope payload from one object to another.
        /// </summary>
        /// <param name="payload">Object that represents the new payload.</param>
        void SetPayload(TPAYLOAD payload);
    }

    public class EnvelopeBody<TPAYLOAD> : IEnvelopeBody<TPAYLOAD>
    {
        private object _payload = null;

        public TPAYLOADTYPE GetPayload<TPAYLOADTYPE>()
        {
            TPAYLOADTYPE payload = default(TPAYLOADTYPE);

            try
            {
                payload = (TPAYLOADTYPE)_payload;
            }
            catch
            {

            }

            return payload;
        }

        public void SetPayload(TPAYLOAD payload)
        {
            _payload = payload;
        }
    }

    public class Envelope<TPAYLOAD> : IEnvelope<TPAYLOAD>
    {
        public IEnvelopeHeader Header { get; private set; }

        public IEnvelopeBody<TPAYLOAD> Body { get; private set;}

        public IEnvelope ConvertAsUnTyped()
        {
            IEnvelope envelope = new Envelope(this.Body.GetPayload<object>());

            foreach (var kvp in this.Header.GetAllHeaders())
            {
                envelope.AddHeader(kvp.Key, kvp.Value);
            }

            return envelope;
        }

        public Envelope()
        {
            this.Header = new EnvelopeHeader();
            this.Body = new EnvelopeBody<TPAYLOAD>();
        }
       
		public Envelope(TPAYLOAD payload)
		{
			this.Header = new EnvelopeHeader();
			this.Body = new EnvelopeBody<TPAYLOAD>();
			this.Body.SetPayload(payload);
		}
    }
}