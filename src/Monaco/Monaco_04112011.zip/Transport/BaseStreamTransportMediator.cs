using System.IO;

namespace Monaco.Transport
{
    /// <summary>
    /// Base class that is used for converting messages to a specific format where 
    /// the transport technology send format is a Stream and the <seealso cref="TransportMessage"/>.
    /// is returned with the contents of the Stream from the received message.
    /// </summary>
    public abstract class BaseStreamTransportMediator : 
        BaseTransportMediator<Stream, TransportMessage>
    {
        
    }
}