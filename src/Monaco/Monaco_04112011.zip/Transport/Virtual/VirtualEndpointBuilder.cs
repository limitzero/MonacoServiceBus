using System;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Internals.Serialization;

namespace Monaco.Transport.Virtual
{
    /// <summary>
    /// Example of endpoint builder class for the virtual endpoint.
    /// </summary>
    public class VirtualEndpointBuilder : IEndpointBuilder<VirtualEndpoint>
    {
        private const string _scheme = "vm";

        public string Scheme
        {
            get { return _scheme; }
        }

        public ISerializationProvider Serializer
        {
            set; private get;
        }


        public IEndpointBuilderSubscription CreateSubscription()
        {
            string description = "Builder scheme for sending and receiving messages in-memory.";
            EndpointBuilderSubscription subscription = new EndpointBuilderSubscription(Scheme, this.GetType().AssemblyQualifiedName, description);
            return subscription;
        }

        public VirtualEndpoint Build(string uri)
        {
            return this.Build(string.Format("VM-{0}", Guid.NewGuid().ToString()), uri);
        }

        public VirtualEndpoint Build(string name, string uri)
        {
            VirtualEndpointAddress address = new VirtualEndpointAddress(uri);
            VirtualEndpointTransport transport = new VirtualEndpointTransport();
            VirtualEndpoint endpoint = new VirtualEndpoint(address, transport);
            endpoint.Name = name;

            return endpoint;
        }
    }
}