using Monaco.Configuration.Bootstrapper;
using Monaco.Endpoint;

namespace Monaco.Transport.Virtual.Bootstrapper
{
    /// <summary>
    /// Example bootstrapper to dyanmically register the transport
    /// on the message bus instance within the configuration cycle:
    /// </summary>
    public class VirtualEndpointTransportBootstrapper : BaseBootstrapper
    {
        public VirtualEndpointTransportBootstrapper()
        {
            // this is auto-registered in the facility:
            this.IsActive = false;
        }

        public override void Configure()
        {
            IEndpointBuilderSubscriptionRepository repository =
                Kernel.Resolve<IEndpointBuilderSubscriptionRepository>();

            if (repository != null)
            {
                repository.Add(new VirtualEndpointBuilder().CreateSubscription());
            }
        }
    }

}