using System;
using Monaco.Transport.Impl;

namespace Monaco.Transport.Virtual
{
    /// <summary>
    /// Transport for sending data in and out of a memory location.
    /// </summary>
    public class VirtualEndpointTransport : ITransport
    {
        private readonly int MAX_QUEUE_SIZE = 256;
        private static readonly object _vm_transport_storage_lock = new object();

        [ThreadStatic]
        private volatile bool _isBusy;

        public event Action<IEnvelope> OnMessageReceived;

        public string EndpointUri { get; set;}
        
        public bool IsTransactional { get; set; }

        public bool IsRecoverable { get; set; }

        public VirtualEndpointTransport()
        {
            
        }

        public void Dispose()
        {
        }


        public VirtualEndpointTransport(int depth)
        {
            MAX_QUEUE_SIZE = depth;
        }

        public void Send(string location, IEnvelope envelope)
        {
            this.Send(envelope);
        }

        public void Send(IEnvelope envelope)
        {
            lock (_vm_transport_storage_lock)
            {
                this._isBusy = (VirtualEndpointStorage.Count(EndpointUri) > MAX_QUEUE_SIZE);

                while (this._isBusy)
                {
                    System.Threading.Thread.Sleep(100);
                    System.Diagnostics.Debug.WriteLine(".");
                }

                // do not know specifically what the payload is, just get it...
                VirtualEndpointStorage.Enqueue(EndpointUri, envelope.GetPayload<object>());
            }
        }

        public IEnvelope Receive()
        {
            return this.Receive(TimeSpan.Zero);
        }

        public void Connect()
        {
            // used by technology to connect/create physical location
        }

        public void Disconnect()
        {
            // used by technology to disconnect/destroy physical location
        }

        public void Reconnect()
        {
            this.Disconnect();
            this.Connect();
        }

        public IEnvelope Receive(TimeSpan timeout)
        {
            IEnvelope envelope = null;

            try
            {
                lock (_vm_transport_storage_lock)
                {
                    object message = VirtualEndpointStorage.Dequeue(this.EndpointUri);     
                    envelope = new Envelope(message);

                    this._isBusy = (VirtualEndpointStorage.Count(EndpointUri) > MAX_QUEUE_SIZE); 
                }
            }
            catch
            {
                // queue does not have any messages, sleep and wait;
                System.Threading.Thread.Sleep(timeout);
            }

            return envelope;
        }
    }
}