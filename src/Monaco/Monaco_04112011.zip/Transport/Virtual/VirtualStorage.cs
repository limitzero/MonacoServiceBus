using System.Linq;
using Monaco.Internals.Collections;

namespace Monaco.Transport.Virtual
{
    /// <summary>
    /// Storage of items sent on the virtual endpoint, needed because virtual endpoints
    /// are created at will and storing the data on the transport implementation will 
    /// go away when the endpoint is disposed.
    /// </summary>
    public class VirtualEndpointStorage
    {
        private static readonly object _storage_lock = new object();
        private static IThreadSafeList<VirtualEndpointStorageItem> _storage;

        static VirtualEndpointStorage()
        {
            if (_storage == null)
            {
                _storage = new ThreadSafeList<VirtualEndpointStorageItem>();
            }
        }

        ~VirtualEndpointStorage()
        {
            _storage.Clear();
            _storage = null;
        }

        public static void Enqueue(string location, object data)
        {
            if (_storage == null) return;

            lock (_storage_lock)
            {
                VirtualEndpointStorageItem item = new VirtualEndpointStorageItem { Key = location, Data = data };
                _storage.Add(item);
            }
        }

        public static int Count(string location)
        {
            if (_storage == null) return 0;

            lock (_storage_lock)
            {
                int count = (from item in _storage
                             where item.Key == location
                             select item).Count();

                return count;
            }
        }

        public static object Dequeue(string location)
        {
            if (_storage == null) return null;

            lock (_storage_lock)
            {
                VirtualEndpointStorageItem theItem = new VirtualEndpointStorageItem();

                if (_storage.Count() > 0)
                {
                    theItem = (from item in _storage
                               where item.Key == location
                               select item).FirstOrDefault();
                    if (theItem != null)
                    {
                        _storage.Remove(theItem);
                    }
                }

                return theItem.Data;
            }
        }

    }
}