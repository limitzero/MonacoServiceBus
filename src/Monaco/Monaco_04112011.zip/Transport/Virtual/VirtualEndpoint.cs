using System;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;

namespace Monaco.Transport.Virtual
{
    /// <summary>
    /// Endpoint that denotes an in-memory location for retrieving and storing data
    /// </summary>
    public class VirtualEndpoint : BaseEndpoint
    {
        public VirtualEndpoint(IEndpointAddress address,
                               ITransport transport) : 
            base(address, transport)
        {
            // this implementation does not support transactions:
            this.IsTransactional = false;
        }

        public override void DoSend(IEnvelope envelope)
        {
            // coulld add something to the envelope before sending...
            this.Transport.Send(envelope);
        }

        public override IEnvelope Receive(TimeSpan timeout)
        {
            // coulld add something to the envelope before returning...
            IEnvelope envelope = this.Transport.Receive(timeout);
            return envelope;
        }
    }
}