using System;
using Monaco.Endpoint;
using Monaco.Exceptions;

namespace Monaco.Transport.Virtual
{
    /// <summary>
    /// Addressing scheme for in-memory endpoints
    /// </summary>
    public class VirtualEndpointAddress : IEndpointAddress
    {
        private const string _scheme = "vm";
        private const string _format = "vm://{location}";

        public string Uri
        {
            get;
            private set;
        }

        public VirtualEndpointAddress(string address)
        {
            this.ValidateAddress(address);
        }

        private void ValidateAddress(string address)
        {
            System.Uri theUri = null;

            try
            {
                theUri = new Uri(address);
            }
            catch (Exception ex)
            {
                throw new InvalidEndpointUriAddressException(address, _format, ex);
            }

            if (theUri.Scheme != _scheme)
            {
                throw new InvalidEndpointUriAddressException(address, _format);
            }

            // only one host is allowed for the vm target:
            string[] theParts = address.Replace("vm://", string.Empty).Split(new char[] {'/'});

            if(theParts.Length > 1)
            {
                throw new InvalidEndpointUriAddressException(address, _format);
            }

            // no adjustment needed, just use the value passed:
            this.Uri = address;
        }

        private string Normalize(string address)
        {
            string path = string.Empty;

            string thePath = address.Replace(string.Concat(_scheme, "://"), string.Empty);
            string[] theParts = thePath.Split(new char[] { '/' });

            string location = theParts[0].Trim();
            path = location;

            return path;
        }
    }
}