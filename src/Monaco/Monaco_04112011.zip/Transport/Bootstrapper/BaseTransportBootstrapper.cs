using Monaco.Configuration.Bootstrapper;
using Monaco.Endpoint;

namespace Monaco.Transport.Bootstrapper
{
    /// <summary>
    /// Base boot-strapper for all transports that can provide for message receipt and delivery on the message bus.
    /// </summary>
    public abstract class BaseTransportBootstrapper : BaseBootstrapper
    {
        public override void Configure()
        {
            IEndpointBuilderSubscription subscription = this.Create();

            if(subscription != null)
            {
                IEndpointBuilderSubscriptionRepository repository =
                Kernel.Resolve<IEndpointBuilderSubscriptionRepository>();

                if (repository != null)
                {
                    repository.Add(subscription);
                }      
            }
        }

        public abstract IEndpointBuilderSubscription Create();
    }
}