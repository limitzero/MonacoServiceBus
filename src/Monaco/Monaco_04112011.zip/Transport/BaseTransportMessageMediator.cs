using System;
using System.IO;
using Monaco.Transport.Builder;
using Monaco.Transport.Formatter;

namespace Monaco.Transport
{
    /// <summary>
    /// Base class that is used for forward building of messages to be consumed on 
    /// the message bus and forward formatting of messges to be delivered to the 
    /// specific transport location.
    /// </summary>
    /// <typeparam name="TDELIVERYMESSAGEFORMAT">Message format needed for the transport to deliver the message.</typeparam>
    /// <typeparam name="TNORMALIZEDMESSAGE">Message that is constructed which is derived from <seealso cref="IMessage"/></typeparam>
    public abstract class BaseTransportMediator<TDELIVERYMESSAGEFORMAT, TNORMALIZEDMESSAGE> :
        IMessageFormatter<TDELIVERYMESSAGEFORMAT>, 
        IMessageBuilder<TransportMessage> 
    {
        public IEnvelope<TDELIVERYMESSAGEFORMAT> Format(object message)
        {
            IEnvelope<TDELIVERYMESSAGEFORMAT> envelope = null;

            try
            {
                envelope = this.DoFormat(message);
            }
            catch (Exception e)
            {
                throw;
            }

            return envelope;
        }

        /// <summary>
        /// This is the user-supplied method for converting the message to the target 
        /// format needed by the technology for delivering the message.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public abstract IEnvelope<TDELIVERYMESSAGEFORMAT> DoFormat(object message);

        public  IEnvelope<TransportMessage> Build(Stream stream)
        {
            IEnvelope<TransportMessage> envelope = null; 

            try
            {
                envelope = this.DoBuild(stream);
            }
            catch (Exception e)
            {                
                throw;
            }

            return envelope;
        }

        /// <summary>
        ///  This is teh user-supplied method for converting the message received
        /// from the transport into the appropriate target message format for consumption 
        /// on the message bus.
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public virtual IEnvelope<TransportMessage> DoBuild(Stream stream)
        {
            TransportMessage message = new TransportMessage();
            message.Contents = stream;

            // create the enveloped message with the appropriate headers:
            Envelope<TransportMessage> envelope = new Envelope<TransportMessage>();
            envelope.Body.SetPayload(message);

            return envelope;
        }
    }
}