﻿namespace Monaco.Transport
{
    /// <summary>
    /// Constants for pre-defined message header values on the <seealso cref="IEnvelope"/>
    /// </summary>
    public static class Headers
    {
        /// <summary>
        /// The name of the message (i.e. object.GetType().Name).
        /// </summary>
        public static readonly string MESSAGE_NAME = "message.name";

        /// <summary>
        /// The full name of the message (i.e. object.GetType().Fullname).
        /// </summary>
        public static readonly string MESSAGE_TYPE= "message.type";

        /// <summary>
        /// The endpoint where the message was received from:
        /// </summary>
        public static readonly string ENDPOINT_URI = "endpoint.uri";
    }
}
