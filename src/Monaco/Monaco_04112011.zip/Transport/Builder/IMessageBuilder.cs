using System.IO;

namespace Monaco.Transport.Builder
{
    /// <summary>
    /// The message builder is responsible for constructing the mesage that 
    /// is received from the transport to an <seealso cref="IEnvelope"/>
    /// where the payload is a concrete implementation of <seealso cref="IMessage"/>.
    /// </summary>
    public interface IMessageBuilder<TTARGETMESSAGE> where TTARGETMESSAGE : IMessage
    {
        /// <summary>
        /// Gets or sets the message from the transport source.
        /// </summary>
        //TSOURCEMESSAGE SourceMessage { get; set; }

        /// <summary>
        /// This will create a message that is specific in name to the 
        /// transport and also derives from the <seealso cref="IMessage"/> contract.
        /// </summary>
        /// <param name="stream">Current stream that represents the message retreived from the transport.</param>
        /// <returns></returns>
        IEnvelope<TTARGETMESSAGE> Build(Stream stream);
    }
}