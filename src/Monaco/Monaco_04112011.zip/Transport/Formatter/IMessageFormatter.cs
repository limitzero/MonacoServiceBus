namespace Monaco.Transport.Formatter
{
    /// <summary>
    /// This is the contract that is implemented by the transport for transforming 
    /// a message into the format needed by the transport technology.
    /// </summary>
    /// <typeparam name="TMESSAGE"></typeparam>
    public interface IMessageFormatter<TMESSAGE> 
    {
        /// <summary>
        /// This will format the message passed into the structure needed by the endpoint 
        /// transport for delivery to the physical location. 
        /// </summary>
        /// <param name="message">Message to format</param>
        /// <returns></returns>
        IEnvelope<TMESSAGE> Format(object message);
    }
}