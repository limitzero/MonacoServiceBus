using System.Collections.Generic;

namespace Monaco.Transport
{
    /// <summary>
    /// Holds the metadata associated with the transport envelope.
    /// </summary>
    public class MessageMetaData
    {
        public IDictionary<MessageMetaDataDescriptor, object> Data { get; private set; }

        public MessageMetaData()
        {
            this.Data = new Dictionary<MessageMetaDataDescriptor, object>();
        }

        public void AddMetaData(MessageMetaDataDescriptor descriptor, object value)
        {
            var kvp = new KeyValuePair<MessageMetaDataDescriptor, object>(descriptor, value);
            if(!this.Data.ContainsKey(descriptor))
                this.Data.Add(kvp);
        }

        public TDATA GetMetaDataItem<TDATA>(MessageMetaDataDescriptor descriptor)
        {
            object metadata;
            this.Data.TryGetValue(descriptor, out metadata);
            return (TDATA)metadata;
        }
    }
}