using Monaco.Internals;

namespace Monaco
{
    /// <summary>
    /// Contract for a component that will produce a certain message. This 
    /// is primarily used in conjuction with the scheduler for simple time-based
    /// tasks that execute on a schedule.
    /// </summary>
    /// <typeparam name="TMESSAGE">The message to produce</typeparam>
    public interface Produces<TMESSAGE> : IProducer where TMESSAGE : IMessage
    {
        /// <summary>
        /// This will return the message to be consumed on the messaging infrastructure.
        /// </summary>
        /// <returns></returns>
        TMESSAGE Produce();
    }
}