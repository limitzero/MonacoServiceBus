using System;

namespace Monaco.Exceptions
{
    public class InvalidPipelineMessageOnReceiveException : ApplicationException
    {
        private const string _message = "";

        public InvalidPipelineMessageOnReceiveException(object payload)
            : base(_message)
        {
            
        }
    }
}