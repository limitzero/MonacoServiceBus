using System;

namespace Monaco.Exceptions
{
    /// <summary>
    /// Exception that is thrown when the message can not be correlated to the ongoing saga for processing.
    /// </summary>
    public class SagaMessageCouldNotBeCorrelatedToOngoingSagaException : ApplicationException
    {
        private const string _message =
            "The following message '{0}' could not be correlated to the current saga '{1}' by the choosen identifier/token.";

        public SagaMessageCouldNotBeCorrelatedToOngoingSagaException(Type theMessage, Type theSaga)
            :base(string.Format(_message, theMessage.FullName, theSaga.FullName))
        {
            
        }
    }
}