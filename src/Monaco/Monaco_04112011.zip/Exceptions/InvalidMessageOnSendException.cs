using System;

namespace Monaco.Exceptions
{
    public class InvalidPipelineMessageOnSendException : ApplicationException
    {
        private const string _message = "";

        public InvalidPipelineMessageOnSendException(object payload)
            :base(_message)
        {
            
        }
    }
}