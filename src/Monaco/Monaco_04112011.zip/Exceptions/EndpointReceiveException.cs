using System;

namespace Monaco.Exceptions
{
    public class EndpointReceiveException : ApplicationException
    {
        private const string _message = "The endpoint '{0}' could not receive the message. Reason:{1}";

        public EndpointReceiveException(string endpointUri, Exception exception)
            : base(string.Format(_message, endpointUri, exception.ToString()), exception)
        {
            
        }
    }
}