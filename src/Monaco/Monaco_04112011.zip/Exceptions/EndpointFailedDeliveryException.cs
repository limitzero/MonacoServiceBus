using System;
using Monaco.Endpoint.Impl;

namespace Monaco.Exceptions
{
    /// <summary>
    /// Exception generated when the retry period has been exhausted for sending 
    /// a message to a dedicated endpoint. This will be the trigger for pushing the message
    /// to the poision endpoint for inspection.
    /// </summary>
    public class EndpointFailedDeliveryException : ApplicationException
    {
        private const string _message = "The following message '{0}' failed to be delivered " +
            "to the following endpoint location '{1}'. Reason: {2}";

        public EndpointFailedDeliveryException(BaseEndpoint endpoint, object message, Exception inner)
            :base(string.Format(_message, message.GetType().FullName, endpoint.Address.Uri, inner.Message), inner)
        {
            
        }

    }
}