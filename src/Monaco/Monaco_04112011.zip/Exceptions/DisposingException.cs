using System;

namespace Monaco.Exceptions
{
    public class DisposingException : ApplicationException
    {
        
    }
}