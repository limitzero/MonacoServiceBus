using System;
using System.Collections.Generic;
using Monaco.Endpoint;
using Monaco.Internals;
using Monaco.Internals.Callbacks;
using Monaco.Internals.Eventing;

namespace Monaco
{
    /// <summary>
    /// Contract for a service bus that will act as a selective wire-tap, listening for messages that it has subscribed to.
    /// </summary>
    public interface IServiceBus : IStartable
    {
        /// <summary>
        /// Event that is fired when the bus is started.
        /// </summary>
        Action<string> OnStart { get; set; }

        /// <summary>
        /// Event that is fired when the bus is stopped.
        /// </summary>
        Action<string> OnStop { get; set; }

        /// <summary>
        /// This will resolve an instance of a component from the underlying container.
        /// </summary>
        /// <typeparam name="TCOMPONENT">Type to resolve.</typeparam>
        /// <returns></returns>
        TCOMPONENT Find<TCOMPONENT>();

        /// <summary>
        /// This will resolve an instance of a component from the underlying container.
        /// </summary>
        /// <param name="component">The type of the component to find in the container.</param>
        /// <returns></returns>
        object Find(Type component);

        /// <summary>
        /// This will find all of the components of the well-known 
        /// type from the underlying container used by the message bus.
        /// </summary>
        /// <typeparam name="TCOMPONENT">Type to find all occurrences for.</typeparam>
        /// <returns></returns>
        ICollection<TCOMPONENT> FindAll<TCOMPONENT>();

        /// <summary>
        /// This will create an instance of well-known type.
        /// </summary>
        /// <typeparam name="TTYPETOCREATE">Type to create</typeparam>
        /// <returns></returns>
        TTYPETOCREATE Create<TTYPETOCREATE>();

        /// <summary>
        /// This will create an instance of an object from the type.
        /// </summary>
        /// <param name="theType"></param>
        /// <returns></returns>
        object Create(Type theType);

        /// <summary>
        /// This will instruct the message bus to mark this message as eligible for the service bus
        /// to pick-up for processing and associate a particular component instance
        /// for processing the message.
        /// </summary>
        /// <typeparam name="TMESSAGE">The message to mark as eligble for the service bus to process.</typeparam>
        void Subscribe<TMESSAGE>()
            where TMESSAGE : IMessage;

        /// <summary>
        /// This will send a message and invoke a callback for the 
        /// sender if provided. This will not work across messaging
        /// domains for the callback.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        ICallback Send(IMessage message);

        /// <summary>
        /// This will send a response to the caller for the request made 
        /// by the <seealso cref="Send"/> method on the message bus.
        /// </summary>
        /// <param name="message"></param>
        void Reply(IMessage message);

        /// <summary>
        /// This will publish the message to the message consumers.
        /// </summary>
        /// <typeparam name="TMESSAGE">The message to publish out to interested subscribers.</typeparam>
        /// <param name="message">The message intended for publication.</param>
        /// <returns></returns>
        void Publish<TMESSAGE>(TMESSAGE message) where TMESSAGE : IMessage;

        /// <summary>
        /// This will publish the current set of messages to the message consumers.
        /// </summary>
        /// <param name="messages">Array of  messages for publication</param>
        /// <returns></returns>
        void Publish(params IMessage[] messages);

        /// <summary>
        /// This will publish the message to a given endpoint.
        /// </summary>
        /// <typeparam name="TMESSAGE">The type message to publish out to interested subscribers.</typeparam>
        /// <param name="endpoint">The location to publish the message to.</param>
        /// <param name="message">The message intended for publication.</param>
        /// <returns></returns>
        void Publish<TMESSAGE>(string endpoint, TMESSAGE message) where TMESSAGE : IMessage;

    	IEndpoint GetEndpoint(string name);
    }
}