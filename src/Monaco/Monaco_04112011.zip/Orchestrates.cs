namespace Monaco
{
    /// <summary>
    /// Contract to denoted a subsequent message coming into an existing long-running process.
    /// </summary>
    /// <typeparam name="TMESSAGE">Message that participates in the existing process.</typeparam>
    public interface Orchestrates<TMESSAGE> : Consumes<TMESSAGE> where TMESSAGE : IMessage
    {
    }
}