namespace Monaco
{
    /// <summary>
    /// Marker interface for all messages that will be participating in the messaging infrastructure.
    /// </summary>
    public interface IMessage
    {
    }
}