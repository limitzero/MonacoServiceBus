namespace Monaco
{
    /// <summary>
    /// Contract to denote the starting message that initiates the beginning  of a long-running process.
    /// </summary>
    /// <typeparam name="TMESSAGE">Message that starts the long running process.</typeparam>
    public interface StartedBy<TMESSAGE> : Consumes<TMESSAGE> where TMESSAGE : IMessage
    {
    }
}