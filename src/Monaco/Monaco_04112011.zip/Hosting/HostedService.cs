﻿using System;
using log4net;
using Monaco.Internals;

namespace Monaco.Hosting
{
	public class HostedService : IStartable
	{
		private readonly IApplicationHost _host;
		private readonly string _assemblyName;
		private readonly AppDomain _appDomain;

		private readonly ILog log = LogManager.GetLogger(typeof(HostedService));

		public bool IsRunning { get; private set; }

		public IApplicationHost Host { get; private set; }

		public HostedService(IApplicationHost host, string assemblyName, AppDomain appDomain)
		{
			Host = host;
			_assemblyName = assemblyName;
			_appDomain = appDomain;
		}

		public void Dispose()
		{
			this.Stop();
		}

		public void Start()
		{
			Host.Start();
		}

		public void Stop()
		{
			Host.Stop();

			try
			{
				AppDomain.Unload(this._appDomain);
			}
			catch (AppDomainUnloadedException appDomainUnloadedException)
			{
				log.Error("Could not unload the app domain, most likely there is a thread that could not be aborted.");
			}
			finally
			{
				this.Host = null;
			}
		}
	}
}