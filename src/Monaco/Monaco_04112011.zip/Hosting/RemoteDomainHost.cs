﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Monaco.Internals;

namespace Monaco.Hosting
{
	public class RemoteDomainHost : IStartable
	{
		private readonly string _applicationLocation;
		private readonly string _assemblyName;
		private string _configurationFile;
		private string hostType = typeof(DefaultHost).FullName;
		private string hostAsm = typeof(DefaultHost).Assembly.FullName;

		public bool IsRunning { get; private set; }

		public HostedService HostedService { get; private set; }

		public RemoteDomainHost(string assembly, string configurationFile)
		{
			Assembly asm = Assembly.Load(assembly);
			this._configurationFile = configurationFile;
			this._applicationLocation = Path.GetDirectoryName(asm.Location);
			this._assemblyName = Path.GetFileNameWithoutExtension(asm.Location);
		}

		public RemoteDomainHost(Assembly assembly, string configurationFile)
		{
			this._configurationFile = configurationFile;
			this._applicationLocation = Path.GetDirectoryName(assembly.Location);
			this._assemblyName = Path.GetFileNameWithoutExtension(assembly.Location);
		}

		public RemoteDomainHost(string applicationLocation, string assemblyName, string configurationFile)
		{
			_applicationLocation = applicationLocation;
			_assemblyName = assemblyName;
			_configurationFile = configurationFile;
		}

		public void Dispose()
		{
			this.Stop();
		}

		public void Start()
		{
			HostedService service = CreateApplicationDomain();
			this.HostedService = service;

			try
			{
				service.Start();
			}
			catch (ReflectionTypeLoadException e)
			{
				var sb = new StringBuilder();
				foreach (var exception in e.LoaderExceptions)
				{
					sb.AppendLine(exception.ToString());
				}
				throw new TypeLoadException(sb.ToString(), e);
			}

		}

		public void Stop()
		{
			if (this.HostedService != null)
			{
				this.HostedService.Stop();
			}
			this.HostedService = null;
		}


		private string ResolveAssemblyNameFromPath(string assemblyName, string assemblyPath)
		{
			string name = string.Empty;

			string file = (from item in Directory.GetFiles(assemblyPath, "*.dll")
			               where item.ToLower().Trim().Contains(assemblyName)
			               select item).FirstOrDefault();

			if(string.IsNullOrEmpty(file) == false)
			{
				name = new FileInfo(file).Name;
			}

			return name;
		}

		private HostedService CreateApplicationDomain()
		{
			// create the app domain:
			AppDomainSetup appDomainSetup = new AppDomainSetup()
			                                	{
			                                		ApplicationBase = _applicationLocation,
			                                		ApplicationName = _assemblyName,
			                                		ConfigurationFile = CreateConfigurationFile(),
			                                		ShadowCopyFiles = "true",
													ShadowCopyDirectories = "true"
			                                	};

			AppDomain appDomain = AppDomain.CreateDomain(_assemblyName, null, appDomainSetup);
			return CreateRemoteHost(appDomain);
		}

		private HostedService CreateRemoteHost(AppDomain appDomain)
		{
			object instance = appDomain.CreateInstanceAndUnwrap(hostAsm, hostType);

			IApplicationHost host = (IApplicationHost)instance;
			host.SetHostAssembly(_assemblyName);

			return new HostedService(host, _assemblyName, appDomain);
		}

		private string CreateConfigurationFile()
		{
			if (_configurationFile != null)
				return _configurationFile;

			_configurationFile = Path.Combine(_applicationLocation, _assemblyName + ".dll.config");

			if (File.Exists(_configurationFile) == false)
				_configurationFile = Path.Combine(_applicationLocation, _assemblyName + ".exe.config");

			return _configurationFile;

		}

		private static string FormatAssemblyName(string assemblyFullName)
		{
			string formattedAssemblyName = assemblyFullName;

			string[] parts = assemblyFullName.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);

			if (parts.Length > 2)
			{
				formattedAssemblyName = parts[0].Trim();
			}

			return formattedAssemblyName;
		}
	}
}