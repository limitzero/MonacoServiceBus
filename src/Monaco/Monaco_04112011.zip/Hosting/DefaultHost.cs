﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using log4net;
using Monaco.Configuration;

namespace Monaco.Hosting
{
	public class DefaultHost : MarshalByRefObject,  IApplicationHost
	{
		private readonly ILog logger = LogManager.GetLogger(typeof(DefaultHost));
		private IServiceBus _serviceBus;
		private MonacoContainer _container;
		private string _hostAssembly;
		private string _configurationFile;

		public IServiceBus Bus { get; private set; }

		public void Dispose()
		{
			this.Stop();
		}

		public bool IsRunning { get; private set; }

		public void Start()
		{
			CheckForEndpointConfiguration();

			CreateContainer();

			Bus = this._container.Resolve<IServiceBus>();
			Bus.Start();
		}

		public void Stop()
		{
			if (Bus != null)
			{
				Bus.Stop();
			}
			Bus = null;

			if (this._container != null)
			{
				_container.Dispose();
			}
			_container = null;
		}

		public void SetHostAssembly(string assemblyName)
		{
			this._hostAssembly = assemblyName;
		}

		public void SetConfigurationFile(string configurationFile)
		{
			this._configurationFile = configurationFile;
		}

		private void CreateContainer()
		{
			if (this._container == null)
			{
				if (string.IsNullOrEmpty(this._configurationFile) == true)
				{
					if (File.Exists(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile) == true)
					{
						_container = new MonacoContainer(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
					}
				}
				else
				{
					_container = new MonacoContainer(this._configurationFile);
				}
			}
		}

		private void CheckForEndpointConfiguration()
		{
			Assembly target = null; 

			try
			{
				target = Assembly.Load(this._hostAssembly);
			}
			catch (System.IO.FileNotFoundException fileNotFoundException)
			{
				logger.Error("The following assembly " + this._hostAssembly + " could not be found.");
				throw;
			}
			catch (System.IO.FileLoadException fileLoadException)
			{
				logger.Error("The following assembly " + this._hostAssembly + " could not be loaded.");
				throw;
			}

			var endpointConfiguration = (from type in target.GetTypes()
			                             where type.IsClass && !type.IsAbstract
			                                   && typeof (BaseServiceEndpointConfiguration).IsAssignableFrom(type)
			                             select type).FirstOrDefault();

			if(endpointConfiguration == null)
			{
				throw new Exception("There is not a service endpoint configuration registered for the assembly " + this._hostAssembly +
				                    ". Please create a class derived from " + typeof(BaseServiceEndpointConfiguration).FullName + " to define the endpoint configuration of your service.");
			}
		}
	}
}