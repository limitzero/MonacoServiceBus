using Monaco.Internals;

namespace Monaco.Hosting
{
	public interface IApplicationHost : IStartable
	{
		IServiceBus Bus { get; }
		void SetHostAssembly(string assemblyName);
		void SetConfigurationFile(string configurationFile);
	}
}