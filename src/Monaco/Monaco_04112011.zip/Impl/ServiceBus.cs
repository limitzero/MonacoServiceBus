using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Castle.MicroKernel;
using Monaco.Agents.Scheduler;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Exceptions;
using Monaco.Internals;
using Monaco.Internals.Agent;
using Monaco.Internals.Callbacks;
using Monaco.Internals.Dispatcher;
using Monaco.Internals.Eventing;
using Monaco.Internals.Logging;
using Monaco.Internals.Serialization;
using Monaco.Messages;
using Monaco.Messages.For.Endpoints;
using Monaco.Messages.For.ServiceBus;
using Monaco.Services;
using Monaco.Services.Impl;
using Monaco.Subscriptions;
using Monaco.Subscriptions.Impl;
using Monaco.Transport;
using Monaco.Transport.Impl;

namespace Monaco.Impl
{
    public class ServiceBus : IServiceBus, INotificationEventBroadcaster
    {
        private bool _disposing;
        private const int MESSAGE_BATCH_SIZE = 256;
        private readonly IKernel _kernel;
        private readonly IScheduler _scheduler;
        private readonly ISubscriptionRepository _subscriptionRepository;
        private readonly IDispatcher _dispatcher;
        private readonly IAgentManager _agentManager;
        private readonly IServiceRepository _serviceRepository;
        private ICallBackRepository _callBackRepository;
        private static readonly object _endpoint_lock = new object();

        public bool IsRunning { get; private set; }

        public Action<string> OnStart { get; set; }
        public Action<string> OnStop { get; set; }

        public BaseEndpoint Endpoint
        {
            get;
            set;
        }

        public event EventHandler<ComponentNotificationEventArgs> ComponentNotificationEvent;

        public event EventHandler<ComponentErrorEventArgs> ComponentErrorEvent;

        public ServiceBus(IKernel kernel,
            IScheduler scheduler,
            ISubscriptionRepository subscriptionRepository,
            IDispatcher dispatcher,
            IAgentManager agentManager,
            IServiceRepository serviceRepository)
        {
            _kernel = kernel;
            _scheduler = scheduler;
            _subscriptionRepository = subscriptionRepository;
            _dispatcher = dispatcher;
            _agentManager = agentManager;
            _serviceRepository = serviceRepository;
        }

        public TCOMPONENT Find<TCOMPONENT>()
        {
            TCOMPONENT theComponent = default(TCOMPONENT);

            if (_disposing == true) return theComponent;

            try
            {
                object aComponent = this.Find(typeof(TCOMPONENT));

                if (aComponent != null)
                {
                    theComponent = (TCOMPONENT)aComponent;
                }
            }
            catch
            {
            }

            return theComponent;
        }

        public object Find(Type component)
        {
            object theComponent = null;

            if (_disposing == true) return null;

            try
            {
                theComponent = _kernel.Resolve(component);
            }
            catch
            {
            }

            return theComponent;
        }

        public ICollection<TCOMPONENT> FindAll<TCOMPONENT>()
        {
            ICollection<TCOMPONENT> components = new List<TCOMPONENT>();

            if (_disposing == true) return null;

            try
            {
                var theComponents = _kernel.ResolveAll<TCOMPONENT>();

                foreach (TCOMPONENT component in theComponents)
                {
                    components.Add(component);
                }
            }
            catch
            {

            }

            return components;
        }

        public TTYPETOCREATE Create<TTYPETOCREATE>()
        {
            TTYPETOCREATE theType = default(TTYPETOCREATE);

            if (_disposing == true) return theType;

            theType = _kernel.Resolve<TTYPETOCREATE>();

            return theType;
        }

        public object Create(Type theType)
        {
            if (_disposing == true) return null;

            return _kernel.Resolve(theType);
        }

        public void Subscribe<TMESSAGE>() where TMESSAGE : IMessage
        {
            if (_disposing == true) return;

            // this is a dynamic subscription that should be 
            // removed when not needed any more for the bus:
            ISubscription subscription = new Subscription();
            subscription.Component = "{N/A}";
            subscription.Message = typeof(TMESSAGE).FullName;
            subscription.IsActive = true;
            subscription.Uri = this.Endpoint.Address.Uri;
            _subscriptionRepository.Register(subscription);
        }

        public void Publish<TMESSAGE>(TMESSAGE message) where TMESSAGE : IMessage
        {
            if (_disposing == true) return;

            List<IMessage> messages = new List<IMessage>();
            messages.Add(message);
            this.PublishInternal(messages.ToArray());
        }

        public void Publish(params IMessage[] messages)
        {
            if (_disposing == true) return;

            this.PublishInternal(messages);
        }

        public void Publish<TMESSAGE>(string endpoint, TMESSAGE message) where TMESSAGE : IMessage
        {
            if (_disposing == true) return;

            List<IMessage> messages = new List<IMessage>();
            messages.Add(message);

            GuardOnBatchLimit(messages);

            IEndpointAdapter adapter = this.Find<IEndpointAdapter>();

            Stream theStream = this.Find<ISerializationProvider>().SerializeToStream(message);

            IEnvelope envelope = new Envelope(theStream);
            envelope.AddHeader(Headers.MESSAGE_NAME, message.GetType().Name);
            envelope.AddHeader(Headers.MESSAGE_TYPE, message.GetType().FullName);

            adapter.GetEndpoint(endpoint).Send(envelope);

            if (this.Endpoint != null)
            {
                EndpointMessageSentMessage msg =
                    new EndpointMessageSentMessage(string.Empty, this.Endpoint.Address.Uri, message);
                this.DeliverToComponent(msg);
            }
        }

    	public IEndpoint GetEndpoint(string name)
    	{
    		IEndpoint endpoint = null;

    		endpoint = (from service in this._serviceRepository.Services
    		            where service.Endpoint.Name.Trim().ToLower() == name.Trim().ToLower()
    		            select service.Endpoint).FirstOrDefault();

    		return endpoint;
    	}

    	public ICallback Send(IMessage message)
        {
            return new MessageBusCallback(this, this._callBackRepository, message.GetType(), message);
        }

        public void Reply(IMessage message)
        {
            ComponentNotificationEventArgs notificationEventArgs;
            ICallback callback = _callBackRepository.Find(message.GetType());

            if (callback != null)
            {
                try
                {
                    notificationEventArgs = new ComponentNotificationEventArgs(NotificationLevel.Info,
                        string.Format("Invoking call back '{0}' for request '{1}' with reply '{2}'.",
                            callback.Callback.Method.Name,
                            callback.RequestMessage.Name,
                            callback.ReplyMessage.Name));

                    OnBusNotification(notificationEventArgs);

                    callback.Callback(message);
                }
                catch (Exception ex)
                {
                    notificationEventArgs = new ComponentNotificationEventArgs(NotificationLevel.Warn,
                     string.Format("Error invoking call back '{0}' for request '{1}' with reply '{2}'. Reason: {3} , Stack Trace : {4} ",
                            callback.Callback.Method.Name,
                            callback.RequestMessage.Name,
                            callback.ReplyMessage.Name,
                            ex.Message,
                            ex.StackTrace));
                    OnBusNotification(notificationEventArgs);
                }
            }
            else
            {
                notificationEventArgs = new ComponentNotificationEventArgs(NotificationLevel.Warn,
                     string.Format("No call back was registered for a request with reply of '{0}'. Reply not delivered...",
                            message.GetType().Name));
                OnBusNotification(notificationEventArgs);
            }
        }

        public void Start()
        {
            if (this.IsRunning == true)
            {
                return;
            }

            try
            {
                // initialize the components:
                IEndpointRegistry registry = this.Find<IEndpointRegistry>();
                this.Endpoint = registry.Find(Constants.MESSAGE_BUS_ENDPOINT_NAME);
                this.Endpoint.Transport.IsRecoverable = true;

                this.RefreshEndpoint(true);
                this.RefreshAgents(true);
                this.RefreshServices(true);
                this.RefreshScheduler(true);

                this._callBackRepository = new CallBackRepository();

            }
            catch (Exception e)
            {
                if (!OnBusError(e))
                    throw;
            }

            this.IsRunning = true;

            if (this.OnStart != null)
            {
                this.OnStart("Bus Started");
            }

            this.OnComponentStarted(this, new ComponentStartedEventArgs("Bus"));

            this.Publish(new BusStartedMessage());
        }

        public void Stop()
        {
            try
            {
                if (this.IsRunning == true)
                {
                    this.Publish(new BusStoppingMessage());

                    // terminate the components:

                    try
                    {
                        this.RefreshEndpoint(false);
                    }
                    catch (Exception e)
                    {
                        Exception endpointStopException =
                            new Exception("An error has ocurred while attemption to stop the endpoint for the message bus on " + this.Endpoint.Address.Uri + ". Reason: " + e.ToString());

                        if (!OnBusError(endpointStopException))
                            throw;
                    }

                    this.RefreshAgents(false);
                    this.RefreshScheduler(false);
                    this.RefreshServices(false);

                    if (this.OnStop != null)
                    {
                        this.OnStop("Bus Stopped");
                    }

                    this.OnComponentStopped(this, new ComponentStoppedEventArgs("Bus"));

                }
            }
            catch (Exception e)
            {
                if (!OnBusError(e))
                    throw;
            }
            finally
            {
                this.IsRunning = false;
            }

        }

        public void Dispose()
        {
            this.Stop();
            GC.SuppressFinalize(this);
        }

        private void RefreshEndpoint(bool isStarting)
        {
            if (this.Endpoint == null)
            {
                return;
            }

            if (isStarting == true)
            {
                lock (_endpoint_lock)
                {
                    this.Endpoint.EndpointMessageReceived += OnMessageReceived;
                    this.Endpoint.ComponentErrorEvent += OnComponentError;
                    this.Endpoint.ComponentStartedEvent += OnComponentStarted;
                    this.Endpoint.ComponentStoppedEvent += OnComponentStopped;
                    this.Endpoint.Start();
                }
            }
            else
            {
                lock (_endpoint_lock)
                {
                    if (this.Endpoint == null) return;

                    this.Endpoint.Stop();
                    this.Endpoint.EndpointMessageReceived -= OnMessageReceived;
                    this.Endpoint.ComponentErrorEvent -= OnComponentError;
                    this.Endpoint.ComponentStartedEvent -= OnComponentStarted;
                    this.Endpoint.ComponentStoppedEvent -= OnComponentStopped;
                    this.Endpoint = null;
                }
            }

        }

        private void RefreshServices(bool isStarting)
        {
            foreach (BaseService service in _serviceRepository.Services)
            {
                if (isStarting == true)
                {
                    service.OnServiceMessageReceived += OnMessageReceived;
                    service.ComponentErrorEvent += OnComponentError;
                    service.ComponentStartedEvent += OnComponentStarted;
                    service.ComponentStoppedEvent += OnComponentStopped;
                    service.Start();
                }
                else
                {
                    service.Stop();
                    service.OnServiceMessageReceived += OnMessageReceived;
                    service.ComponentErrorEvent += OnComponentError;
                    service.ComponentStartedEvent += OnComponentStarted;
                    service.ComponentStoppedEvent += OnComponentStopped;
                }
            }
        }

        private void RefreshAgents(bool isStarting)
        {
            if (isStarting == true)
            {
                _agentManager.ComponentErrorEvent += OnComponentError;
                _agentManager.ComponentStartedEvent += OnComponentStarted;
                _agentManager.ComponentStoppedEvent += OnComponentStopped;
                _agentManager.Start();
            }
            else
            {
                _agentManager.Stop();
                _agentManager.ComponentErrorEvent -= OnComponentError;
                _agentManager.ComponentStartedEvent -= OnComponentStarted;
                _agentManager.ComponentStoppedEvent -= OnComponentStopped;
            }
        }

        private void RefreshScheduler(bool isStarting)
        {
            if (isStarting == true)
            {
                _scheduler.ComponentNotificationEvent += OnComponentNotification;
                _scheduler.ComponentErrorEvent += OnComponentError;

                if (_scheduler.IsRunning == false)
                {
                    // TODO: look at this for implementiing heartbeats...
                    _scheduler.OnMessageReceived = (message) => this.RouteScheduledMessage(message);
                    _scheduler.Start();
                }
            }
            else
            {
                if (_scheduler.IsRunning == true)
                {
                    _scheduler.OnMessageReceived = null;
                    _scheduler.Stop();
                }

                _scheduler.ComponentNotificationEvent -= OnComponentNotification;
                _scheduler.ComponentErrorEvent -= OnComponentError;
            }
        }

        private void RouteScheduledMessage(IMessage message)
        {
            if (message is EndpointHeartBeatMessage)
            {
                this.Publish(
                    ((EndpointHeartBeatMessage)message).EndpointUri,
                    message);
            }
            else
            {
                this.Publish(message);
            }
        }

        /// <summary>
        /// This will ensure that a message batch or a collection on a message does 
        /// not exceed the pre-set limit for itemized collection passing on the bus instance.
        /// </summary>
        /// <param name="messages">Collection to inspect for exceeding batch limit</param>
        private static void GuardOnBatchLimit(ICollection<IMessage> messages)
        {
            if (messages.Count > MESSAGE_BATCH_SIZE)
            {
                throw new MessageBatchExceededException();
            }

            foreach (IMessage message in messages)
            {
                IEnumerable<PropertyInfo> collectionProperties =
                        (from property in message.GetType().GetProperties()
                         where typeof(IEnumerable).IsAssignableFrom(
                                   property.PropertyType)
                         select property).ToList();

                foreach (PropertyInfo property in collectionProperties)
                {
                    ICollection collection = null;

                    try
                    {
                        collection = (ICollection)property.GetValue(message, null);
                    }
                    catch
                    {
                        continue;
                    }

                    if (collection != null)
                    {
                        if (collection.Count > MESSAGE_BATCH_SIZE)
                        {
                            throw new MessageBatchExceededForMessageException(message);
                        }
                    }

                }

            }
        }

        /// <summary>
        /// This will send the message out to the intended parties for processing.
        /// </summary>
        /// <param name="messages">Collection of messages to send.</param>
        private void PublishInternal(IEnumerable<IMessage> messages)
        {
            GuardOnBatchLimit(new List<IMessage>(messages));

            foreach (IMessage message in messages)
            {
                this.DeliverToEndpoint(message);
            }
        }

        /// <summary>
        /// This will find the correct endpoint where the message 
        /// can be consumed and subsequently the message is sent
        /// to the endpoint according to the endpoint semantics.
        /// </summary>
        /// <param name="message"></param>
        private void DeliverToEndpoint(IMessage message)
        {
            // at this point, a component has issued a request to send a message
            // out to the endpoint for all interested components to pick-up and 
            // process, we need to find all of the parties that are interested in receiving 
            // the message via the subscription repository:
            if (typeof(IAdminMessage).IsAssignableFrom(message.GetType()))
            {
                // do not dispatch the messge to the physical endpoint 
                // if it is an internal admin message, this will create a 
                // a recursive loop of receiving and sending on the endpoint,
                // just push it to the service component that can handle the message:
                this.DeliverToComponent(message);
            }
            else
            {
                this.InvokeServiceForSend(message);
            }
        }

        /// <summary>
        /// This will find the correct message handling component 
        /// and dispatch the message directly to it.
        /// </summary>
        /// <param name="message"></param>
        private void DeliverToComponent(IMessage message)
        {
            IEnumerable<IConsumer> handlers = GetHandlersForMessage(message);

            foreach (IConsumer handler in handlers)
            {
                _dispatcher.Dispatch(this, handler, message);
            }
        }

        /// <summary>
        /// This will take the current messaging envelope and 
        /// use the service message pipeline to change the message
        /// into the appropriate format for dispatching to the component 
        /// for consumption.
        /// </summary>
        /// <param name="envelope">Envelope to send to service for dispatch.</param>
        private void InvokeServiceForReceive(IEnvelope envelope)
        {
            IMessage message;
            BaseService service = this.FindServiceForUri(envelope.GetHeader<string>(Headers.ENDPOINT_URI));

            if (service != null)
            {
                // convert the message according to the service pipeline:
                try
                {
                    envelope = service.InvokeForReceive(envelope);
                    message = envelope.GetPayload<IMessage>();
                }
                catch (Exception e)
                {
                    OnBusNotification(new ComponentNotificationEventArgs(NotificationLevel.Warn, e.ToString()));
                    throw;
                }

                // dispatch the message to the handlers:
                DeliverToComponent(message);
            }
        }

        /// <summary>
        /// This will take the current native message implemenation 
        /// and find the correct service implemenation to transform 
        /// the message into the appropriate transmission format 
        /// for delivery to the service endpoint(s) via the subscription
        /// repository.
        /// </summary>
        /// <param name="message">Message to send to a service endpoint.</param>
        private void InvokeServiceForSend(IMessage message)
        {
            // must use the subscription service to determine
            // which service endpoint uri to select for message
            // transformation into the appropriate wire format:

            ICollection<BaseService> services = FindServicesForMessage(message);

            if (services.Count == 0)
            {
                // must send the message to the global subscription manager to deliver the message on our behalf:
                System.Diagnostics.Debug.Assert(false, "Need to forward the message to the global publisher...");
            }
            else
            {
                // invoke the custom pipeline for the service and send the message to the designated endpoint:   
                IEndpointAdapter adapter = this.Find<IEndpointAdapter>();

                foreach (var service in services)
                {
                    IEnvelope envelope = new Envelope(message);

                    envelope = service.InvokeForSend(envelope);
                    adapter.GetEndpoint(service.Endpoint.Address.Uri).Send(envelope);

                    if (this.Endpoint != null)
                    {
                        EndpointMessageSentMessage msg =
                            new EndpointMessageSentMessage(string.Empty, service.Endpoint.Address.Uri, message);
                        this.DeliverToComponent(msg);
                    }

                }
            }
        }

        private BaseService FindServiceForUri(string uri)
        {
            IServiceRepository repository = this.Find<IServiceRepository>();
            BaseService service = repository.FindByUri(uri);
            return service;
        }

        private IEnumerable<IConsumer> GetHandlersForMessage(IMessage message)
        {
            List<IConsumer> theHandlers = new List<IConsumer>();

            IEnumerable<IConsumer> consumers = _kernel.ResolveAll<IConsumer>();

            foreach (var consumer in consumers)
            {
                MessageToMethodMapper mapper = new MessageToMethodMapper();
                MethodInfo method = mapper.Map(consumer, message);

                if (method != null)
                {
                    if (theHandlers.Contains(consumer) == false)
                    {
                        theHandlers.Add(consumer);
                    }
                }
            }

            return theHandlers;
        }

        private ICollection<BaseService> FindServicesForMessage(IMessage message)
        {
            var theServices = new List<BaseService>();
            var theHandlers = this.GetHandlersForMessage(message);

            foreach (var service in _serviceRepository.Services)
            {
                foreach (var theHandler in theHandlers)
                {
                    var theConsumer = service.Consumers.FirstOrDefault(x => x == theHandler.GetType());

                    if (theConsumer != null)
                    {
                        if (theServices.Contains(service) == false)
                        {
                            theServices.Add(service);
                        }
                    }
                }
            }

            return theServices;
        }

        /// <summary>
        /// This is the event handler that is connected to the bus endpoint instance 
        /// to process any message that is sent to the bus for possible multi-component 
        /// consumption for internal message bus message consumers.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnMessageReceived(object sender, EndpointMessageReceivedEventArgs e)
        {
            EndpointMessageReceivedMessage msg =
                           new EndpointMessageReceivedMessage(string.Empty, e.Endpoint.Address.Uri, e.Envelope);
            DeliverToComponent(msg);
            //DeliverToComponent(e.Envelope);
        }

        /// <summary>
        /// This is the callback that is attached to every service endpoint instance 
        /// <seealso cref="RefreshServices"/> that will relay the received message 
        /// to the message bus for possible multi-component consumption.
        /// </summary>
        /// <param name="envelope">Envelope containing a <see cref="Stream"/>payload from the endpoint location.</param>
        private void OnMessageReceived(IEnvelope envelope)
        {
            string uri = envelope.GetHeader<string>(Headers.ENDPOINT_URI);
            EndpointMessageReceivedMessage msg =
                           new EndpointMessageReceivedMessage(string.Empty, uri, envelope);
            DeliverToComponent(msg);
            InvokeServiceForReceive(envelope);
        }

        private void OnBusNotification(ComponentNotificationEventArgs args)
        {
            EventHandler<ComponentNotificationEventArgs> evt = this.ComponentNotificationEvent;

            if (evt != null)
            {
                evt(this, args);
            }
            else
            {
                ILogger logger = this.Find<ILogger>();

                if (logger == null) return;

                switch (args.Level)
                {
                    case NotificationLevel.Debug:
                        logger.LogDebugMessage(args.Message);
                        break;
                    case NotificationLevel.Info:
                        logger.LogInfoMessage(args.Message);
                        break;
                    case NotificationLevel.Warn:
                        logger.LogWarnMessage(args.Message);
                        break;
                }
            }
        }

        private void OnComponentNotification(object sender, ComponentNotificationEventArgs e)
        {
            this.OnBusNotification(e);
        }

        private void OnComponentStarted(object sender, ComponentStartedEventArgs e)
        {
            string message = string.Format("Component '{0}' started.", e.ComponentName);
            ComponentNotificationEventArgs args =
                new ComponentNotificationEventArgs(NotificationLevel.Debug, message);

            this.OnBusNotification(args);
        }

        private void OnComponentStopped(object sender, ComponentStoppedEventArgs e)
        {
            string message = string.Format("Component '{0}' stopped.", e.ComponentName);
            ComponentNotificationEventArgs args = new ComponentNotificationEventArgs(NotificationLevel.Debug, message);

            this.OnBusNotification(args);
        }

        private bool OnBusError(Exception exception)
        {
            EventHandler<ComponentErrorEventArgs> evt = this.ComponentErrorEvent;

            bool isHandlerAttached = (evt != null);

            if (isHandlerAttached)
                evt(this, new ComponentErrorEventArgs(exception));

            ILogger logger = this.Find<ILogger>();

            if (logger != null)
            {
                logger.LogErrorMessage(exception.Message, exception);
            }

            return isHandlerAttached;
        }

        private void OnComponentError(object sender, ComponentErrorEventArgs e)
        {
            this.OnBusError(e.Exception);
        }
    }
}