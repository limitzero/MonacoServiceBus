using Monaco.Internals.Eventing;
using Monaco.Transport;

namespace Monaco.Pipeline
{
    /// <summary>
    /// Contract for an intermediary step in a message processing pipeline.
    /// </summary>
    public interface IPipelineFilter : IStartableEventBroadcaster
    {
        /// <summary>
        /// Gets or sets the name of the filter.
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// Gets or sets a flag indicating whether or not to apply the effects
        /// of the filter on the current chain of message transformations on 
        /// the current pipeline containing the filter.
        /// </summary>
        bool IsSkipped { get; set; }

        /// <summary>
        /// Gets or sets the instance of the local message bus instance.
        /// </summary>
        IServiceBus Bus { get; set; }

        /// <summary>
        /// This will execute the filter logic and return the common 
        /// messaging envelope containing the payload of the data 
        /// to send to the corresponding message consumer(s).
        /// </summary>
        /// <param name="envelope"></param>
        /// <returns></returns>
        IEnvelope Execute(IEnvelope envelope);
    }
}