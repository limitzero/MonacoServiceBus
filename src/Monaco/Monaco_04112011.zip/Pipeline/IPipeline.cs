using System.Collections.Generic;
using System.IO;
using Monaco.Exceptions;
using Monaco.Internals.Eventing;
using Monaco.Transport;

namespace Monaco.Pipeline
{
    /// <summary>
    /// Contract for a basic message handling pipeline from and to an endpoint.
    /// </summary>
    public interface IPipeline : IStartableEventBroadcaster, IErrorEventBroadcaster
    {
        /// <summary>
        /// Gets or sets a name for the messaging pipeline.
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// Gets or sets the uri of the endpoint where this pipeline 
        /// will be applied upon message receipt or delivery to/from 
        /// an endpoint.
        /// </summary>
        string EndpointUri { get; set; }

        /// <summary>
        /// Gets the collection of filters used when a message is received from an endpoint.
        /// </summary>
        ICollection<IPipelineFilter> ReceiveFilters { get; }

        /// <summary>
        /// Gets the collection of filters used when a message is delivered to an endpoint.
        /// </summary>
        ICollection<IPipelineFilter> SendFilters { get; }

        /// <summary>
        /// Gets the collection of filters that successfully executed.
        /// </summary>
        ICollection<IPipelineFilter> ExecutedFilters { get; }

        /// <summary>
        /// Gets or sets the flag to indicate whether or not to stop the 
        /// processing pipeline if a filter generates an exception.
        /// </summary>
        bool HaltOnError { get; set; }

        /// <summary>
        /// This will register the series of filters that will be executed against the message
        /// when the message is received from the endpoint into the message bus before
        /// delivery to the component for processing. The final envelope message payload 
        /// must be derivable from the <seealso cref="IMessage"/> interface in order for 
        /// </summary>
        /// <param name="filters"></param>
        void RegisterReceiveFilters(params IPipelineFilter[] filters);

        /// <summary>
        /// This will register a series of filters that will be executed against the message
        /// payload in the envelope when the message is slated to be delivered to an 
        /// endpoint. The final envelope message payload from these series of filters
        /// must be a  <see cref="Stream"/> object for agnostic message delivery 
        /// to the endpoint.
        /// </summary>
        /// <param name="filters"></param>
        void RegisterSendFilters(params IPipelineFilter[] filters);

        /// <summary>
        ///  This will execute the pipeline on receiving the message
        ///  from an endpoint or sending a message to an endpoint.
        /// </summary>
        /// <exception cref="InvalidPipelineMessageOnReceiveException"/>
        /// <exception cref="InvalidPipelineMessageOnSendException"/>
        IEnvelope Execute(PipelineDirection direction, IServiceBus bus, IEnvelope envelope);
    }
}