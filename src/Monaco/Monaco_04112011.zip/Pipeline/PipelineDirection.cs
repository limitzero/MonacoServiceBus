namespace Monaco.Pipeline
{
    public enum PipelineDirection
    {
        Receive,
        Send,
    }
}