namespace Monaco.Pipeline.Impl.Pipelines.Default
{
    /// <summary>
    /// Default pipeline used by the service configuration 
    /// to construct the differing filters that will be 
    /// needed to transform the message on sending 
    /// and receiving from an indicating endpoint.
    /// </summary>
    public class DefaultPipeline : BasePipeline
    {
        public DefaultPipeline()
        {
            this.Name = "Default Pipeline";
        }
    }
}