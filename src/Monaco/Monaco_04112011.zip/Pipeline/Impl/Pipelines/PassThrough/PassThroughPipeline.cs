using Monaco.Transport;

namespace Monaco.Pipeline.Impl.Pipelines.PassThrough
{
    public class PassThroughPipeline : BasePipeline
    {
        public PassThroughPipeline()
        {
            this.Name = "Pass-through Pipeline";
        }

        public override void Initialize()
        {
            this.RegisterReceiveFilters(new PassThroughReceiveFilter());
            this.RegisterSendFilters(new PassThroughSendFilter());
        }
    }

    public class PassThroughReceiveFilter : BasePipelineFilter
    {
        public override IEnvelope DoExecute(IEnvelope envelope)
        {
            return envelope;
        }
    }

    public class PassThroughSendFilter : BasePipelineFilter
    {
        public override IEnvelope DoExecute(IEnvelope envelope)
        {
            return envelope;
        }
    }

}