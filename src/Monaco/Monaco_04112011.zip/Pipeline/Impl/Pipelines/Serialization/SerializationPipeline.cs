using Monaco.Pipeline.Impl.Pipelines.Serialization.Filters;

namespace Monaco.Pipeline.Impl.Pipelines.Serialization
{
    /// <summary>
    /// Default pipeline used for serialization/de-serialization of messages.
    /// </summary>
    public class SerializationPipeline : BasePipeline
    {
        public override void Initialize()
        {
            this.HaltOnError = true;
            this.Name = "Serialization Pipeline";
            base.RegisterReceiveFilters(new DeserializeFilter());
            base.RegisterSendFilters(new SerializeFilter());
        }
    }
}