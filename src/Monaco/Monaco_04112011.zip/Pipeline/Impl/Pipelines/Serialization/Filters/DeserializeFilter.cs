using System;
using System.IO;
using Monaco.Internals.Logging;
using Monaco.Internals.Serialization;
using Monaco.Transport;

namespace Monaco.Pipeline.Impl.Pipelines.Serialization.Filters
{
    public class DeserializeFilter : BasePipelineFilter
    {
        public DeserializeFilter()
        {
            this.Name = "Deserialize Filter";
        }

        public override IEnvelope DoExecute(IEnvelope envelope)
        {
            string contents = string.Empty;

            var logger = this.Bus.Find<ILogger>();
            var stream = envelope.GetPayload<Stream>();

            contents = this.ReadStream(stream);

            logger.LogDebugMessage(string.Format("Start: deserializing message '{0}'.", contents));

            object theMessage = this.Bus.Find<ISerializationProvider>().Deserialize(contents);
            IMessage message = theMessage as IMessage;
            envelope.ChangePayload(message);

            logger.LogDebugMessage(string.Format("End: deserializing message '{0}'.", contents));

            return envelope;
        }
    }
}