using System;
using System.IO;
using Monaco.Internals.Logging;
using Monaco.Internals.Serialization;
using Monaco.Transport;

namespace Monaco.Pipeline.Impl.Pipelines.Serialization.Filters
{
    public class SerializeFilter : BasePipelineFilter
    {
        public SerializeFilter()
        {
            this.Name = "Serialize Filter";
        }

        public override IEnvelope DoExecute(IEnvelope envelope)
        {
            var serializer = this.Bus.Find<ISerializationProvider>();
            var logger = this.Bus.Find<ILogger>();

            if (serializer != null)
            {
                var theObject = envelope.GetPayload<object>();

                if(theObject == null)
                    throw new ArgumentException("Cannot serialize null envelope payload.");

                logger.LogDebugMessage(string.Format("Start: serializing message '{0}'.", theObject.GetType().FullName));

                byte[] theBytes = serializer.SerializeToBytes(theObject);
                MemoryStream stream = this.WriteStream(theBytes);

                envelope.ChangePayload(stream);

                logger.LogDebugMessage(string.Format("End: serializing message '{0}'.", theObject.GetType().FullName));
            }

            return envelope;
        }
    }
}