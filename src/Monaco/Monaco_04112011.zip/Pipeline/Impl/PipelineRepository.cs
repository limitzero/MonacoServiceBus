using System.Linq;
using Monaco.Exceptions;
using Monaco.Internals.Collections;

namespace Monaco.Pipeline.Impl
{
    public class PipelineRepository : IPipelineRepository
    {
        private bool _disposing;
        private static readonly object _repository_lock = new object();
        private static IThreadSafeDictionary<string, BasePipeline> _repository;

        public PipelineRepository()
        {
            if(_repository == null)
            {
                _repository = new ThreadSafeDictionary<string, BasePipeline>();
            }
        }

        public BasePipeline Find(string uri)
        {
            if (_disposing == true)
            {
                throw new DisposingException();
            }

            lock(_repository_lock)
            {
                BasePipeline thePipeline = (from pipeline in _repository
                                            where pipeline.Key.Trim().ToLower() == uri.Trim().ToLower()
                                            select pipeline.Value).FirstOrDefault();

                return thePipeline;
            }
        }

        public void Register(string uri, BasePipeline pipeline)
        {
            if(_disposing == true)
            {
                throw new DisposingException();
            }

            lock(_repository_lock)
            {
                _repository.Add(uri, pipeline);
            }
        }

        public void Dispose()
        {
            _disposing = true;
            if(_repository != null)
            {
                _repository.Clear();
                _repository = null;
            }
        }
    }
}