using System;

namespace Monaco.Pipeline
{
    /// <summary>
    /// Contract for storing all message handling pipelines 
    /// that are constructed per message endpoint uri 
    /// for handling a message when it arrives from 
    /// an endpoint or when it is delivered to an endpoint.
    /// </summary>
    public interface IPipelineRepository : IDisposable
    {
        /// <summary>
        /// This will find a <seealso cref="BasePipeline">pipeline</seealso>
        /// instance from a specific uri endpoint declaration.
        /// </summary>
        /// <param name="uri">The uri to which a pipeline implementation will be applied</param>
        /// <returns></returns>
        BasePipeline Find(string uri);

        /// <summary>
        /// This will register a pipeline implementation in the
        /// repository for a particular endpoint uri specification
        /// </summary>
        /// <param name="uri">The endpoint uri on which the pipeline implementation will be applied</param>
        /// <param name="pipeline">The pipeline instance to apply on message receipt and delivery</param>
        void Register(string uri, BasePipeline pipeline);
    }
}