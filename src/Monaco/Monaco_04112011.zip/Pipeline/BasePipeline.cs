using System;
using System.Collections.Generic;
using System.IO;
using Monaco.Exceptions;
using Monaco.Internals.Eventing;
using Monaco.Pipeline.Impl.Pipelines.PassThrough;
using Monaco.Transport;

namespace Monaco.Pipeline
{
    /// <summary>
    /// Base class implementing the common functionality 
    /// of a pre and post processing messaging pipeline.
    /// </summary>
    public abstract class BasePipeline : IPipeline
    {
        public string Name { get; set; }

        public string EndpointUri { get; set; }

        public bool HaltOnError { get; set; }

        public ICollection<IPipelineFilter> ReceiveFilters { get; private set; }

        public ICollection<IPipelineFilter> SendFilters { get; private set; }

        public ICollection<IPipelineFilter> ExecutedFilters { get; private set; }

        public event EventHandler<ComponentStartedEventArgs> ComponentStartedEvent;

        public event EventHandler<ComponentStoppedEventArgs> ComponentStoppedEvent;

        public event EventHandler<ComponentErrorEventArgs> ComponentErrorEvent;

        protected BasePipeline()
        {
            this.ReceiveFilters = new List<IPipelineFilter>();
            this.SendFilters = new List<IPipelineFilter>();
            this.ExecutedFilters = new List<IPipelineFilter>();
            this.Initialize();
        }

        /// <summary>
        /// This is the point where the concrete instance of the pipeline 
        /// can be auto-initialized with the desired pipeline filters.
        /// </summary>
        public virtual void Initialize()
        {
        }

        public void RegisterReceiveFilters(params IPipelineFilter[] filters)
        {
            foreach (IPipelineFilter filter in filters)
            {
                this.ReceiveFilters.Add(filter);
            }
        }

        public void RegisterSendFilters(params IPipelineFilter[] filters)
        {
            foreach (IPipelineFilter filter in filters)
            {
                this.SendFilters.Add(filter);
            }
        }

        public IEnvelope Execute(PipelineDirection direction, IServiceBus bus, IEnvelope envelope)
        {
            IEnvelope theEnvelope = envelope;

            OnPipelineStarted();

            try
            {
                this.ExecutedFilters.Clear();

                if (direction == PipelineDirection.Receive)
                {
                    if (this.ReceiveFilters.Count == 0)
                        throw new Exception("There were no received filters specified for the pipeline.");

                    theEnvelope = this.ExecuteReceivePipeline(bus, envelope);
                }
                else
                {
                    if (this.SendFilters.Count == 0)
                        throw new Exception("There were no send filters specified for the pipeline.");

                    theEnvelope = this.ExecuteSendPipeline(bus, envelope);
                }
            }
            catch (Exception e)
            {
                throw;
            }

            OnPipelineCompleted();

            return theEnvelope;
        }

        private IEnvelope ExecuteReceivePipeline(IServiceBus bus, IEnvelope envelope)
        {
            IEnvelope theEnvelope = this.ExecutePipeline(this.ReceiveFilters, bus, envelope);

            if (this.HaltOnError == false)
            {
                if (!(this is PassThroughPipeline))
                {
                    if (typeof(IMessage).IsAssignableFrom(theEnvelope.GetPayload<object>().GetType()) == false)
                    {
                        throw new InvalidPipelineMessageOnReceiveException(theEnvelope.GetPayload<object>());
                    }
                }
            }

            return theEnvelope;
        }

        private IEnvelope ExecuteSendPipeline(IServiceBus bus, IEnvelope envelope)
        {
            IEnvelope theEnvelope = this.ExecutePipeline(this.SendFilters, bus, envelope);

            if (this.HaltOnError == false)
            {
                if (!(this is PassThroughPipeline))
                {
                    if (typeof(Stream).IsAssignableFrom(theEnvelope.GetPayload<object>().GetType()) == false)
                    {
                        throw new InvalidPipelineMessageOnSendException(theEnvelope.GetPayload<object>());
                    }
                }
            }

            return theEnvelope;
        }

        private IEnvelope ExecutePipeline(IEnumerable<IPipelineFilter> filters, IServiceBus bus, IEnvelope envelope)
        {
            IEnvelope theEnvelope = envelope;

            foreach (IPipelineFilter filter in filters)
            {
                filter.ComponentStartedEvent += OnFilterStarted;
                filter.ComponentStoppedEvent += OnFilterCompleted;

                try
                {
                    filter.Bus = bus;
                    theEnvelope = filter.Execute(theEnvelope);
                    this.ExecutedFilters.Add(filter);
                }
                catch (Exception e)
                {
                    if (this.HaltOnError == false)
                    {
                        continue;
                    }
                    else
                    {
                        throw;
                    }
                }
                finally
                {
                    filter.ComponentStartedEvent -= OnFilterStarted;
                    filter.ComponentStoppedEvent -= OnFilterCompleted;
                }
            }

            return theEnvelope;
        }

        private void OnPipelineStarted()
        {
            EventHandler<ComponentStartedEventArgs> evt = this.ComponentStartedEvent;

            if (evt != null)
            {
                evt(this, new ComponentStartedEventArgs(this.Name));
            }
        }

        private void OnPipelineCompleted()
        {
            EventHandler<ComponentStoppedEventArgs> evt = this.ComponentStoppedEvent;

            if (evt != null)
            {
                evt(this, new ComponentStoppedEventArgs(this.Name));
            }
        }

        private bool OnPipelineError(Exception exception)
        {
            EventHandler<ComponentErrorEventArgs> evt = this.ComponentErrorEvent;
            bool isHandlerAttached = (evt != null);

            if (isHandlerAttached == true)
            {
                evt(this, new ComponentErrorEventArgs(exception));
            }

            return isHandlerAttached;
        }

        private void OnFilterStarted(object sender, ComponentStartedEventArgs args)
        {
            EventHandler<ComponentStartedEventArgs> evt = this.ComponentStartedEvent;

            if (evt != null)
            {
                evt(this, args);
            }
        }

        private void OnFilterCompleted(object sender, ComponentStoppedEventArgs args)
        {
            EventHandler<ComponentStoppedEventArgs> evt = this.ComponentStoppedEvent;

            if (evt != null)
            {
                evt(this, args);
            }
        }
    }
}