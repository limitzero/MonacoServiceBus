using System;
using System.IO;
using Monaco.Internals.Eventing;
using Monaco.Transport;

namespace Monaco.Pipeline
{
    /// <summary>
    /// Base class for implementing the basic invocation logic 
    /// of a <seealso cref="IPipelineFilter"/>.
    /// </summary>
    public abstract class BasePipelineFilter : IPipelineFilter
    {
        public event EventHandler<ComponentStartedEventArgs> ComponentStartedEvent;

        public event EventHandler<ComponentStoppedEventArgs> ComponentStoppedEvent;

        /// <summary>
        /// Gets or sets the name of the filter.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets a flag indicating whether or not to apply the effects
        /// of the filter on the current chain of message transformations on 
        /// the current pipeline containing the filter.
        /// </summary>
        public bool IsSkipped { get; set; }

        /// <summary>
        /// Gets or sets the instance of the local message bus instance.
        /// </summary>
        public IServiceBus Bus { get; set; }

        /// <summary>
        /// This will execute the filter logic and return the common 
        /// messaging envelope containing the payload of the data 
        /// to send to the corresponding message consumer(s).
        /// </summary>
        /// <param name="envelope"></param>
        /// <returns></returns>
        public IEnvelope Execute(IEnvelope envelope)
        {
            try
            {
                this.OnFilterStarted();
                envelope = this.DoExecute(envelope);
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                this.OnFilterCompleted();
            }

            return envelope;
        }

        /// <summary>
        /// This will invoke the user-defined logic for message transformation:
        /// </summary>
        /// <param name="envelope">Current messaging envelope containg the payload to transform.</param>
        /// <returns>
        /// A concrete instance of <seealso cref="IEnvelope"/> containing the adjusted payload.
        /// </returns>
        public abstract IEnvelope DoExecute(IEnvelope envelope);

        public string ReadStream(Stream  stream)
        {
            string contents = string.Empty;

            if(stream == null)
                throw new ArgumentException("No data stream present for reading.");

            using (stream)
            {
                stream.Seek(0, SeekOrigin.Begin);
                using (TextReader reader = new StreamReader(stream))
                {
                    contents = reader.ReadToEnd();
                }
            }

            return contents;
        }

        public MemoryStream WriteStream(byte[] bytes)
        {
            MemoryStream stream = new MemoryStream(bytes);
            stream.Seek(0, SeekOrigin.Begin);
            return stream;
        }

        private void OnFilterStarted()
        {
            EventHandler<ComponentStartedEventArgs> evt = this.ComponentStartedEvent;

            if (evt != null)
            {
                evt(this, new ComponentStartedEventArgs(this.Name));
            }
        }

        private void OnFilterCompleted()
        {
            EventHandler<ComponentStoppedEventArgs> evt = this.ComponentStoppedEvent;

            if (evt != null)
            {
                evt(this, new ComponentStoppedEventArgs(this.Name));
            }
        }
    }
}