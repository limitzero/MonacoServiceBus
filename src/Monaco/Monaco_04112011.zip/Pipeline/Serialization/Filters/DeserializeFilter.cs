using System.IO;
using Monaco.Internals.Serialization;
using Monaco.Transport;

namespace Monaco.Pipeline.Serialization.Filters
{
    public class DeserializeFilter : BasePipelineFilter
    {
        public DeserializeFilter()
        {
            Name = "Deserialize Filter";
        }

        public override IEnvelope DoExecute(IEnvelope envelope)
        {
            string contents = string.Empty;

            using (TextReader reader = new StreamReader(envelope.GetPayload<Stream>()))
            {
                contents = reader.ReadToEnd();
            }

            object theMessage = Bus.Find<ISerializationProvider>().Deserialize(contents);
            var message = theMessage as IMessage;
            envelope.ChangePayload(message);

            return envelope;
        }
    }
}