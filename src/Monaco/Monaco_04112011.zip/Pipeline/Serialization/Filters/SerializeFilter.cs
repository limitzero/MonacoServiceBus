using System.IO;
using Monaco.Internals.Serialization;
using Monaco.Transport;

namespace Monaco.Pipeline.Serialization.Filters
{
    public class SerializeFilter : BasePipelineFilter
    {
        public SerializeFilter()
        {
            Name = "Serialize Filter";
        }

        public override IEnvelope DoExecute(IEnvelope envelope)
        {
            var serializaer = Bus.Find<ISerializationProvider>();

            if (serializaer != null)
            {
                byte[] theBytes = serializaer.SerializeToBytes(envelope.GetPayload<object>());
                var stream = new MemoryStream(theBytes);
                envelope.ChangePayload(stream);
            }

            return envelope;
        }
    }
}