using Monaco.Pipeline.Serialization.Filters;

namespace Monaco.Pipeline.Serialization
{
    /// <summary>
    /// Default pipeline used for serialization/de-serialization of messages.
    /// </summary>
    public class SerializationPipeline : BasePipeline
    {
        public SerializationPipeline()
        {
            EndpointUri = "*://*";
            Name = "Serialization Pipeline";
            HaltOnError = true;
        }

        public override void Initialize()
        {
            base.RegisterReceiveFilters(new DeserializeFilter());
            base.RegisterSendFilters(new SerializeFilter());
        }
    }
}