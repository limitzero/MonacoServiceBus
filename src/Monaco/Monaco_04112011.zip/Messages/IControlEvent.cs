namespace Monaco.Messages
{
    /// <summary>
    /// An event denotes when something has happened in the 
    /// internal infrastructure that should be reported on or an 
    /// action take as a result of the corresponding event.
    /// </summary>
    public interface IEvent : IMessage
    {
        
    }
}