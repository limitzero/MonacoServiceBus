using System;

namespace Monaco.Messages
{
    [Serializable]
    public class SagaThread : IMessage
    {
        /// <summary>
        /// Gets or sets the instance identifier of the saga
        /// </summary>
        public Guid InstanceId { get; set; }

        /// <summary>
        /// Gets or sets the date and time the thread was created.
        /// </summary>
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the date and time the thread was modified.
        /// </summary>
        public DateTime? ModifiedOn { get; set; }

        /// <summary>
        /// Gets or sets the instance of the saga fully qualified type name.
        /// </summary>
        public string SagaName { get; set; }

        /// <summary>
        /// Gets or sets the binary form of the saga instance.
        /// </summary>
        public byte[] Instance { get; set; }

        public override bool Equals(object obj)
        {
            if (!(obj is SagaThread))
            {
                return false;
            }

             SagaThread that = (SagaThread)obj;
            if (this.InstanceId == null || that.InstanceId== null || !this.InstanceId.Equals(InstanceId))
            {
                return false;
            }
            return true;
        }

        public override int GetHashCode()
        {
            int hashCode = 0;
            hashCode = 29 * hashCode + (InstanceId== null ? 0 : InstanceId.GetHashCode());
            return hashCode;
        }
    }
}