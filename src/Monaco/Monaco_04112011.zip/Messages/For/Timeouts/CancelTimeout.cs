using System;

namespace Monaco.Messages.For.Timeouts
{
    [Serializable]
    public class CancelTimeout : IAdminMessage
    {
        /// <summary>
        /// Gets or sets the instance of the identifier for the timeout message
        /// that will be remove from the instance of registered timeouts.
        /// </summary>
        public Guid TimeoutId { get; set; }

        public CancelTimeout()
        {
            
        }

        public CancelTimeout(Guid timeoutId)
        {
            TimeoutId = timeoutId;
        }
    }
}