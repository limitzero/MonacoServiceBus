namespace Monaco.Messages.For.Endpoints
{
    public class EndpointHealthRecycleStatisticsMessage : IAdminMessage
    {
    }
}