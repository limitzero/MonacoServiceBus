using System;

namespace Monaco.Messages.For.Endpoints
{
    /// <summary>
    /// Message to inquire about the status of an endpoint on the message bus.
    /// </summary>
    [Serializable]
    public class EndpointsStatusInquiryMessage : IMessage
    {
        public string Originator { get; set; }
        public string EndpointUri { get; set;}
    }
}