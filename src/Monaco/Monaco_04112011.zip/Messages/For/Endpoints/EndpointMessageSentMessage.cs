using System;

namespace Monaco.Messages.For.Endpoints
{
    /// <summary>
    /// Message to record when an endpoint has sent a message. 
    /// </summary>
    [Serializable]
    public class EndpointMessageSentMessage : IAdminMessage
    {
        public string EndpointName { get; set; }
        public string EndpointUri { get; set; }
        public IMessage Message { get; set; }

        public EndpointMessageSentMessage()
        {
            
        }

        public EndpointMessageSentMessage(string endpointName, string endpointUri, IMessage message)
        {
            EndpointName = endpointName;
            EndpointUri = endpointUri;
            this.Message = message;
        }
    }
}