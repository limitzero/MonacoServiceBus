using System.Collections.Generic;
using Monaco.Endpoint.Health.Saga;

namespace Monaco.Messages.For.Endpoints
{
    public class EndpointStatusResultMessage : IMessage
    {
        public List<EndpointStatistic> Statistics { get; set; }

        public EndpointStatusResultMessage()
        {
            if(this.Statistics == null)
            {
                this.Statistics = new List<EndpointStatistic>();
            }
        }

        public void AddStatistics(params EndpointStatistic[] statistics)
        {
            this.Statistics.AddRange(statistics);
        }
    }
}