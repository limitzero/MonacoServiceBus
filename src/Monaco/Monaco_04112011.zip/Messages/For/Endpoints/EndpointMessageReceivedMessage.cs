using System;
using Monaco.Transport;

namespace Monaco.Messages.For.Endpoints
{
    /// <summary>
    /// Message to record when an endpoint has received a message from the physical location.
    /// </summary>
    [Serializable]
    public class EndpointMessageReceivedMessage : IAdminMessage
    {
        public string EndpointName { get; set; }
        public string EndpointUri { get; set; }
        public IEnvelope Envelope { get; set; }

        public EndpointMessageReceivedMessage()
        {
            
        }

        public EndpointMessageReceivedMessage(string endpointName, string endpointUri, IEnvelope envelope)
        {
            EndpointName = endpointName;
            EndpointUri = endpointUri;
            Envelope = envelope;
        }
    }
}