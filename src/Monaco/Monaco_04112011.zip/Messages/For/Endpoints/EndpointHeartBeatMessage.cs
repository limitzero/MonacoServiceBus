using System;

namespace Monaco.Messages.For.Endpoints
{
    [Serializable]
    public class EndpointHeartBeatMessage : IAdminMessage
    {
        public string Interval { get; set; }
        public string Period { get; set; }
        public string GracePeriod { get; set; }
        public string EndpointName { get; set; }
        public string EndpointUri { get; set; }
        public DateTime At { get; set; }
        public DateTime Received { get; set; }

        public EndpointHeartBeatMessage()
        {
            
        }

        public EndpointHeartBeatMessage(string endpointName, string uri, string interval, string period)
        {
            EndpointName = endpointName;
            EndpointUri = uri;
            Interval = interval;
            Period = period;
            At = DateTime.Now;
        }
    }
}