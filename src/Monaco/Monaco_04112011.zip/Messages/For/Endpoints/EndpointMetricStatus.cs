namespace Monaco.Messages.For.Endpoints
{
    public enum EndpointMetricStatus
    {
        Normal, 
        Suspect
    }
}