namespace Monaco.Messages.For.Endpoints
{
    public class BroadcastStatusForAllEndpointsMessage : IAdminMessage
    {
    }
}