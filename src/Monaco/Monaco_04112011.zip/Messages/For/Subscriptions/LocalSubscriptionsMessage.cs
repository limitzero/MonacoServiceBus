using System;
using System.Collections.Generic;
using Monaco.Subscriptions.Impl;

namespace Monaco.Messages.For.Subscriptions
{
    [Serializable]
    public class LocalSubscriptionsMessage  : IAdminMessage
    {
        public string BusUri { get; set; }
        public ICollection<Subscription> Subscriptions { get; set; }

        public LocalSubscriptionsMessage(string busUri, ICollection<Subscription> subscriptions)
        {
            BusUri = busUri;
            Subscriptions = new List<Subscription>(subscriptions);
        }
    }
}