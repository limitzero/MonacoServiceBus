namespace Monaco.Messages.For.ServiceBus
{
    public class BusStoppingMessage : IAdminMessage
    {}
}