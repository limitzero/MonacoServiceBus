using System;

namespace Monaco.Messages.For.ServiceBus
{
    /// <summary>
    /// Message that is published to denote that the service bus has started.
    /// </summary>
    [Serializable]
    public class BusStartedMessage : IAdminMessage
    {
        
    }
}