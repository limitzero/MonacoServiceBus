using System;

namespace Monaco.Messages
{
    [Serializable]
    public class ServicedEndpointMessage : IAdminMessage
    {
        public string Name { get; set; }
        public string EndpointUri { get; set; }
        public string BusUri { get; set; }
    }
}