using System;
using System.Collections.Generic;

namespace Monaco.Messages
{
    [Serializable]
    public class ServicedEndpointsMessage : IAdminMessage
    {
        public List<ServicedEndpointMessage> ServicedEndpoints { get; set; }

        public ServicedEndpointsMessage()
        {
            this.ServicedEndpoints = new List<ServicedEndpointMessage>();
        }
    }
}