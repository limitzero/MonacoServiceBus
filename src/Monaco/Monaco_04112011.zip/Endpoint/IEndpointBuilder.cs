using Monaco.Endpoint.Impl;

namespace Monaco.Endpoint
{
    /// <summary>
    /// Contract for factory implementation for custom endpoints where the 
    /// endpoint can be created using the underlying semantics of the particular
    /// endpoint location and technology type. This is the extension point 
    /// of the technology transport to be created by the service bus.
    /// </summary>
    /// <typeparam name="TENDPOINT">Endpoint to create</typeparam>
    public interface IEndpointBuilder<TENDPOINT> where TENDPOINT : BaseEndpoint
    {
        /// <summary>
        /// Gets the scheme associated with building the endpoints.
        /// </summary>
        string Scheme { get; }

        /// <summary>
        /// This will create the neccesary subscription definition for the 
        /// message bus to dynamically create the builder for the endpoint.
        /// </summary>
        /// <returns></returns>
        IEndpointBuilderSubscription CreateSubscription();

        /// <summary>
        /// This will create an endpoint based on the uri semantics.
        /// </summary>
        /// <param name="uri">The uri of the endpoint type to create.</param>
        /// <returns>
        /// An instance of {TENDPOINT}.
        /// </returns>
        TENDPOINT Build(string uri);

        /// <summary>
        /// This will create an endpoint based on the uri semantics and 
        /// sets the friendly name on the endpoint instance.
        /// </summary>
        /// <param name="name">The friendly name to associate with the endpoint.</param>
        /// <param name="uri">The uri of the endpoint type to create.</param>
        /// <returns>
        /// An instance of {TENDPOINT}.
        /// </returns>
        TENDPOINT Build(string name, string uri);
    }
}