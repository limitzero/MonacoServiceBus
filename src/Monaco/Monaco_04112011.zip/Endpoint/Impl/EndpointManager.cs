using System;
using Monaco.Internals.Eventing;
using Monaco.Transport;

namespace Monaco.Endpoint.Impl
{
    /// <summary>
    /// Concrete implementation of <seealso cref="IEndpointManager"/>
    /// for managing the lifecycle of all message bus endpoints.
    /// </summary>
    public class EndpointManager : IEndpointManager
    {
        private readonly IEndpointRegistry _registry;
        private bool _disposing;

        public bool IsRunning { get; private set; }

        public event EventHandler<ComponentStartedEventArgs> ComponentStartedEvent;
        public event EventHandler<ComponentStoppedEventArgs> ComponentStoppedEvent;
        public event EventHandler<ComponentErrorEventArgs> ComponentErrorEvent;
        public event EventHandler<ComponentNotificationEventArgs> ComponentNotificationEvent;
        public event Action<BaseEndpoint, IEnvelope> EndpointManagerMessageReceived;

        public EndpointManager(IEndpointRegistry registry)
        {
            _registry = registry;
        }

        public void Dispose()
        {
            this.Stop();
        }

        public void Start()
        {
            if(this.IsRunning == true)
            {
                return;
            }

            try
            {
                foreach (BaseEndpoint endpoint in _registry.Endpoints)
                {
                    this.Bind(endpoint, true);
                    endpoint.Start();
                    this.OnEndpointStarted(endpoint);
                }
            }
            catch (Exception e)
            {
                if(!OnEndpointManagerError(e))
                    throw;
            }

            this.IsRunning = true;
            this.OnEndpointManagerStarted();
        }

        public void Stop()
        {
            try
            {
                foreach (BaseEndpoint endpoint in _registry.Endpoints)
                {
                    endpoint.Stop();
                    this.Bind(endpoint, false);
                    this.OnEndpointStopped(endpoint);
                }
            }
            catch (Exception e)
            {
                if (!OnEndpointManagerError(e))
                    throw;
            }

            this.IsRunning = false;
            this.OnEndpointManagerStopped();
        }

        private void Bind(BaseEndpoint endpoint, bool isStarting)
        {
            if(isStarting == true)
            {
                endpoint.EndpointMessageReceived += OnEndpointMessageReceived;
                //endpoint.OnMessageFailedDelivery += OnEndpointMessageDeliveryFailed;
            }
            else
            {
                endpoint.EndpointMessageReceived -= OnEndpointMessageReceived;
                //endpoint.OnMessageFailedDelivery -= OnEndpointMessageDeliveryFailed;
            }
        }

        private void OnEndpointManagerStarted()
        {
            this.OnComponentStarted(this, new ComponentStartedEventArgs("Endpoint Manager"));
        }

        private void OnEndpointManagerStopped()
        {
            this.OnComponentStopped(this, new ComponentStoppedEventArgs("Endpoint Manager"));
        }

        private bool OnEndpointManagerError(Exception exception)
        {
            EventHandler<ComponentErrorEventArgs> evt = this.ComponentErrorEvent;
            bool isHandlerAttached = (evt != null);

            if (isHandlerAttached)
            {
                evt(this, new ComponentErrorEventArgs(exception));
            }

            return isHandlerAttached;
        }

        private void OnEndpointStarted(BaseEndpoint endpoint)
        {
            this.OnComponentStarted(this, new ComponentStartedEventArgs(endpoint.Address.Uri));
        }

        private void OnEndpointStopped(BaseEndpoint endpoint)
        {
            this.OnComponentStopped(this, new ComponentStoppedEventArgs(endpoint.Address.Uri));
        }

        private void OnComponentStarted(object sender, ComponentStartedEventArgs args)
        {
            EventHandler<ComponentStartedEventArgs> evt = this.ComponentStartedEvent;

            if (evt != null)
            {
                evt(this, args);
            }
        }

        private void OnComponentStopped(object sender, ComponentStoppedEventArgs args)
        {
            EventHandler<ComponentStoppedEventArgs> evt = this.ComponentStoppedEvent;

            if (evt != null)
            {
                evt(this, args);
            }
        }

        private void OnComponentError(object sender, ComponentErrorEventArgs args)
        {
            EventHandler<ComponentErrorEventArgs> evt = this.ComponentErrorEvent;

            if(evt != null)
            {
                evt(this, args);
            }
        }

        private void OnComponentNotification(object sender, ComponentNotificationEventArgs args)
        {
            EventHandler<ComponentNotificationEventArgs> evt = this.ComponentNotificationEvent;

            if (evt != null)
            {
                evt(this, args);
            }
        }

        private void OnEndpointMessageDeliveryFailed(IEnvelope envelope, Exception exception)
        {
            // TODO: push the message to the poision queue for the endpoint:
            throw new NotImplementedException();
        }

        private void OnEndpointMessageReceived(object sender, EndpointMessageReceivedEventArgs e)
        {
            if (e.Envelope != null)
            {
                if (this.EndpointManagerMessageReceived != null)
                {
                    this.EndpointManagerMessageReceived(e.Endpoint, e.Envelope);
                }
            }           
        }
    }
}