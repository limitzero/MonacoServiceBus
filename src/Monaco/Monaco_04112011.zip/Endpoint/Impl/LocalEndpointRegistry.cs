using System;
using System.Collections.Generic;
using System.Linq;
using Monaco.Exceptions;
using Monaco.Internals.Collections;

namespace Monaco.Endpoint.Impl
{
    /// <summary>
    /// Volatile instance of <seealso cref="IEndpointRegistry"/> that 
    /// will contain all of the configured endpoints on the message bus instance.
    /// </summary>
    public class LocalEndpointRegistry : IEndpointRegistry, IDisposable
    {
        private static readonly object _endpoints_lock = new object();
        private static IThreadSafeList<BaseEndpoint> _endpoints;
        private bool _disposed;

        public LocalEndpointRegistry()
        {
            if(_endpoints == null)
            {
                _endpoints = new ThreadSafeList<BaseEndpoint>();
            }
        }

        public void Dispose()
        {
            this._disposed = true;

            if(_endpoints != null)
            {
                _endpoints.Clear();
                _endpoints = null;
            }
        }

        public ICollection<BaseEndpoint> Endpoints
        {
            get
            {
                if (_disposed == true)
                {
                    throw new DisposingException();
                }

                lock(_endpoints_lock)
                {
                    return _endpoints;
                }
            }
        }

        public void Register(BaseEndpoint endpoint)
        {
            if (_disposed == true)
            {
                throw new DisposingException();
            }

            lock(_endpoints_lock)
            {
                if (_endpoints.Contains(endpoint) == false)
                {
                    _endpoints.Add(endpoint);
                }
            }
        }

        public BaseEndpoint Find(string name)
        {
            lock(_endpoints_lock)
            {
                BaseEndpoint theEndpoint = (from endpoint in this.Endpoints
                                            where endpoint.Name.Trim().ToLower() == name.Trim().ToLower()
                                            select endpoint).FirstOrDefault();
                return theEndpoint;
            }
        }
    }
}