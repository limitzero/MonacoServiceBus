using System;
using System.IO;
using Monaco.Internals.Reflection;

namespace Monaco.Endpoint.Impl
{
    /// <summary>
    /// Concrete instance of the <seealso cref="IEndpointAdapter"/> used by the 
    /// message bus for direct communication with and endpoint implementation.
    /// </summary>
    //TODO: Fix this for the IEnvelope implementation for sending and receiving
    public class EndpointAdapter : IEndpointAdapter
    {
        private readonly IReflection _reflection;
        private readonly IEndpointBuilderSubscriptionRepository _repository;

        public EndpointAdapter(IReflection reflection, 
                                       IEndpointBuilderSubscriptionRepository repository)
        {
            _reflection = reflection;
            _repository = repository;
        }

        public BaseEndpoint GetEndpoint(string uri)
        {
            IEndpointBuilderSubscription subscription = _repository.Find(uri);

            object builder = _reflection.BuildInstance(subscription.Builder);

            BaseEndpoint endpoint = _reflection.InvokeBuildForEndpointBuilder(builder, uri);

            return endpoint;
        }

        private void Send(string uri, IMessage message)
        {
            BaseEndpoint endpoint = GetEndpoint(uri);
        }

        private void Send(string uri, Stream stream)
        {
            BaseEndpoint endpoint = GetEndpoint(uri);
        }

        private IMessage Receive(string uri)
        {
            return this.Receive(uri, TimeSpan.Zero);
        }

        private IMessage Receive(string uri, TimeSpan timeout)
        {
            BaseEndpoint endpoint = GetEndpoint(uri);
            return null;
        }


    }
}