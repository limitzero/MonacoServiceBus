using System;
using System.Collections.Generic;
using System.Linq;
using Monaco.Exceptions;
using Monaco.Internals.Collections;

namespace Monaco.Endpoint.Impl
{
    /// <summary>
    /// Volatile implementation of the <seealso cref="IEndpointBuilderSubscriptionRepository">
    /// repository to store endpoint building definitions</seealso>.
    /// </summary>
    public class LocalEndpointBuilderSubscriptionRepository : 
        IEndpointBuilderSubscriptionRepository, IDisposable
    {
        private bool _disposed;
        private static readonly object _subscription_lock = new object();
        private static IThreadSafeList<IEndpointBuilderSubscription> _subscriptions;

        public LocalEndpointBuilderSubscriptionRepository()
        {
            if(_subscriptions == null)
            {
                _subscriptions = new ThreadSafeList<IEndpointBuilderSubscription>();
            }
        }

        public void Dispose()
        {
            _disposed = true;

            if(_subscriptions != null)
            {
                _subscriptions.Clear();
                _subscriptions = null;
            }
        }

        public void Add(IEndpointBuilderSubscription subscription)
        {
            if(_disposed == true)
            {
                throw new DisposingException();
            }

            lock(_subscription_lock)
            {
                IEndpointBuilderSubscription theSubscription = (from item in _subscriptions
                                                               where
                                                                   item.Scheme.Trim().ToLower() ==
                                                                   subscription.Scheme.Trim().ToLower()
                                                               select subscription).FirstOrDefault();

                if (theSubscription == null)
                {
                    _subscriptions.Add(subscription);
                }
            }
        }

        public IEndpointBuilderSubscription Find(string uri)
        {
            if (_disposed == true)
            {
                throw new DisposingException();
            }

            Uri theUri = new Uri(uri);

            lock(_subscription_lock)
            {
                IEndpointBuilderSubscription theSubscription = (from subscription in _subscriptions
                                                                where
                                                                    subscription.Scheme.Trim().ToLower() ==
                                                                    theUri.Scheme.Trim().ToLower()
                                                                select subscription).FirstOrDefault();

                if(theSubscription == null)
                {
                    throw new MonacoConfigurationException("No transport configuration was registered for the following scheme: " + new Uri(uri).Scheme);
                }

                return theSubscription;
            }
        }

        public ICollection<IEndpointBuilderSubscription> FindAll()
        {
            lock (_subscription_lock)
            {
                return _subscriptions.ToList();
            }
        }

    }
}