namespace Monaco.Endpoint.Impl
{
    public class EndpointConfiguration : IEndpointConfiguration
    {
        public string Name { get; set; }
        public string Uri { get; set; }
        public int Concurrency { get; set; }
        public string StatusInterval { get; set; }
        public string StatusIntervalGracePeriod { get; set; }
        public int MaxRetries { get; set; }
    }
}