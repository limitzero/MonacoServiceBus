namespace Monaco.Endpoint.Impl
{
    /// <summary>
    /// Concrete instance of the <seealso cref="IEndpointBuilderSubscription"/>
    /// </summary>
    public class EndpointBuilderSubscription : IEndpointBuilderSubscription
    {
        public string Scheme { get; set; }
        public string Builder { get; set; }
        public string Description { get; set; }

        public EndpointBuilderSubscription()
        {
            
        }

        public EndpointBuilderSubscription(string scheme, string builder)
            :this(scheme, builder, string.Empty)
        {
        }

        public EndpointBuilderSubscription(string scheme, string builder, string description)
        {
            Scheme = scheme;
            Builder = builder;
            Description = description;
        }
    }
}