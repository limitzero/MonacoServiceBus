using System;
using System.IO;
using System.Transactions;
using Monaco.Exceptions;
using Monaco.Internals.Agent;
using Monaco.Internals.Eventing;
using Monaco.Transport;
using IsolationLevel = System.Data.IsolationLevel;

namespace Monaco.Endpoint.Impl
{
    #region -- original BaseEndpoint --
    /*
    /// <summary>
    /// This is the base implementation of an endpoint that can 
    /// process the message from the physical location when 
    /// it is delivered or received from the location.
    /// </summary>
    public abstract class BaseEndpoint : BaseAgent, IEndpoint
    {
        private readonly ISerializationProvider _serializationProvider;
        private IMessage _message;

        public event EventHandler<EndpointMessageReceivedEventArgs> EndpointMessageReceived;

        /// <summary>
        /// Event that is fired when a message can not be delivered to the indicated 
        /// location after the retry period. If this action is not handled by the calling
        /// code, the exception <seealso cref="EndpointFailedDeliveryException"/>
        /// will be raised.
        /// </summary>
        public Action<IMessage, Stream, Exception> OnMessageFailedDelivery;

        public ITransport Transport { get; private set; }

        /// <summary>
        /// Gets or set the name of the end point.
        /// </summary>
        public new string Name { get; set; }

        /// <summary>
        /// Gets or sets a flag indicating whether or not the transport supports transactions.
        /// </summary>
        public bool IsTransactional { get; set; }

        /// <summary>
        /// Gets or sets the number of retries that the transport will attempt 
        /// for sending a message to a location.
        /// </summary>
        public int MaxRetries { get; set; }

        /// <summary>
        /// Gets or sets the end point address that the endpoint will receive messages on.
        /// </summary>
        public IEndpointAddress Address { get; set; }

        /// <summary>
        /// .ctor for endpoint without serialization support.
        /// </summary>
        /// <param name="address"></param>
        /// <param name="transport"></param>
        protected BaseEndpoint(IEndpointAddress address, ITransport transport)
            :this(address, transport, null)
        {
        }

        protected BaseEndpoint(IEndpointAddress endpointAddress,
                               ITransport transport,
                               ISerializationProvider serializationProvider)
        {
            Address = endpointAddress;
            Transport = transport;
            Transport.EndpointUri = endpointAddress.Uri;
            _serializationProvider = serializationProvider;
            base.Name = string.Format("ENDPOINT:<{0}>" , Name ?? endpointAddress.Uri);
        }

        /// <summary>
        /// This will send a message to the desired 
        /// endpoint location via the transport technology.
        /// This will delegate to the <see cref="DoSend(IMessage)"/>
        /// method for implementation.
        /// </summary>
        /// <param name="message">The message to send.</param>
        public void Send(IMessage message)
        {
            try
            {
                this.DoSend(message);
            }
            catch (Exception e)
            {
                // register the send operation for retry:
                this.RegisterSendForRetry(() => this.DoSend(message), message, null, this.MaxRetries);
            }
        }

        /// <summary>
        /// This is the method where the local implementation 
        /// of the <see cref="Send(IMessage)"/> invocation will 
        /// be done.
        /// </summary>
        /// <param name="message"></param>
        public abstract void DoSend(IMessage message);

        /// <summary>
        /// This will send a message to the desired 
        /// endpoint location via the transport technology.
        /// This will delegate to the method <see cref="DoSend(MessageMetaData,Stream)"/>
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="message">The message to send.</param>
        public void Send(MessageMetaData metadata, Stream message)
        {
            try
            {
                this.DoSend(metadata, message);
            }
            catch (Exception e)
            {
                this.RegisterSendForRetry(() => this.DoSend(metadata, message), null, message, this.MaxRetries);
            }
        }

        public abstract void DoSend(MessageMetaData metadata, Stream message);

        /// <summary>
        /// This will receive a message from the indicated endpoint via 
        /// the specifics of the particular technology transport. After
        /// the message is received, it will call a void method on the 
        /// caller to notify of the received message.
        /// </summary>
        public virtual IMessage Receive()
        {
            return this.Receive(TimeSpan.Zero);
        }

        /// <summary>
        /// This will receive a message from the indicated endpoint via 
        /// the specifics of the particular technology transport. After
        /// the message is received, it will call a void method on the 
        /// caller to notify of the received message.
        /// </summary>
        public abstract IMessage Receive(TimeSpan timeout);

        public IMessage Deserialize(Stream theStream)
        {
            IMessage theMessage = null;

            if (theStream != null)
            {
                if (_serializationProvider != null)
                {
                    theMessage = _serializationProvider.Deserialize(theStream) as IMessage;
                }
            }

            return theMessage;
        }

        public Stream Serialize(IMessage theMessage)
        {
            Stream theStream = null;

            if (_serializationProvider != null)
            {
                var theBytes = _serializationProvider.SerializeToBytes(theMessage);
                theStream = new MemoryStream(theBytes);
            }

            return theStream;
        }

        public override void Execute()
        {
            this.Transport.IsTransactional = this.IsTransactional;

            if (this.IsTransactional == true)
                this.ReceiveWithTransaction();
            else
            {
                this.GuardForReceive();
            }
        }

        private void GuardForReceive()
        {
            IMessage message = this.Receive();

            if (message != null)
            {
                _message = message;
                OnEndpointMessageReceived(message);
            }
        }

        private void OnEndpointMessageReceived(IMessage message)
        {
            EventHandler<EndpointMessageReceivedEventArgs> evt = this.EndpointMessageReceived;

            if (evt != null)
            {
                evt(this, new EndpointMessageReceivedEventArgs(this, message));
            }
        }

        public void DeliverReceivedMessage(IEndpointAddress address, IMessage message)
        {
            if (message == null)
            {
                return;
            }

            var evt = this.EndpointMessageReceived;
            if (evt != null)
                evt(this, new EndpointMessageReceivedEventArgs(this, message));
        }

        private void ReceiveWithTransaction()
        {
            // set the transaction up for concurrent reads:
            TransactionOptions options = new TransactionOptions();
            options.IsolationLevel = IsolationLevel.RepeatableRead;
            IMessage message = null;

            using (var scope = new TransactionScope(TransactionScopeOption.RequiresNew, options))
            {
                try
                {
                    message = this.Receive();

                    if (message != null)
                    {
                        OnEndpointMessageReceived(message);
                    }

                    scope.Complete();
                }
                catch (Exception e)
                {
                    // all work is rolled back here, including the 
                    //  receive of the message from the transport:
                    if (message != null)
                    {
                        //this.Send(this.PoisionAddress.Uri,  message);
                    }

                    if (!OnEndpointError(e))
                        throw new EndpointReceiveException(this.Address.Uri, e);
                }
            }

        }

        private void RegisterSendForRetry(Action action, IMessage message, Stream stream, int retries)
        {
            Exception theSendException = null;

            try
            {
                for (int retry = 1; retry <= retries; retry++)
                {
                    try
                    {
                        action();
                        theSendException = null;
                        break;
                    }
                    catch (Exception e)
                    {
                        theSendException = e;
                        continue;
                    }
                }

                if (theSendException != null)
                {
                    throw theSendException;
                }
            }
            catch (Exception e)
            {
                if (this.OnMessageFailedDelivery != null)
                {
                    OnMessageFailedDelivery(message, stream, e);
                }
                else
                {
                    // unhandled...need to do something with the message:
                    if (message != null)
                    {
                        throw new EndpointFailedDeliveryException(this, message, e);
                    }

                    if (stream != null)
                    {
                        throw new EndpointFailedDeliveryException(this, stream, e);
                    }
                }
            }

        }

        /// <summary>
        /// This will notify the infrastructure that an error has occured from the polled end point.
        /// </summary>
        /// <param name="exception"></param>
        /// <returns></returns>
        private bool OnEndpointError(Exception exception)
        {
            return base.OnServiceError(exception.Message, exception);
        }
    }
    */
    #endregion 

    /// <summary>
    /// This is the base implementation of an endpoint that can 
    /// process the message from the physical location when 
    /// it is delivered or received from the location.
    /// </summary>
    public abstract class BaseEndpoint : BaseAgent, IEndpoint
    {
        /// <summary>
        /// Event that is triggered when a message is received from the endpoint for consumption.
        /// </summary>
        public event EventHandler<EndpointMessageReceivedEventArgs> EndpointMessageReceived;

        /// <summary>
        /// Event that is fired when a message can not be delivered to the indicated 
        /// location after the retry period. If this action is not handled by the calling
        /// code, the exception <seealso cref="EndpointFailedDeliveryException"/>
        /// will be raised.
        /// </summary>
        public Action<IEnvelope, Exception> OnMessageFailedDelivery;

        /// <summary>
        /// Gets the current <seealso cref="ITransport">transport</seealso> assigned 
        /// to the endpoint for message delivery and receipt 
        /// </summary>
        public ITransport Transport { get; private set; }

        /// <summary>
        /// Gets or sets a flag indicating whether or not the transport supports transactions.
        /// </summary>
        public bool IsTransactional { get; set; }

        /// <summary>
        /// Gets or sets the number of retries that the transport will attempt 
        /// for sending a message to a location.
        /// </summary>
        public int MaxRetries { get; set; }

        /// <summary>
        /// Gets or sets the end point address that the endpoint will receive messages on.
        /// </summary>
        public IEndpointAddress Address { get; set; }

        /// <summary>
        /// Gets or set the name of the end point.
        /// </summary>
        public new string Name { get; set; }

        /// <summary>
        /// .ctor for endpoint 
        /// </summary>
        /// <param name="address">The address specification for the endpoint</param>
        /// <param name="transport">The transport specification for the endpoint</param>
        protected BaseEndpoint(IEndpointAddress address, ITransport transport)
        {
            Address = address;
            Transport = transport;
            Transport.EndpointUri = address.Uri;
            base.Name = string.Format("ENDPOINT:<{0}>", Name ?? address.Uri);
        }

        /// <summary>
        /// This will send a message to the desired 
        /// endpoint location via the transport technology.
        /// This will delegate to the <see cref="DoSend(IEnvelope)"/>
        /// method for implementation.
        /// </summary>
        /// <param name="envelope">The message to send.</param>
        public void Send(IEnvelope envelope)
        {
            try
            {
                this.DoSend(envelope);
            }
            catch (Exception e)
            {
                // register the send operation for retry:
                this.RegisterSendForRetry(() => this.DoSend(envelope), envelope, this.MaxRetries);
            }
        }

        /// <summary>
        /// This is the method where the local implementation 
        /// of the <see cref="Send(IEnvelope)"/> invocation will be done.
        /// </summary>
        /// <param name="envelope"></param>
        public abstract void DoSend(IEnvelope envelope);

        /// <summary>
        /// This will receive a message from the indicated endpoint via 
        /// the specifics of the particular technology transport. After
        /// the message is received, it will call a void method on the 
        /// caller to notify of the received message.
        /// </summary>
        public virtual IEnvelope Receive()
        {
            IEnvelope envelope = this.Receive(TimeSpan.Zero);

            if (envelope != null)
            {
                envelope.AddHeader(Headers.ENDPOINT_URI, this.Address.Uri);
            }

            return envelope;
        }

        /// <summary>
        /// This will receive a message from the indicated endpoint via 
        /// the specifics of the particular technology transport. After
        /// the message is received, it will call a void method on the 
        /// caller to notify of the received message.
        /// </summary>
        public abstract IEnvelope Receive(TimeSpan timeout);

        public override void Execute()
        {
            this.Transport.IsTransactional = this.IsTransactional;

            if (this.IsTransactional == true)
                this.ReceiveWithTransaction();
            else
            {
                this.GuardForReceive();
            }
        }

        public override void Stop()
        {
            this.Transport.Dispose();
            base.Stop();
        }

        private void GuardForReceive()
        {
            IEnvelope message = this.Receive();

            if (message != null)
            {
                OnEndpointMessageReceived(message);
            }
        }

        private void ReceiveWithTransaction()
        {
            // set the transaction up for concurrent reads:
            TransactionOptions options = new TransactionOptions();
            options.IsolationLevel = System.Transactions.IsolationLevel.RepeatableRead;
            IEnvelope message = null;

            using (var scope = new TransactionScope(TransactionScopeOption.RequiresNew, options))
            {
                try
                {
                    message = this.Receive();

                    if (message != null)
                    {
                        OnEndpointMessageReceived(message);
                    }

                    scope.Complete();
                }
                catch (Exception e)
                {
                    // all work is rolled back here, including the 
                    // receive of the message from the transport
                    // let the indicated endpoint implementation 
                    // handle the message that caused the exception:
                    if (message != null && this.OnMessageFailedDelivery != null)
                    {
                        //TODO: make sure that this process effectively pushes the message
                        IEnvelope poisionMessage = message;

                        poisionMessage.AddHeader(Headers.MESSAGE_NAME, 
                            message.GetPayload<object>().GetType().Name);

                        MemoryStream theStream = new MemoryStream(message.BodyStream);
                        poisionMessage.ChangePayload(theStream);

                        this.OnMessageFailedDelivery(poisionMessage, e);
                    }

                    if (!OnEndpointError(e))
                        throw new EndpointReceiveException(this.Address.Uri, e);
                }
            }
        }

        private void RegisterSendForRetry(Action action, IEnvelope envelope, int retries)
        {
            Exception theSendException = null;

            try
            {
                for (int retry = 1; retry <= retries; retry++)
                {
                    try
                    {
                        action();
                        theSendException = null;
                        break;
                    }
                    catch (Exception e)
                    {
                        theSendException = e;
                        continue;
                    }
                }

                if (theSendException != null)
                {
                    throw theSendException;
                }
            }
            catch (Exception e)
            {
                //TODO: make sure that this process effectively pushes the message
                if (this.OnMessageFailedDelivery != null)
                {
                    OnMessageFailedDelivery(envelope, e);
                }
                else
                {
                    // unhandled...need to do something with the raw message from the endpoint:
                    throw new EndpointFailedDeliveryException(this, envelope.GetPayload<object>(), e);
                }
            }
        }

        private void OnEndpointMessageReceived(IEnvelope envelope)
        {
            EventHandler<EndpointMessageReceivedEventArgs> evt = this.EndpointMessageReceived;

            if (evt != null)
            {
                evt(this, new EndpointMessageReceivedEventArgs(this, envelope));
            }
        }

        /// <summary>
        /// This will notify the infrastructure that an error has occured from the polled end point.
        /// </summary>
        /// <param name="exception"></param>
        /// <returns></returns>
        private bool OnEndpointError(Exception exception)
        {
            return base.OnServiceError(exception.Message, exception);
        }
    }
}