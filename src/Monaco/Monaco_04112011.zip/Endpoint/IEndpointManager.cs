using System;
using Monaco.Endpoint.Impl;
using Monaco.Internals;
using Monaco.Internals.Eventing;
using Monaco.Transport;

namespace Monaco.Endpoint
{
    /// <summary>
    /// Concrete instance that will manage the lifecycle of the endpoints (i.e. start/stop)
    /// and report any messages that are received from the endpoints to the message bus
    /// for processing.
    /// </summary>
    public interface IEndpointManager : 
        IStartable, IStartableEventBroadcaster, IErrorEventBroadcaster, INotificationEventBroadcaster
    {
        /// <summary>
        /// Event that is triggered when a message is received from an endpoint.
        /// </summary>
        event Action<BaseEndpoint, IEnvelope> EndpointManagerMessageReceived;
    }
}