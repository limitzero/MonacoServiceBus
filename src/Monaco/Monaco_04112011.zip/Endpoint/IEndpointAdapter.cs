using Monaco.Endpoint.Impl;

namespace Monaco.Endpoint
{
    /// <summary>
    /// Contract used by the message bus to communicate with any endpoint 
    /// for direct delivery and reception of messages.
    /// </summary>
    public interface IEndpointAdapter
    {
        /// <summary>
        /// This will retrieve an instance of an endpoint via the uri for sending or receving a message.
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        BaseEndpoint GetEndpoint(string uri);

        /// <summary>
        /// This will send a message to a specific endpoint by uri specification.
        /// </summary>
        /// <param name="uri">Uri specification of the endpoint</param>
        /// <param name="message">Message to send.</param>
        // void Send(string uri, IMessage message);

        /// <summary>
        /// This will send a message to a specific endpoint by uri specification.
        /// </summary>
        /// <param name="uri">Uri specification of the endpoint</param>
        /// <param name="stream">Message stream to send.</param>
        // void Send(string uri, Stream stream);

        /// <summary>
        /// This will receive a message from a particular endpoint location by uri specification.
        /// </summary>
        /// <param name="uri">Uri specification of the endpoint</param>
        /// <returns>
        ///   A concrete instance of a message implementing the <see cref="IMessage"/> interface.
        /// </returns>
        //IMessage Receive(string uri);

        /// <summary>
        /// This will receive a message from a particular endpoint location by uri specification.
        /// </summary>
        /// <param name="uri">Uri specification of the endpoint</param>
        /// <param name="timeout">Duration in which the message should be received.</param>
        /// <returns>
        ///   A concrete instance of a message implementing the <see cref="IMessage"/> interface.
        /// </returns>
        // IMessage Receive(string uri, TimeSpan timeout);
    }
}