using Monaco.Endpoint.Impl;

namespace Monaco.Endpoint
{
    /// <summary>
    /// Factory implementation that the bus will use in order to dynamically create an endpoint.
    /// </summary>
    public interface IEndpointFactory
    {
        /// <summary>
        /// This will get the current endpoint implementation by uri specification.
        /// </summary>
        /// <param name="uri">Current uri specification that will yield a concrete endpoint.</param>
        /// <returns>
        ///   A concrete instance implementing <see cref="BaseEndpoint"/>
        /// </returns>
        BaseEndpoint Get(string uri);
    }
}