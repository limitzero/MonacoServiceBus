using System.Collections.Generic;
using Monaco.Endpoint.Impl;

namespace Monaco.Endpoint
{
    /// <summary>
    /// Contract that will define all of the active endpoints that are on the message 
    /// bus instance for message receipt and delivery. 
    /// </summary>
    public interface IEndpointRegistry
    {
        /// <summary>
        /// Gets the collection of endpoints on the message bus instance.
        /// </summary>
        ICollection<BaseEndpoint> Endpoints { get;  }

        /// <summary>
        /// This will register an <seealso cref="BaseEndpoint">endpoint</seealso>
        /// on the message bus instance.
        /// </summary>
        /// <param name="endpoint">Concrete endpoint instance for registration.</param>
        void Register(BaseEndpoint endpoint);

        /// <summary>
        /// This will find an instance of a registered endpoint by name.
        /// </summary>
        /// <param name="name">Name of the endpoint.</param>
        /// <returns>
        /// A concrete instance of a class derived from <seealso cref="BaseEndpoint"/>.
        /// </returns>
        BaseEndpoint Find(string name);
    }
}