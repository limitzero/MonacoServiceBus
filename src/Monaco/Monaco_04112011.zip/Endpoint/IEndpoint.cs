﻿using Monaco.Transport;

namespace Monaco.Endpoint
{
    /// <summary>
    /// This is implementation of an endpoint that can 
    /// process the message from the physical location when 
    /// it is delivered or received from the location.
    /// </summary>
    public interface IEndpoint
    {
        /// <summary>
        /// Gets or sets the friendly name for the endpoint
        /// </summary>
        string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the current address that the endpoint will receive messages from or by default send messages to.
        /// </summary>
        IEndpointAddress Address
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the transport associated with the endpoint for receiving and sending messages.
        /// </summary>
        ITransport Transport
        {
            get;
        }

    }
}