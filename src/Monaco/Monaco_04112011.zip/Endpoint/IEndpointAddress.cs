namespace Monaco.Endpoint
{
    /// <summary>
    /// Contract for the addressing scheme to connect to the 
    /// physical messaging storage location.
    /// </summary>
    public interface IEndpointAddress
    {
        /// <summary>
        /// Gets the normalized form of the end point address for accessing the physical storage.
        /// </summary>
        string Uri { get; }
    }
}