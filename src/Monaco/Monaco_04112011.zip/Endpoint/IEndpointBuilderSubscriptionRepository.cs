using System.Collections.Generic;
using Monaco.Endpoint.Impl;

namespace Monaco.Endpoint
{
    /// <summary>
    /// Contract for all endpoint builders that are registered on the message bus instance.
    /// </summary>
    public interface IEndpointBuilderSubscriptionRepository
    {
        /// <summary>
        /// This will add an <seealso cref="IEndpointBuilderSubscription">endpoint builder subscription</seealso> to the repository.
        /// </summary>
        /// <param name="subscription">Subscription representing how to build the endpoint.</param>
        void Add(IEndpointBuilderSubscription subscription);

        /// <summary>
        /// This will return an instance of a subscription denoting how to build an endpoint.
        /// </summary>
        /// <param name="uri">Uri specification of the endpoint to build.</param>
        /// <returns>
        ///   A concrete instance of an <seealso cref="EndpointBuilderSubscription">endpoint subscription</seealso>
        /// </returns>
        IEndpointBuilderSubscription Find(string uri);

        /// <summary>
        /// This will return all of the endpoint builder subscription instances.
        /// </summary>
        /// <returns></returns>
        ICollection<IEndpointBuilderSubscription> FindAll();
    }
}