using Monaco.Messages.For.Endpoints;

namespace Monaco.Endpoint.Health.Tasks
{
    public class EndpointHeartBeatTask : 
        Produces<EndpointHeartBeatMessage>
    {
        public string EndpointName { get; set; }
        public string EndpointUri { get; set; }
        public string EndpointHeartbeatInterval { get; set; }
        public string EndpointHeartbeatGracePeriod { get; set; }

        public EndpointHeartBeatTask()
        {
            
        }

        public EndpointHeartBeatTask(string endpointName,
                                     string endpointUri, 
                                     string endpointHeartbeatInterval, 
                                     string endpointHeartbeatGracePeriod)
        {
            EndpointName = endpointName;
            EndpointUri = endpointUri;
            EndpointHeartbeatInterval = endpointHeartbeatInterval;
            EndpointHeartbeatGracePeriod = endpointHeartbeatGracePeriod;
        }

        public EndpointHeartBeatMessage Produce()
        {
            return new EndpointHeartBeatMessage(
                this.EndpointName,
                this.EndpointUri,
                this.EndpointHeartbeatInterval,
                this.EndpointHeartbeatGracePeriod);
        }
    }
}