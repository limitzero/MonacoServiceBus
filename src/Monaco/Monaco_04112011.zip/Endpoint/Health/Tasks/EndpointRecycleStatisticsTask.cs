using Monaco.Messages.For.Endpoints;

namespace Monaco.Endpoint.Health.Tasks
{
    public class EndpointRecycleStatisticsTask : 
        Produces<EndpointHealthRecycleStatisticsMessage>
    {
        public EndpointHealthRecycleStatisticsMessage Produce()
        {
            return new EndpointHealthRecycleStatisticsMessage();
        }
    }
}