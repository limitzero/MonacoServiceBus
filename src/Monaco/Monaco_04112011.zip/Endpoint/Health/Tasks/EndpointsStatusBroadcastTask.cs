using Monaco.Messages.For.Endpoints;

namespace Monaco.Endpoint.Health.Tasks
{
    public class EndpointsStatusBroadcastTask : 
        Produces<BroadcastStatusForAllEndpointsMessage>
    {
        public BroadcastStatusForAllEndpointsMessage Produce()
        {
            return new BroadcastStatusForAllEndpointsMessage();
        }
    }
}