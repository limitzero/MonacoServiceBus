using System;
using System.Collections.Generic;
using Monaco.Extensions;
using Monaco.Messages.For.Endpoints;

namespace Monaco.Endpoint.Health.Saga
{
    [Serializable]
    public class EndpointStatistic : IMessage
    {
        public string EndpointName { get; set; }
        public string EndpointUri { get; set; }
        public int NumberOfMessagesSent { get; set; }
        public int NumberOfMessagesReceived { get; set; }
        public List<EndpointHeartBeatMessage> Heartbeats { get; set; }
        public EndpointMetricStatus HeartbeatStatus { get; set; }

        public EndpointStatistic()
        {
        }

        public EndpointStatistic(string endpointName, string endpointUri)
        {
            this.EndpointName = endpointName;
            EndpointUri = endpointUri;
            this.Heartbeats = new List<EndpointHeartBeatMessage>();
        }

        public void RecordHeartBeat(EndpointHeartBeatMessage message)
        {
            this.Heartbeats.Add(message);
        }

        public void RecordMessageSent()
        {
            this.NumberOfMessagesSent++;
        }

        public void RecordMessageReceived()
        {
            this.NumberOfMessagesReceived++;
        }

        public void SetHeartBeatStatus()
        {
            int failureCount = 0;
            int successCount = 0;

            foreach (EndpointHeartBeatMessage heartbeat in this.Heartbeats)
            {
                // compute the number of times the heartbeat failed to be reported:
                TimeSpan duration = heartbeat.Received - heartbeat.At;
                TimeSpan gracePeriod = new TimeSpan().CreateFromInterval(heartbeat.GracePeriod).Value; 

                if(duration.Seconds > gracePeriod.Seconds)
                {
                    failureCount++;
                }
                else
                {
                    successCount++;
                }
            }

            if(failureCount > successCount)
            {
                this.HeartbeatStatus = EndpointMetricStatus.Suspect;
            }
            else
            {
                this.HeartbeatStatus = EndpointMetricStatus.Normal;
            }
        }
    }
}