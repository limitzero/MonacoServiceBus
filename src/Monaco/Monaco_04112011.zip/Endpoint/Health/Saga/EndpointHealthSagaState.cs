using System;
using System.Collections.Generic;
using Monaco.Sagas;

namespace Monaco.Endpoint.Health.Saga
{
    [Serializable]
    public class EndpointHealthSagaState : ISagaData
    {
        public Guid CorrelationId { get; set; }
        public List<EndpointStatistic> Statistics { get; set; }

        public EndpointHealthSagaState()
        {
            this.Statistics = new List<EndpointStatistic>();
        }

        public void RegisterStatistic(EndpointStatistic statistic)
        {
            if(!this.Statistics.Contains(statistic))
            {
                this.Statistics.Add(statistic);
            }
        }
    }
}