﻿using System;
using System.Collections.Generic;
using System.Linq;
using Monaco.Endpoint.Impl;
using Monaco.Internals;
using Monaco.Internals.Logging;
using Monaco.Messages;
using Monaco.Messages.For.Endpoints;
using Monaco.Messages.For.ServiceBus;
using Monaco.Services;
using Monaco.Services.Impl;

namespace Monaco.Endpoint.Health.Saga
{
    /// <summary>
    /// Saga to record the health and other statistics for endpoints on the message bus.
    /// </summary>
    [Serializable]
    public class EndpointHealthSaga : Sagas.Saga,
        //Saga<EndpointHealthSagaState>,
        StartedBy<BusStartedMessage>,
        Orchestrates<BusStoppingMessage>,
        Orchestrates<EndpointMessageSentMessage>,
        Orchestrates<EndpointMessageReceivedMessage>,
        Orchestrates<EndpointHeartBeatMessage>, 
        Orchestrates<EndpointHealthRecycleStatisticsMessage>,
        Orchestrates<BroadcastStatusForAllEndpointsMessage>,
        Orchestrates<EndpointsStatusInquiryMessage>
    {
        public EndpointHealthSagaState Data { get; set; }

        public EndpointHealthSaga()
        {
            Data = new EndpointHealthSagaState();
        }

        public void Consume(BusStartedMessage message)
        {
            // send out message to control bus denoting all service endpoints 
            // that are present on the current message bus instance:

            IServiceRepository repository = this.Bus.Find<IServiceRepository>();
            IEndpointRegistry registry = this.Bus.Find<IEndpointRegistry>(); 

            if(repository != null && registry != null)
            {
                BaseEndpoint control = registry.Find(Constants.CONTROL_BUS_ENDPONT_NAME);
                BaseEndpoint bus = registry.Find(Constants.MESSAGE_BUS_ENDPOINT_NAME);

                if (control != null && bus != null)
                {
                    ServicedEndpointsMessage servicedEndpointsMessage = new ServicedEndpointsMessage();

                    foreach (BaseService service in repository.Services)
                    {
                        ServicedEndpointMessage sem = new ServicedEndpointMessage();
                        sem.BusUri = bus.Address.Uri;
                        sem.Name = service.Name;
                        sem.EndpointUri = service.Uri;

                        servicedEndpointsMessage.ServicedEndpoints.Add(sem);
                    }

                    Bus.Publish(control.Address.Uri, servicedEndpointsMessage);
                }
            }

        }

        public void Consume(BusStoppingMessage message)
        {
            this.Data = null;
            MarkAsCompleted();
        }

        public void Consume(EndpointsStatusInquiryMessage message)
        {
            List<EndpointStatistic> statistics = new List<EndpointStatistic>();

            foreach (EndpointStatistic statistic in this.Data.Statistics)
            {
                ICollection<EndpointStatistic> endpointStats = this.GetStatisticsForEndpoint(message.EndpointUri);
                EndpointStatistic endpointStatistic =
                    this.ComputeStatistics(message.EndpointUri, endpointStats);

                if (!statistics.Exists(x => x.EndpointUri == endpointStatistic.EndpointUri))
                {
                    statistics.Add(endpointStatistic);
                }
            }

            // send the listing of statistics back to the requestor:
            EndpointStatusResultMessage result =
                new EndpointStatusResultMessage() { Statistics = statistics.Distinct().ToList() };

            Bus.Publish(message.Originator, result);
        }

        public void Consume(BroadcastStatusForAllEndpointsMessage message)
        {

        }

        public void Consume(EndpointHealthRecycleStatisticsMessage message)
        {
            ILogger logger = Bus.Find<ILogger>();

            logger.LogInfoMessage("Recycling all endpoint statistics...");

            this.Data = new EndpointHealthSagaState() {CorrelationId = this.InstanceId};
        }

        public void Consume(EndpointHeartBeatMessage message)
        {
            Bus.Find<ILogger>().LogInfoMessage(string.Format("Heartbeat received from '{0}'.", message.EndpointUri));
            EndpointStatistic statistic = new EndpointStatistic(message.EndpointName, message.EndpointUri);

            message.Received = DateTime.Now;

            statistic.RecordHeartBeat(message);
            Data.RegisterStatistic(statistic);
        }

        public void Consume(EndpointMessageReceivedMessage message)
        {
            Bus.Find<ILogger>().LogInfoMessage(string.Format("Message '{0}' received from endpoint '{1}'.", 
                                                   message.Envelope.GetType().Name,  
                                                   message.EndpointUri));

            EndpointStatistic statistic = new EndpointStatistic(message.EndpointName, message.EndpointUri);
            statistic.RecordMessageReceived();
            Data.RegisterStatistic(statistic);
        }

        public void Consume(EndpointMessageSentMessage message)
        {
            Bus.Find<ILogger>().LogInfoMessage(string.Format("Message '{0}' delivered to endpoint '{1}'.", 
                                                   message.Message.GetType().Name,
                                                   message.EndpointUri));

            EndpointStatistic statistic = new EndpointStatistic(message.EndpointName, message.EndpointUri);
            statistic.RecordMessageSent();
            Data.RegisterStatistic(statistic);
        }

        private ICollection<EndpointStatistic> GetStatisticsForEndpoint(string endpointUri)
        {
            ICollection<EndpointStatistic> statistics = (from theStatistic in this.Data.Statistics
                                                         where
                                                             theStatistic.EndpointUri.Trim().ToLower() ==
                                                             endpointUri.Trim().ToLower()
                                                         select theStatistic).Distinct().ToList();
            return statistics;
        }

        private EndpointStatistic ComputeStatistics(string endpointUri,
                                                    IEnumerable<EndpointStatistic> statistics)
        {
            EndpointStatistic endpointStatistic = new EndpointStatistic(string.Empty, endpointUri);

            foreach (var statistic in statistics)
            {
                endpointStatistic.NumberOfMessagesReceived += statistic.NumberOfMessagesReceived;
                endpointStatistic.NumberOfMessagesSent += statistic.NumberOfMessagesSent;
                endpointStatistic.Heartbeats.AddRange(statistic.Heartbeats);
            }

            endpointStatistic.SetHeartBeatStatus();

            return endpointStatistic;
        }

    }
}