namespace Monaco.Endpoint
{
    /// <summary>
    /// Contract for all registered endpoint builders in the message bus instance.
    /// </summary>
    public interface IEndpointBuilderSubscription
    {
        /// <summary>
        /// Gets or sets the scheme associated with an endpoint.
        /// </summary>
        string Scheme { get; set; }

        /// <summary>
        /// Gets or sets the description of the builder for the scheme.
        /// </summary>
        string Description { get; set; }

        /// <summary>
        /// Gets or sets the fully qualified name of the builder for the endpoint.
        /// </summary>
        string Builder { get; set; }
    }
}