using System;
using System.Collections.Generic;
using System.Linq;
using Monaco.Exceptions;
using Monaco.Internals.Collections;
using Monaco.Messages.For.Timeouts;

namespace Monaco.Agents.Timeout.Impl
{
    public class LocalTimeoutsRepository : ITimeoutsRepository, IDisposable
    {
        private bool _disposing;
        private static readonly object _timeouts_lock = new object();
        private static IThreadSafeList<ScheduleTimeout> _timeouts;

        public LocalTimeoutsRepository()
        {
            if(_timeouts == null)
            {
                _timeouts = new ThreadSafeList<ScheduleTimeout>();
            }
        }

        public void Dispose()
        {
            _disposing = true;

            if (_timeouts != null)
            {
                _timeouts.Clear();
                _timeouts = null;
            }

        }

        public ICollection<ScheduleTimeout> FindAll()
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock(_timeouts_lock)
            {
                return _timeouts;
            }
        }

        public void Add(ScheduleTimeout timeout)
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock (_timeouts_lock)
            {
                _timeouts.Add(timeout);
            }
        }

        public void Remove(ScheduleTimeout timeout)
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock (_timeouts_lock)
            {
                _timeouts.Remove(timeout);
            }
        }

        public void Remove(Guid timeoutId)
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock (_timeouts_lock)
            {
                ScheduleTimeout tm = (from timeout in this.FindAll()
                                      where timeout.Id == timeoutId
                                      select timeout).FirstOrDefault();

                if (tm != null)
                {
                    _timeouts.Remove(tm);
                }
            }
        }
    }
}