using Monaco.Messages.For.Timeouts;

namespace Monaco.Agents.Timeout.Impl
{
    public class TimeoutsConsumer :
        Consumes<ScheduleTimeout>, 
        Consumes<CancelTimeout>
    {
        private readonly IServiceBus _bus;

        public TimeoutsConsumer(IServiceBus bus)
        {
            _bus = bus;
        }

        public void Consume(ScheduleTimeout message)
        {
            TimeoutsAgent agent = _bus.Find<TimeoutsAgent>();

            if(agent != null)
            {
                agent.RegisterTimeout(message);
            }
        }

        public void Consume(CancelTimeout message)
        {
            TimeoutsAgent agent = _bus.Find<TimeoutsAgent>();

            if (agent != null)
            {
                agent.RegisterCancel(message);
            }
        }
    }
}