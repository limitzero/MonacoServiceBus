using System.Collections.Generic;
using log4net;
using Monaco.Internals.Agent;
using Monaco.Messages.For.Timeouts;

namespace Monaco.Agents.Timeout.Impl
{
    public class TimeoutsAgent : BaseAgent, ITimeoutsAgent
    {
        private readonly ILog _log = LogManager.GetLogger(typeof (TimeoutsAgent));

        private readonly IServiceBus _bus;
        private readonly ITimeoutsRepository _repository;

        public TimeoutsAgent(IServiceBus bus, ITimeoutsRepository repository)
        {
            _bus = bus;
            _repository = repository;
            base.Name = "Timeouts Agent";
        	base.Frequency = 1;
        }

        public override void Execute()
        {
            // poll the repository for all timeouts that have expired 
            // and deliver the message out to the interested parties:
            ICollection<ScheduleTimeout> timeouts = _repository.FindAll();

            foreach (ScheduleTimeout timeout in timeouts)
            {
                if (timeout.HasExpired() == true)
                {
                    _bus.Publish(timeout.MessageToDeliver);

                    string msg  = string.Format("Scheduled time out for message '{0}' with instance identifier of '{1}' " +
                                        "created at '{2}' for delivery at '{3}' completed.",
                                        timeout.MessageToDeliver.GetType().FullName,
                                        timeout.Id.ToString(),
                                        timeout.CreatedOn.ToString(),
                                        System.DateTime.Now.ToString());

                    if (_log != null)
                    {
                        _log.Info(msg);
                    }

                    this.RegisterCancel(timeout.CreateCancelMessage());
                }
            }
        }

        public void RegisterTimeout(ScheduleTimeout timeout)
        {
            string msg = string.Format("Time out scheduled for message '{0}' with instance identifier of '{1}' " +
                                        "created at '{2}' for delivery at '{3}'.",
                                        timeout.MessageToDeliver.GetType().FullName,
                                        timeout.Id.ToString(),
                                        timeout.CreatedOn.ToString(),
                                        timeout.At.ToString());

            if (_log != null)
            {
                _log.Info(msg);
            }

            _repository.Add(timeout);
        }

        public void RegisterCancel(CancelTimeout timeout)
        {
            string msg = string.Format("Cancellation message registered for scheduled timeout with " +
                      "corresponding instance id of '{0}'.",
                        timeout.TimeoutId.ToString());

            if (_log != null)
            {
                _log.Info(msg);
            }

            _repository.Remove(timeout.TimeoutId);
        }
    }
}