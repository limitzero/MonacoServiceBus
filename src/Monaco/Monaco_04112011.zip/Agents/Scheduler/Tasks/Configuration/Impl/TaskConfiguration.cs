using System;

namespace Monaco.Agents.Scheduler.Tasks.Configuration.Impl
{
    public class TaskConfiguration : ITaskConfiguration
    {
        public string TaskName { get; set;}
        public Type Component { get; set; }
        public object ComponentInstance { get; set;}
        public string MethodName { get; set;}
        public string Interval { get; set; }
        public bool HaltOnError { get; set; }
        public bool ForceStart { get; set; }

        public TaskConfiguration()
        {
            TaskName = string.Format("TASK-{0}", Guid.NewGuid().ToString());
        }
    }

}