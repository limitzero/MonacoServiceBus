using System;
using System.Collections.Generic;
using System.Linq;
using Castle.MicroKernel;
using Monaco.Agents.Scheduler.EventArgs;
using Monaco.Agents.Scheduler.Tasks.Configuration;
using Monaco.Agents.Scheduler.Tasks.MethodInvoker;
using Monaco.Exceptions;
using Monaco.Internals.Eventing;

namespace Monaco.Agents.Scheduler
{
    /// <summary>
    /// The scheduler is the point in the system where all pollable tasks are registered for execution 
    /// according to their defined intervals.
    /// </summary>
    public class Scheduler : IScheduler
    {
        private readonly IKernel _kernel;
        private List<IScheduledItem> _scheduledItems;
        private bool _disposed;

        public Action<IMessage> OnMessageReceived { get; set; }

        public event EventHandler<ComponentErrorEventArgs> ComponentErrorEvent;

        public event EventHandler<ComponentNotificationEventArgs> ComponentNotificationEvent;

        public ICollection<IScheduledItem> RegisteredItems
        {
            get { return _scheduledItems; }
            set { _scheduledItems = new List<IScheduledItem>(value); }
        }

        public bool IsRunning { get; private set; }

        public Scheduler(IKernel kernel)
        {
            _kernel = kernel;
            if(this._scheduledItems == null)
            {
                _scheduledItems = new List<IScheduledItem>();
            }
        }

        public void Start()
        {
            if (_disposed) return;

            foreach (IScheduledItem item in RegisteredItems)
            {
                this.HookUpEventHandlers(item, true);
                item.Start();
            }

            IsRunning = true;
            OnSchedulerStarted();
        }

        public void Stop()
        {
            foreach (IScheduledItem item in _scheduledItems)
            {
                this.HookUpEventHandlers(item, false);
                item.Stop();
            }

            IsRunning = false;
            OnSchedulerStopped();
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void RegisterItem(IScheduledItem item)
        {
            try
            {
                if (this._scheduledItems.Exists(x => x.Name.Trim().ToLower() == item.Name.Trim().ToLower()) == false)
                {
                    RegisteredItems.Add(item);
                }
            }
            catch
            {
                
            }
        }

        public void CreateScheduledItem(string taskName, string interval, object task, 
            string taskMethod, bool haltOnError, bool forceStart)
        {
            IMethodInvokerScheduledTask theTask = new MethodInvokerScheduledTask();
            theTask.Instance = task;
            theTask.MethodName = taskMethod;
            theTask.Interval = interval;

            IScheduledItem item = new ScheduleItem();
            item.Name = taskName;
            item.Task = theTask;
            item.HaltOnError = haltOnError;
            item.ForceStart = forceStart;

            this.RegisterItem(item);
        }

        public void CreateFromConfiguration(ITaskConfiguration configuration)
        {
            IMethodInvokerScheduledTask theTask = new MethodInvokerScheduledTask();
            string theMethodName = "Produce";
            Type theType = null;

            if(configuration.Component == null && configuration.ComponentInstance == null)
            {
                throw new MonacoConfigurationException(string.Format("The task '{0}' must supply a component type or "  +
                    "component instance for invocation.", configuration.TaskName));
            }

            if(configuration.ComponentInstance != null)
            {
                theType = configuration.ComponentInstance.GetType();
                _kernel.AddComponentInstance(Guid.NewGuid().ToString(),  configuration.ComponentInstance);
            }
            else
            {
                theType = configuration.Component;
                _kernel.AddComponent(Guid.NewGuid().ToString(), configuration.Component);
            }

            object aTask = _kernel.Resolve(theType);

            Type theInterface = (from type in aTask.GetType().GetInterfaces()
                                 where type.FullName.StartsWith(typeof (Produces<>).FullName)
                                 select type).FirstOrDefault();

            if (theInterface == null)
            {
                if(string.IsNullOrEmpty(configuration.MethodName) == true)
                {
                    throw new MonacoConfigurationException(
                        string.Format(
                            "For the task '{0}' using component '{1}', the method that will be executed must be supplied.",
                            configuration.TaskName, theType.FullName));
                } 
            }
            else
            {
                configuration.MethodName = theMethodName;
            }

            theTask.Instance = aTask;
            theTask.MethodName = configuration.MethodName;
            theTask.Interval = configuration.Interval;

            IScheduledItem item = new ScheduleItem();
            item.Name = configuration.TaskName;
            item.Task = theTask;
            item.HaltOnError = configuration.HaltOnError;
            item.ForceStart = configuration.ForceStart;

            this.RegisterItem(item);
        }

        private void HookUpEventHandlers(IScheduledItem scheduledItem, bool enlistOnly)
        {
            if (enlistOnly == true)
            {
                scheduledItem.ScheduledItemError += OnScheduledItemError;
                scheduledItem.ComponentErrorEvent += OnScheduledItemComponentError;
                scheduledItem.ComponentNotificationEvent += OnScheduledItemNotification;
                scheduledItem.ScheduledItemMessageCreated += OnScheduledItemMessageCreated;
            }
            else
            {
                scheduledItem.ScheduledItemError -= OnScheduledItemError;
                scheduledItem.ComponentErrorEvent -= OnScheduledItemComponentError;
                scheduledItem.ComponentNotificationEvent -= OnScheduledItemNotification;
                scheduledItem.ScheduledItemMessageCreated -= OnScheduledItemMessageCreated;
            }
        }

        private void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    this.Stop();
                }

                _disposed = true;
            }
        }

        private void OnSchedulerStarted()
        {
            EventHandler<ComponentNotificationEventArgs> evt = this.ComponentNotificationEvent;

            if (evt != null)
            {
                evt(this, new ComponentNotificationEventArgs("Scheduler Started."));
            }
        }

        private void OnSchedulerStopped()
        {
            EventHandler<ComponentNotificationEventArgs> evt = this.ComponentNotificationEvent;

            if(evt != null)
            {
                evt(this, new ComponentNotificationEventArgs("Scheduler Stopped."));
            }
        }

        private bool OnSchedulerError(Exception exception)
        {
            EventHandler<ComponentErrorEventArgs> evt = this.ComponentErrorEvent;

            bool isHandlerAttached = (evt != null);

            if (isHandlerAttached)
                evt(this, new ComponentErrorEventArgs(exception));

            return isHandlerAttached;
        }

        private void OnScheduledItemComponentError(object sender, ComponentErrorEventArgs e)
        {
            Exception itemException = new Exception(e.ErrorMessage, e.Exception);
            this.OnSchedulerError(itemException);
        }

        private void OnScheduledItemMessageCreated(object sender, ScheduledItemMessageCreatedEventArgs e)
        {
            if (e.Message != null)
            {
                if(this.OnMessageReceived  != null)
                {
                    this.OnMessageReceived(e.Message);
                }
            }
        }

        private void OnScheduledItemNotification(object sender, ComponentNotificationEventArgs e)
        {
            EventHandler<ComponentNotificationEventArgs> evt = this.ComponentNotificationEvent;

            if(evt != null)
            {
                evt(this, new ComponentNotificationEventArgs(e.Level, e.Message));
            }
        }

        private void OnScheduledItemError(object sender, ScheduledItemErrorEventArgs e)
        {
            if(e.ScheduledItem.HaltOnError == true)
            {
                e.ScheduledItem.Stop();

                ComponentNotificationEventArgs notificationEventArgs = 
                    new ComponentNotificationEventArgs(NotificationLevel.Warn,
                                                       string.Format("Task '{0}' forcibly stopped on error: Reason: {1}", e.ScheduledItem.Name, e.Exception.StackTrace));

                this.OnScheduledItemNotification(this, notificationEventArgs);
            }
            else
            {
                ComponentNotificationEventArgs notificationEventArgs =
                    new ComponentNotificationEventArgs(NotificationLevel.Warn,
                                                       string.Format("Task '{0}' experinced an error: Message: {1}", e.ScheduledItem.Name, e.Exception.StackTrace));
                this.OnScheduledItemNotification(this, notificationEventArgs);
            }

        }


    }
}