namespace Monaco.Agents.Scheduler.EventArgs
{
    public class ScheduledTaskMessageCreatedEventArgs : System.EventArgs
    {
        public IScheduledTask Task { get; private set; }
        public IMessage Message { get; private set; }

        public ScheduledTaskMessageCreatedEventArgs(IScheduledTask task, IMessage message)
        {
            Task = task;
            Message = message;
        }
    }
}