namespace Monaco.Agents.Scheduler.EventArgs
{
    public class ScheduledItemMessageCreatedEventArgs : System.EventArgs
    {
        public IMessage Message { get; private set; }

        public ScheduledItemMessageCreatedEventArgs(IMessage message)
        {
            Message = message;
        }
    }
}