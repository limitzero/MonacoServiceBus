using System;

namespace Monaco.Agents.Scheduler.EventArgs
{
    public class ScheduledItemErrorEventArgs : System.EventArgs
    {
        public IScheduledItem ScheduledItem { get; private set; }
        public Exception Exception { get; private set; }

        public ScheduledItemErrorEventArgs(IScheduledItem scheduledItem, Exception exception)
        {
            ScheduledItem = scheduledItem;
            Exception = exception;
        }
    }
}