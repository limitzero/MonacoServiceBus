using System;
using Monaco.Agents.Scheduler.EventArgs;
using Monaco.Internals.Eventing;

namespace Monaco.Agents.Scheduler
{
    /// <summary>
    /// Contract for a scheduled task.
    /// </summary>
    public interface IScheduledTask : INotificationEventBroadcaster, IErrorEventBroadcaster
    {
        event EventHandler<ScheduledTaskMessageCreatedEventArgs> ScheduledTaskMessageCreated;

        /// <summary>
        /// (Read-Write). The interval, in seconds, that the method on the component should be polled.
        /// </summary>
        string Interval { get; set; }

        /// <summary>
        /// This will execute the scheduled task.
        /// </summary>
        void Execute();
    }
}