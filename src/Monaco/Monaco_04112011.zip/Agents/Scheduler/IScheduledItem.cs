using System;
using Monaco.Agents.Scheduler.EventArgs;
using Monaco.Internals;
using Monaco.Internals.Eventing;

namespace Monaco.Agents.Scheduler
{
    public interface IScheduledItem : IStartable, INotificationEventBroadcaster, IErrorEventBroadcaster
    {
        event EventHandler<ScheduledItemMessageCreatedEventArgs> ScheduledItemMessageCreated;
        event EventHandler<ScheduledItemErrorEventArgs> ScheduledItemError;

        string Name { get; set; }
        bool HaltOnError { get; set; }
        bool ForceStart { get; set; }
        IScheduledTask Task { get; set; }
    }
}