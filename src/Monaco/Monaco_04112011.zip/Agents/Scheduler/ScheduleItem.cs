using System;
using System.Threading;
using Monaco.Agents.Scheduler.EventArgs;
using Monaco.Extensions;
using Monaco.Internals.Eventing;

namespace Monaco.Agents.Scheduler
{
    public class ScheduleItem : IScheduledItem
    {
        private bool _disposed;
        private Timer _timer;

        public event EventHandler<ComponentErrorEventArgs> ComponentErrorEvent;
        public event EventHandler<ComponentNotificationEventArgs> ComponentNotificationEvent;
        public event EventHandler<ScheduledItemMessageCreatedEventArgs> ScheduledItemMessageCreated;
        public event EventHandler<ScheduledItemErrorEventArgs> ScheduledItemError;

        public string Name { get; set;}
      
        public bool HaltOnError { get; set;}

        public bool ForceStart { get; set; }

        public IScheduledTask Task
        {
            get;
            set;
        }

        public bool IsRunning
        {
            get; 
            private set;
        }

        public ScheduleItem()
        {
            this.Name = string.Format("TASK-{0}", Guid.NewGuid().ToString());
        }

        public void Start()
        {
            if (_disposed)
                return;

            if (this.IsRunning)
            {
                return;
            }

            if(string.IsNullOrEmpty(this.Task.Interval))
            {
                return;
            }

            if (string.IsNullOrEmpty(this.Name))
            {
                this.Name = string.Format("TASK-{0}", Guid.NewGuid().ToString());
            }

            this.HookupEventHandlers(this.Task, true);

            if(this.ForceStart == true)
            {
                this.ExecuteTask(null);    
            }

            this._timer = new Timer(ExecuteTask, null, 100, 
                new TimeSpan().CreateFromInterval(Task.Interval).Value.Seconds * 1000);

            this.IsRunning = true;
        }

        public void Stop()
        {
            if (this._timer != null)
            {
                _timer.Dispose();
            }

            this.HookupEventHandlers(this.Task, false);;
            this.IsRunning = false;
        }

        private void HookupEventHandlers(IScheduledTask task, bool enlistOnly)
        {
            if(enlistOnly == true)
            {
                this.Task.ComponentErrorEvent += OnTaskError;
                this.Task.ComponentNotificationEvent += OnTaskNotification;
                this.Task.ScheduledTaskMessageCreated += OnTaskMessageCreated;
            }
            else
            {               
                this.Task.ComponentErrorEvent -= OnTaskError;
                this.Task.ComponentNotificationEvent -= OnTaskNotification;
                this.Task.ScheduledTaskMessageCreated -= OnTaskMessageCreated;
            }
        }

        private void ExecuteTask(object state)
        {
            try
            {
                OnScheduledItemStarted();
                if (_disposed) return;

                OnScheduledItemNotification(this, 
                                            new ComponentNotificationEventArgs(NotificationLevel.Info, 
                                                                               string.Format("Executing scheduled task '{0}'", this.Name)));

                this.Task.Execute();
               
            }
            catch (Exception exception)
            {
                if (!OnScheduledItemError(exception))
                    throw;
            }
            finally
            {
                OnScheduledItemCompleted();
            }

        }

        public void Dispose()
        {
            this.OnDisposing(true);
            GC.SuppressFinalize(this);
        }

        private void OnDisposing(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    this.Stop();
                }

                _disposed = true;
            }
        }

        private void OnTaskMessageCreated(object sender, ScheduledTaskMessageCreatedEventArgs e)
        {
            OnScheduledItemMessageCreated(e.Message);
        }

        private void OnTaskNotification(object sender, ComponentNotificationEventArgs e)
        {
            this.OnScheduledItemNotification(sender, e);
        }

        private void OnTaskError(object sender, ComponentErrorEventArgs e)
        {
            if(this.HaltOnError == true)
            {
                this.Stop();
                string message = string.Format("Scheduled task '{0}' forcibly stopped. Reason: [{1}], Stack Trace: {2}.'", this.Name,
                                               e.ErrorMessage, e.Exception.StackTrace);
                this.OnScheduledItemNotification(this, new ComponentNotificationEventArgs(NotificationLevel.Warn, message));
            }
        }

        private void OnScheduledItemMessageCreated(IMessage message)
        {
            EventHandler<ScheduledItemMessageCreatedEventArgs> evt = this.ScheduledItemMessageCreated;

            if (evt != null)
            {
                evt(this, new ScheduledItemMessageCreatedEventArgs(message));
            }
        }

        private void OnScheduledItemNotification(object sender, ComponentNotificationEventArgs e)
        {
            EventHandler<ComponentNotificationEventArgs> evt = this.ComponentNotificationEvent;

            if(evt != null)
            {
                evt(this, new ComponentNotificationEventArgs(e.Level, e.Message));
            }
        }

        private bool OnScheduledItemError(Exception exception)
        {
            EventHandler<ScheduledItemErrorEventArgs> evt = this.ScheduledItemError;

            var isEventHandlerAttached = (evt != null);

            if (isEventHandlerAttached)
                evt(this, new ScheduledItemErrorEventArgs(this, exception));

            return isEventHandlerAttached;
        }

        private void OnScheduledItemStarted()
        {
            EventHandler<ComponentNotificationEventArgs> evt = this.ComponentNotificationEvent;
            if (evt != null)
            {
                evt(this, new ComponentNotificationEventArgs(string.Format("Scheduled item {0} started.", this.Name)));
            }
        }

        private void OnScheduledItemCompleted()
        {
            EventHandler<ComponentNotificationEventArgs> evt = this.ComponentNotificationEvent;
            if (evt != null)
            {
                evt(this, new ComponentNotificationEventArgs(string.Format("Scheduled item {0} completed", this.Name)));
            }
        }


    }
}