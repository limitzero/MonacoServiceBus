namespace Monaco.Subscriptions
{
    /// <summary>
    /// Contract for individual components that wish to 
    /// manage the lifetime of their consumed messages
    /// on the bus instance for subscription.
    /// </summary>
    public interface ISubscriptionLifecycle 
    {
        void Start(IServiceBus bus);
        void Stop(IServiceBus bus);
    }
}