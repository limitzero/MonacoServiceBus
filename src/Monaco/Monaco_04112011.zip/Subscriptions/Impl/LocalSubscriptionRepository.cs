using System.Collections.Generic;
using System.Linq;
using Monaco.Internals.Collections;

namespace Monaco.Subscriptions.Impl
{
    /// <summary>
    /// Volatile instance of local subscription repository for the local message bus.
    /// </summary>
    public class LocalSubscriptionRepository : ISubscriptionRepository
    {
        private static readonly object _subscriptions_lock = new object();
        private readonly IThreadSafeList<Subscription> _subscriptions;

        public ICollection<Subscription> Subscriptions
        {
            get { return _subscriptions; }
        }

        public LocalSubscriptionRepository()
        {
            if(this._subscriptions == null)
            {
                this._subscriptions = new ThreadSafeList<Subscription>();
            }
        }

        public ICollection<Subscription> Find(IMessage message)
        {
            lock (_subscriptions_lock)
            {
                ICollection<Subscription> subscriptions = (from item in this._subscriptions
                                                            where
                                                                item.Message.Trim().ToLower() ==
                                                                message.GetType().FullName.Trim().ToLower()
                                                            select item).ToList();

                return subscriptions;
            }
        }

        public void Register(ISubscription subscription)
        {
            lock (_subscriptions_lock)
            {
                if(this._subscriptions.Contains(subscription as Subscription) == false)
                {
                    this._subscriptions.Add(subscription as Subscription);
                }
            }
        }

        public void Unregister(ISubscription subscription)
        {
            lock (_subscriptions_lock)
            {
                if (this._subscriptions.Contains(subscription as Subscription) == true)
                {
                    this._subscriptions.Remove(subscription as Subscription);
                }
            }
        }
    }
}