using System;

namespace Monaco.Subscriptions.Impl
{
    /// <summary>
    /// Concrete instance of a message subscription.
    /// </summary>
    [Serializable]
    public class Subscription : ISubscription
    {
        public Guid Id { get; set; }
        public bool IsActive { get; set;}
        public string Uri { get; set; }
        public string Component { get; set; }
        public string Message { get; set; }

        public Subscription()
            :this(true, string.Empty, string.Empty, string.Empty)
        {
            
        }

        public Subscription(bool isActive, string uri, string component, string message)
        {
            Id = Guid.NewGuid();
            IsActive = isActive;
            Uri = uri;
            Component = component;
            Message = message;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is Subscription))
            {
                return false;
            }

            Subscription that = (Subscription)obj;
            if (this.Id == null || that.Id == null || !this.Id.Equals(Id))
            {
                return false;
            }
            return true;
        }

        public override int GetHashCode()
        {
            int hashCode = 0;
            hashCode = 107 * hashCode + (Id == null ? 0 : Id.GetHashCode());
            return hashCode;
        }
    }
}