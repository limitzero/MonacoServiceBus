using System.Collections.Generic;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Internals;
using Monaco.Messages.For.ServiceBus;
using Monaco.Messages.For.Subscriptions;

namespace Monaco.Subscriptions.Saga
{
    /// <summary>
    /// Saga to coordinate all actions that occur with subscriptions for this message bus instance.
    /// </summary>
    public class SubscriptionsSaga :Sagas.Saga,
        StartedBy<BusStartedMessage>,
        Orchestrates<BusStoppingMessage>,
        Orchestrates<RegisterSubscriptionMessage>,
        Orchestrates<UnregisterSubscriptionMessage>
    {
        public void Consume(BusStartedMessage message)
        {
            // send out message to subscription manager denoting all subscriptions 
            // on this local message bus instance for global pub/sub:
            IEndpointRegistry registry = this.Bus.Find<IEndpointRegistry>();
            ISubscriptionRepository repository = this.Bus.Find<ISubscriptionRepository>();

            if (registry != null & repository != null)
            {
                BaseEndpoint subscription = registry.Find(Constants.SUBSCRIPTION_MANAGER_ENDPOINT_NAME);
                BaseEndpoint bus = registry.Find(Constants.MESSAGE_BUS_ENDPOINT_NAME);

                if (subscription != null & bus != null)
                {
                    var localSubscriptionsMessage = new LocalSubscriptionsMessage(bus.Address.Uri,
                                                                                  repository.Subscriptions);

                    this.Bus.Publish(subscription.Address.Uri, localSubscriptionsMessage);
                }
            }
        }

        public void Consume(BusStoppingMessage message)
        {
            this.MarkAsCompleted();
        }

        public void Consume(RegisterSubscriptionMessage message)
        {
            ISubscriptionRepository repository = this.Bus.Find<ISubscriptionRepository>();

            if (repository != null)
            {
                repository.Register(message.Subscription);
            }
        }

        public void Consume(UnregisterSubscriptionMessage message)
        {
            ISubscriptionRepository repository = this.Bus.Find<ISubscriptionRepository>();

            if (repository != null)
            {
                repository.Unregister(message.Subscription);
            }
        }
    }
}