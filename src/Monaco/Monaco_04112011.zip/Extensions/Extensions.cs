using System;

namespace Monaco.Extensions
{
    public static class Extensions
    {
        static Extensions()
        {
        }

        /// <summary>
        /// This will create a timespan object from the interval "hh:mm:ss"
        /// (hours, minutes, seconds)
        /// </summary>
        /// <example>
        /// TimeSpan.CreateFromInterval("00:10:00");
        /// </example>
        /// <param name="value">Current TimeSpan object</param>
        /// <param name="interval">Current interval to create for TimeSpan</param>
        /// <returns></returns>
        public static TimeSpan? CreateFromInterval(this TimeSpan value, string interval)
        {
            TimeSpan? theTimeSpan = null;


            try
            {
                var theParts = interval.Split(new char[] { ':' });
                if (theParts.Length != 3) return theTimeSpan;

                int theHours = 0;
                Int32.TryParse(theParts[0], out theHours);

                int theMinutes = 0;
                Int32.TryParse(theParts[1], out theMinutes);

                int theSeconds = 0;
                Int32.TryParse(theParts[2], out theSeconds);

                theTimeSpan = new TimeSpan(theHours, theMinutes, theSeconds);
            }
            catch 
            {    
            }

            return theTimeSpan;
        }
    }
}