using System;
using Monaco.Exceptions;
using Monaco.Internals.Collections;
using Monaco.Internals.Serialization;
using Monaco.Messages;

namespace Monaco.Sagas.Impl
{
    public class LocalSagaDataFinder<TDATA> : IDisposable,
         ISagaDataRepository<TDATA> where TDATA : class, ISagaData, new()
    {
        private readonly ISerializationProvider _serializer;
        private static readonly object _threads_lock = new object();
        private static IThreadSafeDictionary<Guid, SagaDataThread> _threads;
        private bool _disposing;

        public LocalSagaDataFinder(ISerializationProvider serializer)
        {
            _serializer = serializer;

            if(_threads == null)
            {
                _threads = new ThreadSafeDictionary<Guid, SagaDataThread>();
            }
        }

        public void Dispose()
        {
            this._disposing = true;

            if(_threads  != null)
            {
                _threads.Clear();
                _threads = null;
            }
        }

        public TDATA Find(Guid instanceId)
        {
            TDATA theData = default(TDATA);

            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock (_threads_lock)
            {
                SagaDataThread thread = null;
                _threads.TryGetValue(instanceId, out thread);

                if (thread != null)
                {
                    theData = _serializer.Deserialize(thread.Instance) as TDATA;

                    if(theData != null)
                    {
                        theData.CorrelationId = instanceId;
                    }
                }

                return theData;
            }
        }

        public TDATA Create(Guid instanceId)
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            return new TDATA() {CorrelationId =  instanceId};
        }

        public void Save(TDATA data)
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock (_threads_lock)
            {
                SagaDataThread thread = null;
                _threads.TryGetValue(data.CorrelationId, out thread);

                if (thread != null)
                {
                    _threads.Remove(thread.InstanceId);
                    thread = this.CreateThread(data, thread);
                }
                else
                {
                    thread = this.CreateThread(data, null);
                }

                thread.ModifiedOn = DateTime.Now;

                _threads.Add(thread.InstanceId, thread);
            }
        }

        public void Remove(Guid instanceId)
        {

            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock (_threads_lock)
            {
                _threads.Remove(instanceId);
            }
        }

        private SagaDataThread CreateThread(TDATA data, SagaDataThread previousThread)
        {
            SagaDataThread theThread = new SagaDataThread();

            if (previousThread != null)
            {
                theThread.CreatedOn = previousThread.CreatedOn;
            }
            else
            {
                theThread.CreatedOn = DateTime.Now;
            }

            theThread.InstanceId = data.CorrelationId;
            theThread.Instance = _serializer.SerializeToBytes(data);
            theThread.SagaDataName = data.GetType().FullName;

            return theThread;
        }


    }
}