using System;
using System.Linq;
using Monaco.Exceptions;
using Monaco.Internals.Collections;
using Monaco.Internals.Serialization;
using Monaco.Messages;

namespace Monaco.Sagas.Impl
{
    /// <summary>
    /// Volatile instance of repository for storing saga instances.
    /// </summary>
    public class LocalSagaRepository : ISagaRepository, IDisposable
    {
        private bool _disposing;
        private readonly ISerializationProvider _serializer;
        private static readonly object _threads_lock = new object();
        private static IThreadSafeList<SagaThread> _threads;

        public LocalSagaRepository(ISerializationProvider serializer)
        {
            _serializer = serializer;

            if(_threads == null)
            {
                _threads = new ThreadSafeList<SagaThread>();
            }
        }

        public void Dispose()
        {
            _disposing = true;

            if(_threads != null)
            {
                _threads.Clear();
                _threads = null;
            }
        }

        public ISaga Find(Guid instanceId)
        {
            ISaga theSaga = null; 

            if(this._disposing == true)
            {
                throw new DisposingException();
            }

            lock(_threads_lock)
            {
                SagaThread theThread = (from thread in _threads
                                        where thread.InstanceId == instanceId
                                        select thread).FirstOrDefault();

                if(theThread != null)
                {
                    theSaga = _serializer.Deserialize(theThread.Instance) as ISaga;
                }

                return theSaga;
            }
        }

        public void Save(ISaga saga)
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock (_threads_lock)
            {
                SagaThread theThread = (from thread in _threads
                                        where thread.InstanceId == saga.InstanceId
                                        select thread).FirstOrDefault();

                if (theThread != null)
                {
                    _threads.Remove(theThread);
                    theThread = this.CreateThread(saga, theThread);
                }
                else
                {
                    theThread = this.CreateThread(saga, null);
                }

                theThread.ModifiedOn = DateTime.Now;

                _threads.Add(theThread);
            }
        }

        public void Remove(Guid instanceId)
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock(_threads_lock)
            {
                SagaThread theThread = (from thread in _threads
                                        where thread.InstanceId ==instanceId
                                        select thread).FirstOrDefault();

                if(theThread != null)
                {
                    _threads.Remove(theThread);
                }
            }
        }

        private SagaThread CreateThread(ISaga saga, SagaThread previousThread)
        {
            SagaThread theThread =new SagaThread();

            if(previousThread != null)
            {
                theThread.CreatedOn = previousThread.CreatedOn;
            }
            else
            {
                theThread.CreatedOn = DateTime.Now;
            }

            theThread.InstanceId = saga.InstanceId;
            theThread.Instance = _serializer.SerializeToBytes(saga);
            theThread.SagaName = saga.GetType().FullName;

            return theThread;
        }
    }
}