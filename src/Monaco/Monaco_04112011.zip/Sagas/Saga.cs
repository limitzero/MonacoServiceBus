﻿using System;
using System.Xml.Serialization;

namespace Monaco.Sagas
{
    /// <summary>
    /// Base implementation of a long-running process.
    /// </summary>
    [Serializable]
    public abstract class Saga : ISaga
    {
        [XmlIgnore]
        public IServiceBus Bus { get; set; }

    	/// <summary>
    	/// Gets or sets the instance identifier for the saga instance.
    	/// </summary>
    	public Guid InstanceId { get; set; }

    	/// <summary>
    	/// Gets or sets the flag to indicate whether or not the process has completed.
    	/// </summary>
    	public bool IsCompleted { get; set; }

        public void MarkAsCompleted()
        {
            IsCompleted = true;
        }
    }

    /// <summary>
    /// Base implementation of a long-running process with a defined persisted 
    /// data entity for keeping data between long-running process calls.
    /// </summary>
    /// <typeparam name="TDATA">Type of the data to keep persisted between calls.</typeparam>
    [Serializable]
    public abstract class Saga<TDATA> : Saga, ISaga<TDATA> where TDATA : class, ISagaData, new()
    {
		/// <summary>
		/// Gets or sets the data associated with the saga.
		/// </summary>
        public TDATA Data { get; set; }

    }
}