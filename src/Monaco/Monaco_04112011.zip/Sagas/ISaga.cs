using System;

namespace Monaco.Sagas
{
    /// <summary>
    /// Contract for long-running transactions within the message bus environment.
    /// </summary>
    public interface ISaga
    {
        /// <summary>
        /// Gets or sets the instance identifier for the saga instance.
        /// </summary>
        Guid InstanceId { get; set; }

        /// <summary>
        /// Gets or sets the flag to indicate whether or not the process has completed.
        /// </summary>
        bool IsCompleted { get; set; }
    }

    /// <summary>
    /// Contract for long-running transactions within the message bus environment
    /// that can have data persisted between calls to the active instance.
    /// </summary>
    /// <typeparam name="TDATA">Data that is kept between calls to the saga.</typeparam>
    public interface ISaga<TDATA> : ISaga where TDATA : class, ISagaData, new()
    {
        /// <summary>
        /// Gets or sets the data that is associated with the saga.
        /// </summary>
        TDATA Data { get; set; }
    }
}