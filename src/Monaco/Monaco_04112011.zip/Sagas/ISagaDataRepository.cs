using System;

namespace Monaco.Sagas
{
    /// <summary>
    /// Contract that represents the primary construct for retreiving 
    /// data for a saga instance for interjecting into a saga instance.
    /// </summary>
    /// <typeparam name="TDATA"></typeparam>
    public interface ISagaDataRepository<TDATA> where TDATA : class, ISagaData, new()
    {
        /// <summary>
        /// This will find the instance of the data used for the saga.
        /// </summary>
        /// <param name="instanceId"></param>
        /// <returns></returns>
        TDATA Find(Guid instanceId);

        /// <summary>
        /// This will create a new instance of the data used for the saga.
        /// </summary>
        TDATA Create(Guid instanceId);

        /// <summary>
        /// This will save the data associated with the saga,
        /// </summary>
        void Save(TDATA data);

        /// <summary>
        /// This will remove the data associated with the saga
        /// </summary>
        void Remove(Guid instanceId);
    }
}