using System;

namespace Monaco.Sagas
{
    /// <summary>
    /// Contract that represents the data that is saved between 
    /// calls for a saga that can be persisted to an external store.
    /// </summary>
    public interface ISagaData : IMessage
    {
        /// <summary>
        /// Gets or sets the unique identifier for the saga instance
        /// that should be associated with the data for the saga.
        /// </summary>
        Guid CorrelationId { get; set; }
    }
}