using System;
using Monaco.Internals.Callbacks;
using Rhino.Mocks;

namespace Monaco.Sagas.Testing
{
    public class SagaTestScenario : IDisposable
    {
        private readonly MockRepository _mockRepository;
        private readonly Saga _theSaga;
        private readonly IServiceBus _theServiceBus;
        private ICallback _callback;

        public delegate void PublishDelegate(IMessage message);

        public SagaTestScenario(MockRepository mockRepository, Saga theSaga, IServiceBus theMessageBus)
        {
            _mockRepository = mockRepository;

            _theSaga = theSaga;

            _theServiceBus = theMessageBus;

            _theSaga.Bus = theMessageBus;
        }

        public void Dispose()
        {
           
        }

        /// <summary>
        /// This will represent a point on the saga where a message can be received on the saga for processing.
        /// </summary>
        /// <param name="when">The functon on the saga that will consume the message</param>
        /// <returns></returns>
        public void WhenItConsumes(Action when)
        {
            _mockRepository.ReplayAll();
            when();
            _mockRepository.VerifyAll();
        }

        /// <summary>
        /// This will execute a series of logical steps in the saga without 
        /// publishing a message.
        /// </summary>
        /// <param name="theAction">The custom code to execute.</param>
        /// <returns></returns>
        public SagaTestScenario ItWillExecute(Action theAction)
        {
            theAction();
            return this;
        }

        /// <summary>
        /// This will indicate within the saga that it has transitioned 
        /// to a particular state.
        /// </summary>
        /// <param name="state">Name of the state to transition to.</param>
        /// <returns></returns>
        public SagaTestScenario ItWillMarkATransitionTo(string state)
        {
            //_theSaga.TransitionTo(state);
            LastCall.Repeat.AtLeastOnce()
                .Message(string.Format("The saga should indicate that has transitioned to state '{0}'.", state));
            return this;
        }

        /// <summary>
        /// This will mark a point where the saga will send a message and 
        /// expect back a response via a callback.
        /// </summary>
        /// <typeparam name="TSAGAMESSAGE"></typeparam>
        /// <param name="sendAction"></param>
        /// <returns></returns>
        public SagaTestScenario ItWillSend<TSAGAMESSAGE>(Func<TSAGAMESSAGE> sendAction)
            where TSAGAMESSAGE : class, IMessage
        {
            _callback = _mockRepository.DynamicMock<ICallback>();
            TSAGAMESSAGE theSentMessage = sendAction();

            Expect.Call(_theServiceBus.Send(theSentMessage))
                .Repeat.AtLeastOnce()
                .Return(_callback)
                .Message(
                "The saga should send a message and register a callback to handle the subsequent reply message.");

            return this;
        }

        public SagaTestScenario ItWillReplyWith<TSAGAMESSAGE>(Func<TSAGAMESSAGE> replyAction)
            where TSAGAMESSAGE : class, IMessage, new()
        {
            TSAGAMESSAGE theReplyMessage = replyAction();

            //_theSaga.Reply(theReplyMessage);
            _theServiceBus.Reply(theReplyMessage);

            LastCall.IgnoreArguments()
                .Message(
                string.Format("The saga should reply back to the caller with the message '{0}' after the custom logic has been executed.",
                              typeof(TSAGAMESSAGE).FullName));
            return this;
        }

        /// <summary>
        /// This will represent a point on the saga where the message will be consumed and 
        /// another distinct message will be produced via the custom logic in the corresponding 
        /// method and published out for consumption by other consumers via the message bus.
        /// </summary>
        /// <typeparam name="TSAGAMESSAGE"></typeparam>
        /// <param name="publishAction">Logic that will executed and publish a message</param>
        /// <returns></returns>
        public SagaTestScenario ItWillPublish<TSAGAMESSAGE>(Func<TSAGAMESSAGE> publishAction)
            where TSAGAMESSAGE : class, IMessage, new()
        {
            TSAGAMESSAGE thePublishedMessage = publishAction();

            _theServiceBus.Publish(thePublishedMessage);

            LastCall.IgnoreArguments().Repeat.AtLeastOnce()
                .Message(
                string.Format("The saga should publish the message '{0}' after the custom " + 
                "logic has been executed. ",
                              typeof(TSAGAMESSAGE).FullName));

            return this;
        }

        /// <summary>
        /// This will represent a point on the saga where the message will be consumed and 
        /// a set of distinct messages will be produced via the custom logic in the corresponding 
        /// method and published out for consumption by other consumers via the message bus.
        /// </summary>
        /// <param name="publishAction"></param>
        /// <returns></returns>
        public SagaTestScenario ItWillPublishAMessageBatch(Func<IMessage[]> publishAction)
        {
            IMessage[] thePublishedMessages = publishAction();

            var theMessages = string.Empty;
            foreach (var theMessage in theMessages)
            {
                theMessages = string.Concat(theMessage.GetType().FullName, ", ");
            }
            theMessages.TrimEnd(new char[] { ',', ' ' });

            //_theSaga.Publish(thePublishedMessages);

            _theServiceBus.Publish(thePublishedMessages);
            LastCall.IgnoreArguments().Repeat.Times(theMessages.Length)
                .Message(
                string.Format("The saga should publish the messages '{0}' after the custom logic has been executed.",
                              theMessages));
            return this;
        }

        /// <summary>
        /// This will represent a point on the saga where the message will be consumed and 
        /// another distinct message will be produced via the custom logic in the corresponding 
        /// method and published out for consumption by other consumers via the message bus.
        /// </summary>
        /// <typeparam name="TSAGAMESSAGE"></typeparam>
        /// <param name="endpointUri">Uri that the message will be published out to.</param>
        /// <param name="publishAction">Logic that will executed and publish a message</param>
        /// <returns></returns>
        public SagaTestScenario ItWillPublishToEndpoint<TSAGAMESSAGE>(string endpointUri,
                                                                      Func<TSAGAMESSAGE> publishAction)
            where TSAGAMESSAGE : class, IMessage
        {
            TSAGAMESSAGE thePublishedMessage = publishAction();

            //_theSaga.Publish(endpointUri,  thePublishedMessage);

            _theServiceBus.Publish(endpointUri, thePublishedMessage);

            LastCall.Repeat.AtLeastOnce()
                .Message(
                string.Format("The saga should publish the message '{0}' to the location '{1}' after the custom logic has been executed.",
                              typeof(TSAGAMESSAGE).FullName, endpointUri));
            return this;
        }
    }
}