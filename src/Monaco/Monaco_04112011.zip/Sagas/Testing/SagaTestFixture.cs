using System.Linq;
using System.Reflection;
using System;
using Castle.MicroKernel;
using Monaco.Internals.Reflection;
using Rhino.Mocks;

namespace Monaco.Sagas.Testing
{
    /// <summary>
    /// Base test fixture used for unit testing sagas.
    /// </summary>
    /// <typeparam name="TSAGA">The type of the saga to test</typeparam>
    public abstract class SagaTestFixture<TSAGA> : IDisposable where TSAGA : Saga
    {
        private MockRepository _mocks = null;
        private IServiceBus _messageBus;

        /// <summary>
        /// The current saga scenario under test. The scenario 
        /// is read from the bottom-up.
        /// </summary>
        public SagaTestScenario Saga { get; private set; }

        /// <summary>
        /// This will prepare the saga for testing under the current user-defined scenario.
        /// </summary>
        /// <returns></returns>
        protected TSAGA PrepareSaga()
        {
            _mocks = new MockRepository();
            Guid InstanceId = Guid.NewGuid();

            TSAGA saga = _mocks.PartialMock<TSAGA>();

            saga.InstanceId = InstanceId; 

            _messageBus = _mocks.DynamicMock<IServiceBus>();

            SetSagaData(saga, InstanceId);

            Saga = new SagaTestScenario(_mocks, saga, _messageBus);

            return saga;
        }

        public void Dispose()
        {
            _mocks = null;
            _messageBus = null;
            Saga = null;
        }

        private void SetSagaData(TSAGA saga, Guid InstanceId)
        {
            if (this.ContainsInterface(saga, typeof(ISaga<>)) != null)
            {
                // need to instantiate new data for saga and sync the instance 
                // identifier with the instance identifier of the saga (testing of course):
                PropertyInfo theSagaDataProperty = this.GetSagaDataProperty(saga);

                try
                {
                    IReflection reflection = new DefaultReflection(new DefaultKernel());
                    ISagaData theData = reflection.BuildInstance(theSagaDataProperty.PropertyType.AssemblyQualifiedName) as ISagaData;

                    if (theData != null)
                    {
                        theData.CorrelationId = InstanceId;
                        saga.GetType().GetProperty("Data").SetValue(saga, theData, null);
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
            }
        }

        private PropertyInfo GetSagaDataProperty(object theSaga)
        {
            PropertyInfo theDataProperty = null;

            if (this.ContainsInterface(theSaga, typeof(ISaga<>)) != null)
            {
                try
                {
                    theDataProperty = (from property in theSaga.GetType().GetProperties()
                                       where property.Name.Trim().ToLower() == "data"
                                       select property).FirstOrDefault();
                }
                catch (Exception e)
                {
                    throw;
                }
            }
            return theDataProperty;
        }

        private Type ContainsInterface(object theComponent, Type interfaceType)
        {
            Type theInterface = (from contract in theComponent.GetType().GetInterfaces()
                                 where contract.IsGenericType == true
                                       &&
                                       contract.FullName.StartsWith(interfaceType.FullName)
                                 select contract).FirstOrDefault();

            return theInterface;
        }
    }
}