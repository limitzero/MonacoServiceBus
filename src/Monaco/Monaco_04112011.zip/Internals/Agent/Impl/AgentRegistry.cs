using System;
using System.Collections.Generic;
using Monaco.Exceptions;
using Monaco.Internals.Collections;

namespace Monaco.Internals.Agent.Impl
{
    public class AgentRegistry : IAgentRegistry, IDisposable
    {
        private static readonly object _registry_lock = new object();
        private bool _disposing;
        private IThreadSafeList<BaseAgent> _registry;
        
        public AgentRegistry()
        {
            if(this._registry == null)
            {
                this._registry = new ThreadSafeList<BaseAgent>();
            }
        }

        public void Dispose()
        {
            _disposing = true;

            if(_registry != null)
            {
                _registry.Clear();
                _registry = null;
            }
        }

        public ICollection<BaseAgent> Agents
        {
            get
            {
                if(this._disposing == true)
                {
                    throw new DisposingException();
                }

                lock (_registry_lock)
                {
                    return this._registry.Instance;
                }
            }
        }

        public void Register(BaseAgent agent)
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock (_registry_lock)
            {

                if (!this._registry.Contains(agent))
                {
                    this._registry.Add(agent);
                }
            }
        }

        public void Register(params BaseAgent[] agents)
        {
            if (this._disposing == true)
            {
                throw new DisposingException();
            }

            lock (_registry_lock)
            {
                foreach (BaseAgent agent in agents)
                {
                    this.Register(agent);
                }
            }
        }

        public void Unregister<TAGENT>() where TAGENT : BaseAgent
        {
            lock (_registry_lock)
            {
                int index = 0;
                foreach (BaseAgent agent in _registry)
                {
                    if(typeof(TAGENT) != agent.GetType())
                    {
                        index++;
                        continue;
                    }
                    break;
                }

                if (index <= _registry.Count)
                {
                    _registry.RemoveAt(index);
                }

            }
        }

    }
}