using System;
using Monaco.Internals.Eventing;

namespace Monaco.Internals.Agent.Impl
{
    public class AgentManager : IAgentManager
    {
        private bool _disposing;
        private readonly IAgentRegistry _registry;

        public event EventHandler<ComponentStartedEventArgs> ComponentStartedEvent;
        public event EventHandler<ComponentStoppedEventArgs> ComponentStoppedEvent;
        public event EventHandler<ComponentErrorEventArgs> ComponentErrorEvent;

        public AgentManager(IAgentRegistry registry)
        {
            _registry = registry;
        }

        public void Dispose()
        {
            _disposing = true;
            this.Stop();
        }

        public bool IsRunning
        {
            get; private set;
        }

        public void Start()
        {
            if (IsRunning == true)
            {
                return;
            }

            if (_registry != null)
                if (_registry.Agents.Count > 0)
                    foreach (BaseAgent agent in _registry.Agents)
                    {
                        agent.ComponentErrorEvent += ServiceError;
                        agent.ComponentStartedEvent += ServiceStarted;
                        agent.ComponentStoppedEvent += ServiceStopped;
                        agent.Start();
                    }

            IsRunning = true;
            OnServiceStarted(this.GetType().Name);
        }

        public void Stop()
        {
            if (_registry != null)
                if (_registry.Agents.Count > 0)
                    foreach (BaseAgent agent in _registry.Agents)
                    {
                        agent.Stop();
                        agent.ComponentErrorEvent -= ServiceError;
                        agent.ComponentStartedEvent -= ServiceStarted;
                        agent.ComponentStoppedEvent -= ServiceStopped;
                    }

            IsRunning = false;
            OnServiceStopped(this.GetType().Name);
        }

        private void ServiceStopped(object sender, ComponentStoppedEventArgs e)
        {
            OnServiceStopped(e.ComponentName);
        }

        private void ServiceStarted(object sender, ComponentStartedEventArgs e)
        {
            OnServiceStarted(e.ComponentName);
        }

        private void ServiceError(object sender, ComponentErrorEventArgs e)
        {
            var msg = string.Format("Service Error: Message = {0}, Stack Trace = {1}",
                                    e.ErrorMessage, e.Exception.StackTrace);
            OnServiceError(msg);
        }

        private void OnServiceStarted(string serviceName)
        {
            var evt = this.ComponentStartedEvent;
            if (evt != null)
                evt(this, new ComponentStartedEventArgs(serviceName));
        }

        private void OnServiceStopped(string serviceName)
        {
            var evt = this.ComponentStoppedEvent;
            if (evt != null)
                evt(this, new ComponentStoppedEventArgs(serviceName));
        }

        private bool OnServiceError(string theErrorMessage)
        {
            var evt = this.ComponentErrorEvent;
            var isHandlerAttached = (evt != null);

            if (isHandlerAttached)
                evt(this, new ComponentErrorEventArgs(theErrorMessage));

            return isHandlerAttached;
        }

        private bool OnServiceError(Exception theException)
        {
            var evt = this.ComponentErrorEvent;
            var isHandlerAttached = (evt != null);

            if (isHandlerAttached)
                evt(this, new ComponentErrorEventArgs(theException));

            return isHandlerAttached;
        }

    }
}