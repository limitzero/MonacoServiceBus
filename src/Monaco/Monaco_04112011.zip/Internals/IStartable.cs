using System;

namespace Monaco.Internals
{
    public interface IStartable : IDisposable
    {
        bool IsRunning { get; }
        void Start();
        void Stop();
    }
}