using System.Collections.Generic;

namespace Monaco.Internals.Collections
{
    public interface IThreadSafeDictionary<TKEY, TVALUE> : IDictionary<TKEY, TVALUE>
    {
        
    }
}