using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Monaco.Internals.Collections
{
    public interface  IThreadSafeList<TITEM> : IList<TITEM>
    {
        ReadOnlyCollection<TITEM> Instance { get; }
    }
}