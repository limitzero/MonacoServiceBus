using System.Collections;
using System.Collections.Generic;

namespace Monaco.Internals.Collections
{
    public class ThreadSafeDictionary<TKEY, TVALUE> : IThreadSafeDictionary<TKEY, TVALUE>
    {
        private readonly object _padLock = new object();
        private readonly IDictionary<TKEY, TVALUE> _dictionary = new Dictionary<TKEY, TVALUE>();

        public IEnumerator<KeyValuePair<TKEY, TVALUE>> GetEnumerator()
        {
            lock (_padLock)
            {
                return this._dictionary.GetEnumerator();
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            lock (_padLock)
            {
                return this._dictionary.GetEnumerator();
            }
        }

        public void Add(KeyValuePair<TKEY, TVALUE> item)
        {
            lock (_padLock)
            {
                this._dictionary.Add(item);
            }
        }

        public void Clear()
        {
            lock (_padLock)
            {
                this._dictionary.Clear();
            }
        }

        public bool Contains(KeyValuePair<TKEY, TVALUE> item)
        {
            lock (_padLock)
            {
                return this._dictionary.Contains(item);
            }
        }

        public void CopyTo(KeyValuePair<TKEY, TVALUE>[] array, int arrayIndex)
        {
            lock(_padLock)
            {
                this._dictionary.CopyTo(array, arrayIndex);
            }
        }

        public bool Remove(KeyValuePair<TKEY, TVALUE> item)
        {
            lock (_padLock)
            {
                return this._dictionary.Remove(item);
            }
        }

        public int Count
        {
            get
            {
                lock (_padLock)
                {
                    return this._dictionary.Count;
                }
            }
        }

        public bool IsReadOnly
        {
            get
            {
                lock (_padLock)
                {
                    return this._dictionary.IsReadOnly;
                }
            }
        }

        public bool ContainsKey(TKEY key)
        {
            lock (_padLock)
            {
                return this._dictionary.ContainsKey(key);
            }
        }

        public void Add(TKEY key, TVALUE value)
        {
            lock (_padLock)
            {
                this._dictionary.Add(key, value);
            }
        }

        public bool Remove(TKEY key)
        {
            lock (_padLock)
            {
                return this._dictionary.Remove(key);
            }
        }

        public bool TryGetValue(TKEY key, out TVALUE value)
        {
            lock (_padLock)
            {
                return this._dictionary.TryGetValue(key, out value);
            }
        }

        public TVALUE this[TKEY key]
        {
     
            get
            {
                lock(_padLock)
                {
                    return this._dictionary[key];
                }
            }
            
            set
            {
                lock (_padLock)
                {
                    this._dictionary[key]= value;
                }
            }
        }

        public ICollection<TKEY> Keys
        {
            get
            {
                lock(_padLock)
                {
                    return this._dictionary.Keys;
                }
            }
        }

        public ICollection<TVALUE> Values
        {
            get
            {
                lock (_padLock)
                {
                    return this._dictionary.Values;
                }
            }
        }
    }
}