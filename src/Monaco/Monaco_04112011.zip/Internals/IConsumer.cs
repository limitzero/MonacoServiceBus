namespace Monaco.Internals
{
    /// <summary>
    /// Primary interface for all contracts that are set to handle messages.
    /// </summary>
    public interface IConsumer
    {
    }
}