using System;
using Monaco.Endpoint.Impl;
using Monaco.Transport;

namespace Monaco.Internals.Eventing
{
    /// <summary>
    /// Event arguements passed to event subscriber when a message is received from an endpoint.
    /// </summary>
    public class EndpointMessageReceivedEventArgs : EventArgs
    {
        public BaseEndpoint Endpoint { get; private set; }
        public IEnvelope Envelope { get; private set; }

        public EndpointMessageReceivedEventArgs(BaseEndpoint endpoint, IEnvelope envelope)
        {
            Endpoint = endpoint;
            Envelope = envelope;
        }
    }
}