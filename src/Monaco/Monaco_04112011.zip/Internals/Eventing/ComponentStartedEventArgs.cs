using System;

namespace Monaco.Internals.Eventing
{
    public class ComponentStartedEventArgs : EventArgs
    {
        public string ComponentName { get; set; }

        public ComponentStartedEventArgs(string componentName)
        {
            ComponentName = componentName;
        }
    }
}