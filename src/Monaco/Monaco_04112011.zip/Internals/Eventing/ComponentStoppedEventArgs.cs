using System;

namespace Monaco.Internals.Eventing
{
    public class ComponentStoppedEventArgs : EventArgs
    {
        public string ComponentName { get; set; }

        public ComponentStoppedEventArgs(string componentName)
        {
            ComponentName = componentName;
        }
    }
}