namespace Monaco.Internals
{
    /// <summary>
    /// Contract for all message producers
    /// </summary>
    public interface  IProducer
    {}
}