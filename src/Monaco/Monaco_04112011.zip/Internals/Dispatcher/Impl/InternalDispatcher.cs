using System;
using System.Linq;
using System.Reflection;
using Castle.MicroKernel;
using Monaco.Exceptions;
using Monaco.Internals.Logging;
using Monaco.Internals.Reflection;
using Monaco.Sagas;

namespace Monaco.Internals.Dispatcher.Impl
{
    public class InternalDispatcher : IDispatcher
    {
        private IServiceBus _bus;
        private readonly IKernel _kernel;
        private readonly ISagaRepository _sagaRepository;
        private readonly IReflection _reflection;

        public InternalDispatcher(IKernel kernel, 
            ISagaRepository sagaRepository, 
            IReflection reflection)
        {
            _kernel = kernel;
            _sagaRepository = sagaRepository;
            _reflection = reflection;
        }

        public void Dispatch(IServiceBus bus, IConsumer handler, IMessage message)
        {
            object theComponent = handler;
            _bus = bus;

            try
            {
                _kernel.Resolve<ILogger>().LogDebugMessage(string.Format("Start: dispatching message '{0}' to component '{1}'.",
                    message.GetType().FullName, handler.GetType().FullName));

                if (theComponent != null)
                {
                    if (typeof(ISaga).IsAssignableFrom(theComponent.GetType()))
                    {
                        ManageSagaInvocation(theComponent, message);
                    }
                    else
                    {
                        this.DispatchMessage(theComponent, message);
                    }
                }
            }
            catch (Exception e)
            {
                var ex = new DispatcherDispatchException(message.GetType().FullName, handler.GetType().FullName, e);
                throw ex;
            }
            finally
            {
                _kernel.Resolve<ILogger>().LogDebugMessage(string.Format("Complete: dispatching message '{0}' to component '{1}'.",
                        message.GetType().FullName, handler.GetType().FullName));
            }

        }

        private void ManageSagaInvocation(object theSaga, IMessage message)
        {
            object theSagaFinder = null;

            try
            {
                if (IsStartOfNewSaga(theSaga, message) == true)
                {
                    this.InitializeSaga(theSaga, message);
                }
                else
                {
                    ISaga sagaFromPersistance = _sagaRepository.Find(((ISaga)theSaga).InstanceId);

                    if (sagaFromPersistance != null)
                    {
                        theSaga = sagaFromPersistance;
                    }

                    CheckForSagaMessageCorrelation(message, theSaga as ISaga);
                    this.ContinueSaga(theSaga, message);
                }

                this.DispatchMessage(theSaga, message);
                this.PersistSaga(theSaga);
            }
            catch (Exception e)
            {
                throw;
            }
        }

        private static bool IsStartOfNewSaga(object theSaga, IMessage message)
        {
            bool isStartingNewSaga = false;

            try
            {
                Type theStartedByInterfaceType = (from contract in theSaga.GetType().GetInterfaces()
                                                  where contract.IsGenericType == true
                                                        &&
                                                        contract.GetGenericArguments()[0] == message.GetType()
                                                        &&
                                                        contract.FullName.StartsWith(typeof(StartedBy<>).FullName)
                                                  select contract).FirstOrDefault();

                if (theStartedByInterfaceType != null)
                {
                    isStartingNewSaga = true;
                }
            }
            catch (Exception e)
            {
                throw;
            }

            return isStartingNewSaga;
        }

        private void InitializeSaga(object theSaga, IMessage message)
        {
            Guid instanceId = Guid.NewGuid();
            ((ISaga)theSaga).InstanceId = instanceId;

            if (this.ContainsInterface(theSaga, typeof(ISaga<>)) != null)
            {
                // need to instantiate new data for saga and sync the instance 
                // identifier with the instance identifier of the saga:
                PropertyInfo theSagaDataProperty = this.GetSagaDataProperty(theSaga);

                if (theSagaDataProperty != null)
                {
                    object theSagaDataRepository =
                        this.CreateSagaDataRepositoryFromDataType(theSagaDataProperty.PropertyType);

                    // set the new data in the saga for use:
                    ISagaData theSagaData = _reflection.InvokeCreateForSagaDataRepository(theSagaDataRepository,
                                                                                          instanceId);
                    theSagaData.CorrelationId = instanceId;
                    theSagaDataProperty.SetValue(theSaga, theSagaData, null);
                }
            }
        }

        private void ContinueSaga(object theSaga, IMessage message)
        {
            // saga should be initialized at this point with
            // instance identifier and any optional saga data:
            ISagaData theSagaData = null;
            Guid instanceId = ((ISaga)theSaga).InstanceId;

            if (this.ContainsInterface(theSaga, typeof(ISaga<>)) != null)
            {
                // need to instantiate new data for saga and sync the instance 
                // identifier with the instance identifier of the saga:
                PropertyInfo theSagaDataProperty = this.GetSagaDataProperty(theSaga);

                if (theSagaDataProperty != null)
                {
                    object theSagaDataRepository = 
                        this.CreateSagaDataRepositoryFromDataType(theSagaDataProperty.PropertyType);

                    // set the data in the saga for use from the persistance store:
                    theSagaData = _reflection.InvokeFindForSagaDataRepository(theSagaDataRepository, instanceId) as ISagaData;

                    // create the data again if it can not be found:
                    if (theSagaData == null)
                    {
                        theSagaData = _reflection.InvokeCreateForSagaDataRepository(theSagaDataRepository, instanceId);
                        theSagaData.CorrelationId = instanceId;
                    }

                    theSagaDataProperty.SetValue(theSaga, theSagaData, null); 
                }
            }

        }

        private static void CheckForSagaMessageCorrelation(IMessage theMessage, ISaga theSaga)
        {
            // need to check for correlated messages to the saga:
            var theCorrelationInterface = (from theInterface in theSaga.GetType().GetInterfaces()
                                           where
                                               theInterface.FullName.StartsWith(
                                                   typeof(Correlated.By<>).FullName)
                                               &&
                                               theInterface.GetGenericArguments()[0] == theMessage.GetType()
                                           select theInterface).FirstOrDefault();

            if (theCorrelationInterface == null) return;

            // must have method to conform to interface, proceed to call the "Correlate" function: 
            MethodInfo correlateMethod =
                new MessageToMethodMapper().Map(theSaga, theMessage, "Correlate");

            bool isCorrelatedForMessage = new MessageMethodInvoker()
                .Invoke<bool>(theSaga, correlateMethod, theMessage);

            if (isCorrelatedForMessage == false)
                throw new SagaMessageCouldNotBeCorrelatedToOngoingSagaException(theMessage.GetType(),
                                                                                theSaga.GetType());
        }

        private void PersistSaga(object theSaga)
        {
            Guid instanceId = ((ISaga)theSaga).InstanceId;
            bool isCompleted = ((ISaga)theSaga).IsCompleted;

            PropertyInfo theSagaDataProperty = this.GetSagaDataProperty(theSaga);
            bool isDataPropertyAvailable = (theSagaDataProperty != null);

            ISagaData theSagaData = null;
            object theSagaFinder = null;

            if (isDataPropertyAvailable == true)
            {
                theSagaData = theSagaDataProperty.GetValue(theSaga, null) as ISagaData;
                theSagaFinder = this.CreateSagaDataRepositoryFromDataType(theSagaDataProperty.PropertyType);
            }

            if (isCompleted == true)
            {
                _sagaRepository.Remove(instanceId);

                if (isDataPropertyAvailable == true)
                {
                    _reflection.InvokeRemoveForSagaDataRepository(theSagaFinder, instanceId);
                }
            }
            else
            {
                _sagaRepository.Save(theSaga as ISaga);

                if (isDataPropertyAvailable == true)
                {
                    _reflection.InvokeSaveForSagaDataRepository(theSagaFinder, theSagaData);
                }
            }
        }

        private void DispatchMessage(object component, IMessage message)
        {
            this.SetServiceBus(component, false);

            MethodInfo consumerMethod =
                new MessageToMethodMapper().Map(component, message);

            if (consumerMethod != null)
            {
                new MessageMethodInvoker().Invoke(component, consumerMethod, message);
            }

            this.SetServiceBus(component, true);

        }

        private PropertyInfo GetSagaDataProperty(object theSaga)
        {
            PropertyInfo theDataProperty = null;

            if (this.ContainsInterface(theSaga, typeof(ISaga<>)) != null)
            {
                try
                {
                    theDataProperty = (from property in theSaga.GetType().GetProperties()
                                       where property.Name.Trim().ToLower() == "data"
                                       select property).FirstOrDefault();
                }
                catch (Exception e)
                {
                    throw;
                }
            }
            return theDataProperty;
        }

        private void SetServiceBus(object component, bool canRemove)
        {
            PropertyInfo serviceBusProperty;

            if (typeof(Saga).IsAssignableFrom(component.GetType()))
            {
                if (canRemove == false)
                {
                    ((Saga)component).Bus = _bus;
                }
                else
                {
                    ((Saga)component).Bus = null;
                }
            }
            else
            {
                try
                {
                    serviceBusProperty = (from property in component.GetType().GetProperties()
                                          where property.Name.Trim().ToLower() == "bus"
                                          select property).FirstOrDefault();
                }
                catch (Exception e)
                {
                    throw;
                }

                if (serviceBusProperty != null)
                {
                    if (canRemove == false)
                    {
                        serviceBusProperty.SetValue(_bus as IServiceBus, component, null);
                    }
                    else
                    {
                        serviceBusProperty.SetValue(null, component, null);
                    }
                }
            }

        }

        private object CreateSagaDataRepositoryFromDataType(Type theSagaDataType)
        {
            object theSagaDataRepository = null;

            Type theType = typeof(ISagaDataRepository<>).MakeGenericType(theSagaDataType);

            if (theType != null)
            {
                theSagaDataRepository = _bus.Find(theType);
            }

            return theSagaDataRepository;
        }

        private Type ContainsInterface(object theComponent, Type interfaceType)
        {
            Type theInterface = (from contract in theComponent.GetType().GetInterfaces()
                                 where contract.IsGenericType == true
                                       &&
                                       contract.FullName.StartsWith(interfaceType.FullName)
                                 select contract).FirstOrDefault();

            return theInterface;
        }
    }
}