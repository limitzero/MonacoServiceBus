using System;

namespace Monaco.Internals.Callbacks
{
    public interface ICallBackRepository
    {
        void Register(ICallback callback);
        ICallback Find(Type theMessageType);
    }
}