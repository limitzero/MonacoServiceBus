using System;
using Monaco.Internals.Collections;

namespace Monaco.Internals.Callbacks
{
    public class CallBackRepository : ICallBackRepository
    {
        private static readonly object _callbacksLock = new object();
        private static IThreadSafeDictionary<Type, ICallback> _callbacks;

        public CallBackRepository()
        {
            if (_callbacks == null)
            {
                _callbacks = new ThreadSafeDictionary<Type, ICallback>();
            }
        }

        ~CallBackRepository()
        {
            if(_callbacks != null)
            {
                _callbacks.Clear();
                _callbacks = null;
            }
        }

        public void Register(ICallback callback)
        {
            if(!_callbacks.ContainsKey(callback.ReplyMessage))
            {
                lock(_callbacksLock)
                {
                    _callbacks.Add(callback.ReplyMessage, callback);
                }
            }
        }

        public ICallback Find(Type theMessageType)
        {
            ICallback callback = null;

            try
            {
                _callbacks.TryGetValue(theMessageType, out callback);
            }
            catch
            {
            }
            
            return callback;
        }
    }
}