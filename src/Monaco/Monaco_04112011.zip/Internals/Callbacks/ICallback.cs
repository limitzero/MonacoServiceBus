using System;

namespace Monaco.Internals.Callbacks
{
    /// <summary>
    /// This is the contract for the message bus to send messages 
    /// and invoke the caller as to the response for the request.
    /// </summary>
    public interface ICallback
    {
        /// <summary>
        /// Gets the response message type to send to client.
        /// </summary>
        Type ReplyMessage { get; }

        /// <summary>
        /// Gets or sets the request message that is sent to the 
        /// bus for a corresponding reply message.
        /// </summary>
        Type RequestMessage { get; }

        /// <summary>
        /// Gets the callback function to execute on the client.
        /// </summary>
        Action<IMessage> Callback { get; }

        /// <summary>
        /// Registers an action to callback when the message bus sends a reply 
        /// to a message that was sent (synchronous communication).
        /// </summary>
        /// <typeparam name="TMESSAGE">The type of message desired for the response.</typeparam>
        /// <param name="callback">The callback action to handle the response message</param>
        void RegisterCallbackFor<TMESSAGE>(Action<TMESSAGE> callback) where TMESSAGE : class, IMessage;
    }
}