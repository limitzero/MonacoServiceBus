using System;
using Monaco.Internals.Logging;

namespace Monaco.Internals.Callbacks
{
    public class MessageBusCallback : ICallback
    {
        private readonly ICallBackRepository _callbackPersister;
        private readonly string _location;
        private readonly IMessage _message;
        private readonly IServiceBus _bus;

        /// <summary>
        /// Gets or sets the request message that is sent to the 
        /// bus for a corresponding reply message.
        /// </summary>
        public Type RequestMessage
        {
            get; 
            private set;
        }

        /// <summary>
        /// Gets the response message to send to client.
        /// </summary>
        public Type ReplyMessage
        {
            get; 
            private set;
        }

        /// <summary>
        /// Gets the callback function to execute on the client.
        /// </summary>
        public Action<IMessage> Callback
        {
            get;
            private set;
        }

        /// <summary>
        /// Initializes an instance of a message bus callback for a message that is sent for a request/response scenario.
        /// </summary>
        /// <param name="bus"></param>
        /// <param name="callbackPersister"></param>
        /// <param name="requestMessage"></param>
        public MessageBusCallback(IServiceBus bus, ICallBackRepository callbackPersister, Type requestMessage)
        {
            this.RequestMessage = requestMessage;
            this._bus = bus;
            this._callbackPersister = callbackPersister;
        }

        public MessageBusCallback(IServiceBus bus, ICallBackRepository callbackPersister, 
                                  Type requestMessage, IMessage message)
            : this(bus, callbackPersister, requestMessage, null, message)
        {
        }

        public MessageBusCallback(IServiceBus bus, ICallBackRepository callbackPersister,
                                  Type requestMessage, string location, IMessage message)
        {
            this.RequestMessage = requestMessage;
            this._bus = bus;
            this._callbackPersister = callbackPersister;
            this._location = location;
            this._message = message;
        }

        public void RegisterCallbackFor<TMESSAGE>(Action<TMESSAGE> callback) where TMESSAGE : class, IMessage
        {
            ReplyMessage = typeof (TMESSAGE);
            this.Callback = theMessage => callback(theMessage as TMESSAGE);
            _callbackPersister.Register(this);

            string message = string.Format("Registering call back '{0}' for request '{1}' with reply '{2}'.",
                                           callback.Method.Name,
                                           this.RequestMessage.Name,
                                           this.ReplyMessage.Name);

            _bus.Find<ILogger>().LogInfoMessage(message);

            if(!string.IsNullOrEmpty(_location) == true)
            {
                _bus.Publish(this._location, this._message);
            }
            else
            {
                _bus.Publish(this._message);    
            }
            
        }
    }
}