using Monaco.Agents.Timeout;
using Monaco.Sagas;
using Monaco.Subscriptions;

namespace Monaco.Internals
{
    public static class Constants
    {
        /// <summary>
        /// Default name of the endpoint that represents the message bus.
        /// </summary>
        public const string MESSAGE_BUS_ENDPOINT_NAME = "message.bus";

        /// <summary>
        /// Default name of the endpoint that represents the message bus poision location.
        /// </summary>
        public const string MESSAGE_BUS_POISION_ENDPOINT_NAME = "message.bus.poision";

        /// <summary>
        /// Default name of the endpoint that represents the control bus.
        /// </summary>
        public const string CONTROL_BUS_ENDPONT_NAME = "control.bus";

        /// <summary>
        /// Default name of the endpoint that represents the global subscription manager bus instance.
        /// </summary>
        public const string SUBSCRIPTION_MANAGER_ENDPOINT_NAME = "subscription.manager";

        /// <summary>
        /// Default empty time interval.
        /// </summary>
        public const string EMPTY_TIME_INTERVAL = "00:00:00";

        /// <summary>
        /// Default key for the concrete implementation of the <seealso cref="ISubscriptionRepository"/>
        /// </summary>
        public const string SUBSCRIPTION_REPOSITORY_CONTAINER_KEY = "subscrption.repository";

        /// <summary>
        /// Default key for the concrete implementation of the <seealso cref="ITimeoutsRepository"/>
        /// </summary>
        public const string TIMEOUTS_REPOSITORY_CONTAINER_KEY = "timeouts.repository";

        /// <summary>
        /// Default key for the concrete implementation of the <seealso cref="ISagaRepository"/>
        /// </summary>
        public const string SAGA_REPOSITORY_CONTAINER_KEY = "saga.repository";

        /// <summary>
        /// Default key for the concrete implementation of the <seealso cref="ISagaDataRepository{TDATA}"/>
        /// </summary>
        public const string SAGA_DATA_REPOSITORY_CONTAINER_KEY = "saga.data.repository";
    }
}