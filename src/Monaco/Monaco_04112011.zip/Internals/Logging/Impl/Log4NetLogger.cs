using System;
using log4net;
using Monaco.Impl;

namespace Monaco.Internals.Logging.Impl
{
    public class Log4NetLogger : ILogger
    {
        private ILog _logger;
        private readonly bool _isConfigured;
        private bool _isDisposing;

        public Log4NetLogger()
        {
            if (this._isConfigured == false)
            {
                try
                {
                    log4net.Config.XmlConfigurator.Configure(new System.IO.FileInfo(@"log4net.config.xml"));
                }
                catch (Exception exception)
                {
                    var msg = "An error has occurred while configuring log4net. Reason:" + exception.Message +
                              " Please ensure that the configuration file named 'log4net.config.xml' is placed in the executable directory.";
                    throw new Exception(msg, exception);
                }

                this._isConfigured = true;
                this.GetLogger();
            }
        }

        public void LogDebugMessage(string message)
        {
            if(_isDisposing) return;

            if (_logger.IsDebugEnabled)
                _logger.Debug(message);
        }

        public void LogInfoMessage(string message)
        {
            if (_isDisposing) return;

            if (_logger.IsInfoEnabled)
                _logger.Info(message);
        }

        public void LogWarnMessage(string message)
        {
            if (_isDisposing) return;

            if (_logger.IsWarnEnabled)
                _logger.Warn(message);
        }

        public void LogWarnMessage(string message, Exception exception)
        {
            if (_isDisposing) return;

            if (_logger.IsWarnEnabled)
                _logger.Warn(message, exception);
        }

        public void LogErrorMessage(string message)
        {
            if (_isDisposing) return;

            if (_logger.IsErrorEnabled)
                _logger.Error(message);
        }

        public void LogErrorMessage(string message, Exception exception)
        {
            if (_isDisposing) return;

            if (_logger.IsErrorEnabled)
                if(string.IsNullOrEmpty(message))
                {
                    message = exception.Message;
                }
            _logger.Error(message, exception);
        }

        public void Dispose()
        {
            this.OnDisposing(true);
        }

        private void OnDisposing(bool isDisposing)
        {
            if(isDisposing)
            {
                _isDisposing = true;
                _logger = null;
            }
        }

        private void GetLogger()
        {
            if (_logger == null)
                _logger = LogManager.GetLogger(typeof(ServiceBus));
        }
    }
}