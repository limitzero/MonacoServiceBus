using System.Collections.Generic;

namespace Monaco.Internals.Transport
{
    /// <summary>
    /// Common transport envelope that has the message that is received from the endpoint.
    /// </summary>
    public interface IEnvelope
    {
        /// <summary>
        /// Gets the stream instance of the original payload 
        /// received from the endpoint location.
        /// </summary>
        byte[] BodyStream { get; }

        /// <summary>
        /// This wil retrieve the internal payload of the envelope by type.
        /// </summary>
        /// <typeparam name="TPAYLOAD"></typeparam>
        /// <returns></returns>
        TPAYLOAD GetPayload<TPAYLOAD>();

        /// <summary>
        /// This will change the contents of the envelope payload
        /// from one object to another.
        /// </summary>
        /// <param name="payload">Object that represents the new payload.</param>
        void ChangePayload(object payload);

        /// <summary>
        /// This will add a header to the envelope describing 
        /// either the payload or additional meta-data.
        /// </summary>
        /// <param name="key">Unique key to identify the data.</param>
        /// <param name="data">Value attached to the key.</param>
        void AddHeader(string key, object data);

        /// <summary>
        /// This will extract the value for a given header
        /// </summary>
        /// <param name="key">Unique key to identify the data.</param>
        /// <returns></returns>
        object GetHeader(string key);

        /// <summary>
        /// This will extract the value for a given header
        /// </summary>
        /// <typeparam name="TDATA">Well-known type to cast the data to after extraction.</typeparam>
        /// <param name="key">Unique key to identify the data.</param>
        /// <returns>
        /// Object cast to well-known type or null if it can not be cast.
        /// </returns>
        TDATA GetHeader<TDATA>(string key);
    }

}