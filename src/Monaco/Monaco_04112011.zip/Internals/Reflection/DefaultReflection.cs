using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using Castle.MicroKernel;
using Castle.MicroKernel.Registration;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Sagas;

namespace Monaco.Internals.Reflection
{
    public class DefaultReflection : IReflection
    {
        private readonly IKernel _kernel;

        public DefaultReflection(IKernel kernel)
        {
            _kernel = kernel;
        }

        /// <summary>
        /// This will construct an assembly representing all of the interface-based only 
        /// message implementations primarily for the serialization engine.
        /// </summary>
        /// <param name="contracts">Collection of interfaces representing messages</param>
        /// <param name="registerInContainer">Flag to indicate whether or not to add these components to the container.</param>
        public ICollection<Type> BuildProxyAssemblyForContracts(ICollection<Type> contracts, bool registerInContainer)
        {
            // this is adapted from http://msdn.microsoft.com/en-us/library/system.reflection.emit.propertybuilder.aspx
            List<Type> theProxiedTypes = new List<Type>();

            var assemblyName = new AssemblyName("proxyAssembly");
            var assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.RunAndSave);
            var moduleBuilder = assemblyBuilder.DefineDynamicModule("proxyModule", "_proxy.dll");
            TypeBuilder typeBuilder = null;

            foreach (Type contract in contracts)
            {
                var methods = new List<MethodInfo>(contract.GetMethods());

                if (contract.Name.StartsWith("I"))
                {
                    var proxyName = contract.Name.Substring(1, contract.Name.Length - 1);
                    typeBuilder = moduleBuilder.DefineType(proxyName, TypeAttributes.Public);
                }
                else
                {
                    typeBuilder = moduleBuilder.DefineType(contract.Name + "Proxy", TypeAttributes.Public);
                }

                typeBuilder.AddInterfaceImplementation(contract);

                // for inheritance chains, get all of the methods for full implementation and subsequent interfaces:
                foreach (var @interface in contract.GetInterfaces())
                {
                    typeBuilder.AddInterfaceImplementation(@interface);

                    foreach (var method in @interface.GetMethods())
                    {
                        if (!methods.Contains(method))
                        {
                            methods.Add(method);
                        }
                    }
                }

                var ctorBuilder = typeBuilder.DefineConstructor(
                       MethodAttributes.Public,
                       CallingConventions.Standard,
                       new Type[] { });

                var ilGenerator = ctorBuilder.GetILGenerator();
                //ilGenerator.EmitWriteLine("Creating Proxy instance");
                ilGenerator.Emit(OpCodes.Ret);

                var fieldNames = new List<string>();

                // cycle through all of the methods and create the "set" and "get" methods:
                foreach (var methodInfo in methods)
                {
                    // build the backing field for the property based on the property name:
                    var fieldName = string.Concat("m_", methodInfo.Name
                                                            .Replace("set_", string.Empty)
                                                            .Replace("get_", string.Empty))
                        .Trim();

                    // create the property name based on the set_XXX and get_XXX matching methods:
                    var propertyName = fieldName.Replace("m_", string.Empty);

                    if (!fieldNames.Contains(fieldName))
                    {
                        fieldNames.Add(fieldName);
                        FieldBuilder fieldBuilder = typeBuilder.DefineField(fieldName.ToLower(),
                                                                            methodInfo.ReturnType,
                                                                            FieldAttributes.Private);

                        // The last argument of DefineProperty is null, because the
                        // property has no parameters. (If you don't specify null, you must
                        // specify an array of Type objects. For a parameterless property,
                        // use an array with no elements: new Type[] {})
                        PropertyBuilder propertyBuilder = typeBuilder.DefineProperty(propertyName,
                                                                                     PropertyAttributes.HasDefault,
                                                                                     methodInfo.ReturnType,
                                                                                     null);

                        // The property set and property get methods require a special
                        // set of attributes.
                        MethodAttributes getSetAttr =
                            MethodAttributes.Public |
                            MethodAttributes.HideBySig |
                            MethodAttributes.SpecialName |
                            MethodAttributes.NewSlot |
                            MethodAttributes.Virtual |
                            MethodAttributes.Final;

                        // Define the "get" accessor method for the property.
                        MethodBuilder getPropMethodBuilder =
                            typeBuilder.DefineMethod(string.Concat("get_", propertyName),
                                                     getSetAttr,
                                                     methodInfo.ReturnType,
                                                     Type.EmptyTypes);

                        ILGenerator getPropMethodIL = getPropMethodBuilder.GetILGenerator();

                        getPropMethodIL.Emit(OpCodes.Ldarg_0);
                        getPropMethodIL.Emit(OpCodes.Ldfld, fieldBuilder);
                        getPropMethodIL.Emit(OpCodes.Ret);

                        // Define the "set" accessor method for the property.
                        MethodBuilder setPropMethodBuilder =
                            typeBuilder.DefineMethod(string.Concat("set_", propertyName),
                                                     getSetAttr,
                                                     null,
                                                     new Type[] { methodInfo.ReturnType });

                        ILGenerator setPropMethodIL = setPropMethodBuilder.GetILGenerator();

                        setPropMethodIL.Emit(OpCodes.Ldarg_0);
                        setPropMethodIL.Emit(OpCodes.Ldarg_1);
                        setPropMethodIL.Emit(OpCodes.Stfld, fieldBuilder);
                        setPropMethodIL.Emit(OpCodes.Ret);

                        // Last, we must map the two methods created above to our PropertyBuilder to 
                        // their corresponding behaviors, "get" and "set" respectively. 
                        propertyBuilder.SetGetMethod(getPropMethodBuilder);
                        propertyBuilder.SetSetMethod(setPropMethodBuilder);

                    }

                }

                var constructedType = typeBuilder.CreateType();
                theProxiedTypes.Add(constructedType);
            }

            var file = string.Concat(assemblyName, ".dll");
            var filename = Path.Combine(Environment.CurrentDirectory, file);

            try
            {
                if (File.Exists(filename))
                    File.Delete(filename);

                assemblyBuilder.Save(file, PortableExecutableKinds.Required32Bit, ImageFileMachine.I386);
            }
            catch
            {

            }

            if(registerInContainer == true)
            {
                Assembly asm = Assembly.LoadFile(filename);
                _kernel.Register(AllTypes.FromAssembly(asm).Where(x => x.IsClass == true && typeof(IMessage).IsAssignableFrom(x))
                            .WithService.FirstInterface());
            }

            return theProxiedTypes;
        }

        /// <summary>
        /// This will build a concrete proxy object based on the interface contract.
        /// </summary>
        /// <typeparam name="TCONTRACT">Interface for building a concrete instance</typeparam>
        /// <returns>
        ///  A concrete instance of the {TCONTRACT}.
        /// </returns>
        public TCONTRACT BuildProxyFor<TCONTRACT>()
        {
            // this is adapted from http://msdn.microsoft.com/en-us/library/system.reflection.emit.propertybuilder.aspx

            var proxy = default(TCONTRACT);

            var typeOfT = typeof(TCONTRACT);
            var methods = new List<MethodInfo>(typeOfT.GetMethods());

            var assemblyName = new AssemblyName("proxyAssembly");
            var assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.RunAndSave);
            var moduleBuilder = assemblyBuilder.DefineDynamicModule("proxyModule", "_proxy.dll");

            TypeBuilder typeBuilder = null;

            if (typeof(TCONTRACT).Name.StartsWith("I"))
            {
                var proxyName = typeof(TCONTRACT).Name.Substring(1, typeof(TCONTRACT).Name.Length - 1);
                typeBuilder = moduleBuilder.DefineType(proxyName, TypeAttributes.Public);
            }
            else
            {
                typeBuilder = moduleBuilder.DefineType(typeof(TCONTRACT).Name + "Proxy", TypeAttributes.Public);
            }

            typeBuilder.AddInterfaceImplementation(typeOfT);

            // for inheritance chains, get all of the methods for full implementation and subsequent interfaces:
            foreach (var @interface in typeof(TCONTRACT).GetInterfaces())
            {
                typeBuilder.AddInterfaceImplementation(@interface);

                foreach (var method in @interface.GetMethods())
                    if (!methods.Contains(method))
                        methods.Add(method);
            }

            var ctorBuilder = typeBuilder.DefineConstructor(
                MethodAttributes.Public,
                CallingConventions.Standard,
                new Type[] { });

            var ilGenerator = ctorBuilder.GetILGenerator();
            //ilGenerator.EmitWriteLine("Creating Proxy instance");
            ilGenerator.Emit(OpCodes.Ret);

            var fieldNames = new List<string>();

            // cycle through all of the methods and create the "set" and "get" methods:
            foreach (var methodInfo in methods)
            {
                // build the backing field for the property based on the property name:
                var fieldName = string.Concat("m_", methodInfo.Name
                                                        .Replace("set_", string.Empty)
                                                        .Replace("get_", string.Empty))
                    .Trim();

                // create the property name based on the set_XXX and get_XXX matching methods:
                var propertyName = fieldName.Replace("m_", string.Empty);

                if (!fieldNames.Contains(fieldName))
                {
                    fieldNames.Add(fieldName);
                    FieldBuilder fieldBuilder = typeBuilder.DefineField(fieldName.ToLower(),
                                                                        methodInfo.ReturnType,
                                                                        FieldAttributes.Private);

                    // The last argument of DefineProperty is null, because the
                    // property has no parameters. (If you don't specify null, you must
                    // specify an array of Type objects. For a parameterless property,
                    // use an array with no elements: new Type[] {})
                    PropertyBuilder propertyBuilder = typeBuilder.DefineProperty(propertyName,
                                                                                 PropertyAttributes.HasDefault,
                                                                                 methodInfo.ReturnType,
                                                                                 null);

                    // The property set and property get methods require a special
                    // set of attributes.
                    MethodAttributes getSetAttr =
                        MethodAttributes.Public |
                        MethodAttributes.HideBySig |
                        MethodAttributes.SpecialName |
                        MethodAttributes.NewSlot |
                        MethodAttributes.Virtual |
                        MethodAttributes.Final;

                    // Define the "get" accessor method for the property.
                    MethodBuilder getPropMethodBuilder =
                        typeBuilder.DefineMethod(string.Concat("get_", propertyName),
                                                 getSetAttr,
                                                 methodInfo.ReturnType,
                                                 Type.EmptyTypes);

                    ILGenerator getPropMethodIL = getPropMethodBuilder.GetILGenerator();

                    getPropMethodIL.Emit(OpCodes.Ldarg_0);
                    getPropMethodIL.Emit(OpCodes.Ldfld, fieldBuilder);
                    getPropMethodIL.Emit(OpCodes.Ret);

                    // Define the "set" accessor method for the property.
                    MethodBuilder setPropMethodBuilder =
                        typeBuilder.DefineMethod(string.Concat("set_", propertyName),
                                                 getSetAttr,
                                                 null,
                                                 new Type[] { methodInfo.ReturnType });

                    ILGenerator setPropMethodIL = setPropMethodBuilder.GetILGenerator();

                    setPropMethodIL.Emit(OpCodes.Ldarg_0);
                    setPropMethodIL.Emit(OpCodes.Ldarg_1);
                    setPropMethodIL.Emit(OpCodes.Stfld, fieldBuilder);
                    setPropMethodIL.Emit(OpCodes.Ret);

                    // Last, we must map the two methods created above to our PropertyBuilder to 
                    // their corresponding behaviors, "get" and "set" respectively. 
                    propertyBuilder.SetGetMethod(getPropMethodBuilder);
                    propertyBuilder.SetSetMethod(setPropMethodBuilder);

                }

            }

            var constructedType = typeBuilder.CreateType();
            var instance = Activator.CreateInstance(constructedType);
            proxy = (TCONTRACT)instance;

            var file = string.Concat(assemblyName, ".dll");
            var filename = Path.Combine(Environment.CurrentDirectory, file);

            try
            {
                if (File.Exists(filename))
                    File.Delete(filename);

                assemblyBuilder.Save(file);
            }
            catch
            {

            }

            return proxy;

        }

        public object BuildInstance(Type currentType)
        {
            object instance = null;

            try
            {
                instance = currentType.Assembly.CreateInstance(currentType.FullName);
            }
            catch (Exception)
            {
                string msg = string.Format("Could create the instance from the assembly '{0}' to create type '{1}'.",
                                           currentType.Assembly.FullName,
                                           currentType.FullName);
                throw;
            }

            return instance;
        }

        public object BuildInstance(string typeName)
        {
            object instance = null;
            Assembly asm = null;

            string[] typeParts = typeName.Split(new[] { ',' });

            try
            {
                asm = Assembly.Load(typeParts[1].Trim());
            }
            catch
            {
                string msg = string.Format("Could not load the assembly {0} to create type {1}.", typeParts[1],
                                           typeParts[0]);

                //m_logger.Error(msg, exception);
                return instance;
            }

            try
            {
                instance = asm.CreateInstance(typeParts[0].Trim());
            }
            catch
            {
                string msg = string.Format("Could not create the type {0}.", typeParts[0]);
                //m_logger.Error(msg, exception);
                return instance;
            }

            return instance;
        }

        public Type FindType(string typeName)
        {
            Type theType = null;
            string[] files = Directory.GetFiles(System.Environment.CurrentDirectory, "*.dll");

            foreach (string file in files)
            {
                try
                {
                    Assembly asm = Assembly.LoadFile(file);
                    theType = asm.GetTypes()
                        .Where(x => x.IsClass == true)
                        .Where(x => x.IsAbstract == false)
                        .Where(x => x.FullName.Trim().ToLower() == typeName)
                        .FirstOrDefault();

                    if (theType != null)
                    {
                        break;
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
            }

            return theType;
        }

        public Type FindConcreteTypeImplementingInterface(Type interfaceType, Assembly assemblyToScan)
        {
            Type retval = null;

            foreach (Type type in assemblyToScan.GetTypes())
            {
                if (type.IsClass & !type.IsAbstract)
                    if (interfaceType.IsAssignableFrom(type))
                    {
                        retval = type;
                        break;
                    }
            }

            return retval;
        }

        public Type[] FindConcreteTypesImplementingInterface(Type interfaceType, Assembly assemblyToScan)
        {
            var retval = new List<Type>();

            try
            {
                foreach (Type type in assemblyToScan.GetTypes())
                {
                    if (type.IsClass & !type.IsAbstract)
                        if (interfaceType.IsAssignableFrom(type))
                        {
                            if (!retval.Contains(type))
                                retval.Add(type);
                        }
                }
            }
            catch
            {
            }

            return retval.ToArray();
        }

        public object[] FindConcreteTypesImplementingInterfaceAndBuild(Type interfaceType, Assembly assemblyToScan)
        {
            var objects = new List<object>();
            Type[] types = FindConcreteTypesImplementingInterface(interfaceType, assemblyToScan);

            foreach (Type type in types)
            {
                if (type.IsAbstract) continue;
                objects.Add(BuildInstance(type.AssemblyQualifiedName));
            }

            return objects.ToArray();
        }

        public IEndpointBuilderSubscription InvokeCreateSubscriptionForBuilder(object theBuilder)
        {
            MethodInfo method = theBuilder.GetType().GetMethod("CreateSubscription");
            IEndpointBuilderSubscription subscription = method.Invoke(theBuilder, null) as IEndpointBuilderSubscription;
            return subscription;
        }

        public Type FindConcreteTypeForEndpointFactoryDefinition(string theFullyQualifiedType)
        {
            Type theType = null;
            Assembly asm = null;

            string[] typeParts = theFullyQualifiedType.Split(new[] { ',' });

            try
            {
                asm = Assembly.Load(typeParts[1].Trim());
            }
            catch
            {
                string msg = string.Format("Could not load the assembly {0} to create type {1}.", typeParts[1],
                                           typeParts[0]);
            }

            if (asm != null)
            {

                theType = (from type in asm.GetTypes()
                           where type.FullName.StartsWith(typeParts[1].Trim())
                                 && type.IsClass == true
                                 && type.IsAbstract == false
                           select type).FirstOrDefault();
            }

            return theType;
        }

        public object InvokeEndpointFactoryCreate(object factory, string endpointName, string endpointUri)
        {
            var theMethod = factory.GetType().GetMethod("CreateEndpointWithName");
            var theEndpoint = theMethod.Invoke(factory, new object[] { endpointName, endpointUri });
            return theEndpoint;
        }

        public ISagaData InvokeFindForSagaDataRepository(object sagaFinder, Guid instanceId)
        {
            MethodInfo method = sagaFinder.GetType().GetMethod("Find");
            object saga = method.Invoke(sagaFinder, new object[] { instanceId });
            return saga as ISagaData;
        }

        public ISagaData InvokeCreateForSagaDataRepository(object sagaFinder, Guid instanceId)
        {
            MethodInfo method = sagaFinder.GetType().GetMethod("Create");
            object saga = method.Invoke(sagaFinder, new object[] { instanceId });
            return saga as ISagaData;
        }

        public void InvokeRemoveForSagaDataRepository(object sagaFinder, Guid instanceId)
        {
            MethodInfo method = sagaFinder.GetType().GetMethod("Remove");
            method.Invoke(sagaFinder, new object[] { instanceId });
        }

        public void InvokeSaveForSagaDataRepository(object sagaFinder, ISagaData data)
        {
            MethodInfo method = sagaFinder.GetType().GetMethod("Save");
            method.Invoke(sagaFinder, new object[] { data });
        }

        public BaseEndpoint InvokeBuildForEndpointBuilder(object builder, string uri)
        {
            //PropertyInfo property = builder.GetType().GetProperty("Serializer");
            //property.SetValue(builder, _kernel.Resolve<ISerializationProvider>(), null);

            MethodInfo method = builder.GetType().GetMethod("Build", new Type[] {typeof(string)});
            object endpoint = method.Invoke(builder, new object[] { uri });

            return endpoint as BaseEndpoint;
        }

    }
}