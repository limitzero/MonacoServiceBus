using System;
using System.Collections.Generic;
using System.Reflection;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Sagas;

namespace Monaco.Internals.Reflection
{
    /// <summary>
    /// Contract for internally based reflection helper functions.
    /// </summary>
    public interface IReflection
    {
        /// <summary>
        /// This will bulid a new instance of the object by type reference
        /// </summary>
        /// <param name="currentType">The type to create</param>
        /// <returns></returns>
        object BuildInstance(Type currentType);

        /// <summary>
        /// This will build a new instance of the object by the fully qualified type name.
        /// </summary>
        /// <param name="typeName"></param>
        /// <returns></returns>
        object BuildInstance(string typeName);

        /// <summary>
        /// This will search the current executable directory for the type specified
        /// and return the type instance.
        /// </summary>
        /// <param name="typeName">The fully qualified type to search for.</param>
        /// <returns></returns>
        Type FindType(string typeName);

        Type FindConcreteTypeForEndpointFactoryDefinition(string theFullyQualifiedType);
       
        Type FindConcreteTypeImplementingInterface(Type interfaceType, Assembly assemblyToScan);

        Type[] FindConcreteTypesImplementingInterface(Type interfaceType, Assembly assemblyToScan);

        object[] FindConcreteTypesImplementingInterfaceAndBuild(Type interfaceType, Assembly assemblyToScan);

        /// <summary>
        /// This will dynamically call the builder implementation to get the subscription details
        /// for endpoint creation.
        /// </summary>
        /// <param name="theBuilder"></param>
        /// <returns></returns>
        IEndpointBuilderSubscription InvokeCreateSubscriptionForBuilder(object theBuilder);

        /// <summary>
        /// This will create an endpoint with the specified polling interval.
        /// </summary>
        /// <param name="factory"></param>
        /// <param name="endpointName"></param>
        /// <param name="endpointUri"></param>
        /// <returns></returns>
        object InvokeEndpointFactoryCreate(object factory, string endpointName, string endpointUri);

        /// <summary>
        /// This will call the "Find" method on the saga data persister implementation
        /// to return an instance of a the saga data from the persistance store.
        /// </summary>
        /// <param name="sagaFinder">Current instance of the saga data finder</param>
        /// <param name="instanceId">Unique indentifier for the saga data instance</param>
        /// <returns>
        /// Saga data instance or null instance
        /// </returns>
        ISagaData InvokeFindForSagaDataRepository(object sagaFinder, Guid instanceId);

        /// <summary>
        /// This will call the "Create" method on the saga data persister implementation
        /// to return a new instance of a the saga data.
        /// </summary>
        /// <param name="sagaFinder">Current instance of the saga data finder</param>
        /// <param name="instanceId">Unique indentifier for the saga instance.</param>
        /// <returns>
        /// Saga data instance or null instance
        /// </returns>
        ISagaData InvokeCreateForSagaDataRepository(object sagaFinder, Guid instanceId);

        /// <summary>
        /// This will call the "Remove" method on the saga data persister implementation
        /// to remove theinstance of a the saga data.
        /// </summary>
        /// <param name="sagaFinder">Current instance of the saga data finder</param>
        /// <param name="instanceId">Unique indentifier for the saga instance.</param>
        void InvokeRemoveForSagaDataRepository(object sagaFinder, Guid instanceId);

        /// <summary>
        /// This will call the "Save" method on the saga data persister implementation
        /// to save the saga data to the persistance store.
        /// </summary>
        /// <param name="sagaFinder">Current instance of the saga data finder</param>
        /// <param name="data">Saga data to save.</param>
        /// <returns>
        /// Saga data instance or null instance (implemented as object)
        /// </returns>
        void InvokeSaveForSagaDataRepository(object sagaFinder, ISagaData data);

        /// <summary>
        /// This will call the "Build" method on the endpoint builder definition 
        /// to return a concrete instance of an object derived from <seealso cref="BaseEndpoint"/>
        /// </summary>
        /// <param name="builder">Builder instance</param>
        /// <param name="uri">Uri specification for endpoint</param>
        /// <returns></returns>
        BaseEndpoint InvokeBuildForEndpointBuilder(object builder, string uri);

        /// <summary>
        /// This will construct an assembly representing all of the interface-based only 
        /// message implementations primarily for the serialization engine.
        /// </summary>
        /// <param name="contracts">Collection of interfaces representing messages</param>
        /// <param name="registerInContainer">Flag to indicate whether or not to add these components to the container.</param>
        ICollection<Type> BuildProxyAssemblyForContracts(ICollection<Type> contracts, bool registerInContainer);

        /// <summary>
        /// This will build a concrete proxy object based on the interface contract.
        /// </summary>
        /// <typeparam name="TCONTRACT">Interface for building a concrete instance</typeparam>
        /// <returns>
        ///  A concrete instance of the {TCONTRACT}.
        /// </returns>
        TCONTRACT BuildProxyFor<TCONTRACT>();
    }
}