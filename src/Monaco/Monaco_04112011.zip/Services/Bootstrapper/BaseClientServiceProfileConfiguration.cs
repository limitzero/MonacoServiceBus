namespace Monaco.Services.Bootstrapper
{
    /// <summary>
    /// This is the client service profile for an service configuration. It will 
    /// configure the service and consumers in the message bus and also
    /// purge the underlying endpoint contents when started. This configuration 
    /// is not meant to have messages survive restarts of the service.
    /// </summary>
    public abstract class BaseClientServiceProfileConfiguration : BaseServiceBootstrapper
    {
        public override void Configure()
        {
            base.Configure();

            if (this.Service != null)
            {
                // force the endpoint to purge all messages when starting the service:
                this.Service.Endpoint.Transport.IsRecoverable = false;
            }
        }
    }
}