namespace Monaco.Services.Bootstrapper
{
    /// <summary>
    /// This is the server service profile for a service configuration. It will 
    /// configure the service and consumers in the message bus and also
    /// keep all messages in the endpoint location. This configuration 
    /// is meant to have messages survive restarts of the service.
    /// </summary>
    public abstract class BaseServerServiceProfileConfiguration : BaseServiceBootstrapper
    {
        public override void Configure()
        {
            base.Configure();

            if (this.Service != null)
            {
                // force the endpoint to purge all messages when starting the service:
                this.Service.Endpoint.Transport.IsRecoverable = true;
            }

        }
    }
}