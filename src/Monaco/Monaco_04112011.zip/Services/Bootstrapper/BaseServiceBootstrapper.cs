using Monaco.Configuration.Bootstrapper;
using Monaco.Configuration.Service;
using Monaco.Services.Impl;

namespace Monaco.Services.Bootstrapper
{
    /// <summary>
    /// Bootstrapper for configuring message services for message transformation via pipeline and filters.
    /// </summary>
    public abstract class BaseServiceBootstrapper : BaseBootstrapper
    {
        protected BaseService Service { get; private set; }

        public override void Configure()
        {
            IServiceConfiguration configuration = Kernel.Resolve<IServiceConfiguration>();

            this.ConfigureService(configuration);

            BaseService service = configuration.Create();

            if (service != null)
            {
                IServiceRepository repository = Kernel.Resolve<IServiceRepository>();

                if (repository != null)
                {
                    repository.Register(service);
                    this.Service = service;
                }
            }

        }

        /// <summary>
        /// This will take the user-supplied information for the service, create it and register 
        /// it in the repository.
        /// </summary>
        /// <param name="configuration"></param>
        public abstract void ConfigureService(IServiceConfiguration configuration);
    }
}