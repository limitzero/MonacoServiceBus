using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Monaco.Agents.Scheduler;
using Monaco.Agents.Scheduler.Tasks.Configuration;
using Monaco.Agents.Scheduler.Tasks.Configuration.Impl;
using Monaco.Configuration.Endpoint;
using Monaco.Endpoint;
using Monaco.Endpoint.Health.Tasks;
using Monaco.Endpoint.Impl;
using Monaco.Internals;
using Monaco.Internals.Eventing;
using Monaco.Pipeline;
using Monaco.Pipeline.Impl.Pipelines.Serialization;
using Monaco.Subscriptions;
using Monaco.Subscriptions.Impl;
using Monaco.Transport;

namespace Monaco.Services.Impl
{
    /// <summary>
    /// Contract that all services will have on the message bus that 
    /// will require custom service components to respond to messages
    /// that are sent out via the bus or other serviced components.
    /// </summary>
    public abstract class BaseService : IService
    {
        private bool _disposing;
        private readonly IServiceBus _bus;
        private readonly static object _endpoint_lock = new object();

        public string Name { get; set; }

        public string Uri { get; private set; }

        public BaseEndpoint Endpoint { get; private set; }

        public BasePipeline Pipeline { get; private set; }

        public bool IsRunning { get; private set; }

        public ICollection<Type> Consumers { get; private set; }

        public event Action<IEnvelope> OnServiceMessageReceived;

        public event EventHandler<ComponentStartedEventArgs> ComponentStartedEvent;

        public event EventHandler<ComponentStoppedEventArgs> ComponentStoppedEvent;

        public event EventHandler<ComponentErrorEventArgs> ComponentErrorEvent;

        protected BaseService(IServiceBus bus)
        {
            _bus = bus;
            this.Consumers = new List<Type>();

            // every service needs a pipeline to handle
            // the messages coming to and from the endpoint, 
            // set the service to have the basic serialization
            // pipeline to at least attempt to process the message:
            this.Pipeline = new SerializationPipeline();
        }

        public void Dispose()
        {
            _disposing = true;
            this.Stop();
        }

        public void Start()
        {
            if (this.IsRunning == true)
            {
                return;
            }

            this.RefreshEndpoint(true);
            this.RefreshPipeline(true);
            this.IsRunning = true;
        }

        public void Stop()
        {
            this.RefreshEndpoint(false);
            this.RefreshPipeline(false);
            this.IsRunning = false;
        }

        public IEnvelope Invoke(PipelineDirection direction, IEnvelope envelope)
        {
            try
            {
                envelope = this.Pipeline.Execute(direction, _bus, envelope);
            }
            catch (Exception e)
            {
                throw;
            }

            return envelope;
        }

        public IEnvelope InvokeForSend(IEnvelope envelope)
        {
            try
            {
                envelope = this.Pipeline.Execute(PipelineDirection.Send, _bus, envelope);
            }
            catch (Exception e)
            {
                throw;
            }

            return envelope;
        }

        public IEnvelope InvokeForReceive(IEnvelope envelope)
        {
            try
            {
                envelope = this.Pipeline.Execute(PipelineDirection.Receive, _bus, envelope);
            }
            catch (Exception e)
            {
                throw;
            }

            return envelope;
        }

        public void RegisterPipeline(BasePipeline pipeline)
        {
            this.Pipeline = pipeline;
        }

        public void RegisterEndpoint(BaseEndpoint endpoint)
        {
            this.Endpoint = endpoint;
        }

        public void RegisterEndpoint(IEndpointConfiguration configuration)
        {
            // create and register the service endpoint:
            IEndpointAdapter adapter = _bus.Find<IEndpointAdapter>();
            IEndpointRegistry registry = _bus.Find<IEndpointRegistry>();

            this.Endpoint = adapter.GetEndpoint(configuration.Uri);

            if (string.IsNullOrEmpty(configuration.Name) == true)
            {
                this.Endpoint.Name = string.Format("<{0}>@<{1}>", this.Name, Endpoint.Address.Uri);
            }
            else
            {
                this.Endpoint.Name = configuration.Name;
            }

            this.Endpoint.MaxRetries = configuration.MaxRetries;
            this.Endpoint.Concurrency = configuration.Concurrency;
            this.Uri = Endpoint.Address.Uri;

            registry.Register(this.Endpoint);

            // create the "heartbeat task" for the service endpoint (if configured):
            if (string.IsNullOrEmpty(configuration.StatusInterval) == false &&
                configuration.StatusInterval != Constants.EMPTY_TIME_INTERVAL)
            {
                EndpointHeartBeatTask task = new EndpointHeartBeatTask(Guid.NewGuid().ToString(), configuration.Uri,
                                                                       configuration.StatusInterval,
                                                                       configuration.StatusIntervalGracePeriod);

                IScheduler scheduler = _bus.Find<IScheduler>();

                ITaskConfiguration taskConfiguration = new TaskConfiguration();
                taskConfiguration.TaskName = string.Format("Heartbeat task for endpoint <{0}>@<{1}>",
                                                           configuration.Uri, configuration.StatusInterval);
                taskConfiguration.ComponentInstance = task;
                taskConfiguration.Interval = configuration.StatusInterval;
                taskConfiguration.HaltOnError = false;
                taskConfiguration.ForceStart = true;
                scheduler.CreateFromConfiguration(taskConfiguration);
            }
        }

        public void RegisterHandler<THANDLER>() where THANDLER : IConsumer
        {
            this.RegisterHandler(typeof(THANDLER));
        }

        public void RegisterHandler(Type handler)
        {
            if (typeof(IConsumer).IsAssignableFrom(handler) == false)
                throw new Exception(string.Format("The current message consumer '{0}' for service '{1}' is not derived from the interfaces of '{2}'. " +
                    "Please make sure that this component is derived from either one of this interfaces before registering with the service implementation.",
                      handler.FullName,
                      this.Name,
                      string.Concat(typeof(Consumes<>).FullName, ", ", typeof(StartedBy<>).FullName, ", or ", typeof(Orchestrates<>).FullName)));

            IConsumer theHandler = _bus.Find(handler) as IConsumer;

            if (handler != null)
            {
                if (this.Consumers.Contains(handler) == false)
                {
                    this.BuildSubscriptions(theHandler);
                    this.Consumers.Add(handler);
                }

            }
        }

        public string Verbalize()
        {
            string contents = string.Empty;

            using (MemoryStream stream = new MemoryStream())
            {
                System.Diagnostics.TextWriterTraceListener trace =
                    new System.Diagnostics.TextWriterTraceListener(stream);

                if (this.Pipeline.ReceiveFilters.Count > 0)
                {
                    var pipeline = string.Format(
                        "A custom receive pipeline of '{0}' will be invoked for every message " +
                        "and apply the following filters after the message is received from the location of '{1}':",
                        this.Pipeline.Name,
                        this.Endpoint.Address.Uri);

                    trace.WriteLine(pipeline);
                    trace.IndentLevel = 4;

                    foreach (var filter in this.Pipeline.ReceiveFilters)
                    {
                        trace.WriteLine(string.Format("- {0}", filter.Name));
                    }

                    trace.WriteLine(string.Empty);
                }

                if (this.Pipeline.SendFilters.Count > 0)
                {
                    var pipeline = string.Format(
                        "A custom send pipeline of '{0}' will be invoked for every message " +
                        "and apply the following filters before the message is sent to the location of '{1}':",
                        this.Pipeline.Name,
                        this.Endpoint.Address.Uri);

                    trace.WriteLine(pipeline);
                    trace.IndentLevel = 4;

                    foreach (var filter in this.Pipeline.SendFilters)
                    {
                        trace.WriteLine(string.Format("- {0}", filter.Name));
                    }

                    trace.WriteLine(string.Empty);
                }

                trace.Flush();
                stream.Seek(0, SeekOrigin.Begin);
                using (TextReader reader = new StreamReader(stream))
                {
                    contents = reader.ReadToEnd();
                }
            }

            return contents;
        }

        private void RefreshEndpoint(bool isStarting)
        {
            if (this.Endpoint == null)
            {
                return;
            }

            if (isStarting == true)
            {
                lock (_endpoint_lock)
                {
                    this.Endpoint.EndpointMessageReceived += OnMessageReceived;
                    this.Endpoint.ComponentErrorEvent += OnComponentError;
                    this.Endpoint.ComponentStartedEvent += OnComponentStarted;
                    this.Endpoint.ComponentStoppedEvent += OnComponentStopped;
                    this.Endpoint.Start();
                }
            }
            else
            {
                lock (_endpoint_lock)
                {
                    if (this.Endpoint == null) return;

                    this.Endpoint.Stop();
                    this.Endpoint.EndpointMessageReceived -= OnMessageReceived;
                    this.Endpoint.ComponentErrorEvent -= OnComponentError;
                    this.Endpoint.ComponentStartedEvent -= OnComponentStarted;
                    this.Endpoint.ComponentStoppedEvent -= OnComponentStopped;
                    this.Endpoint = null;
                }
            }
        }

        private void RefreshPipeline(bool isStarting)
        {
            if (isStarting == true)
            {
                this.Pipeline.ComponentErrorEvent += OnComponentError;
                this.Pipeline.ComponentStartedEvent += OnComponentStarted;
                this.Pipeline.ComponentStoppedEvent += OnComponentStopped;
            }
            else
            {
                this.Pipeline.ComponentErrorEvent -= OnComponentError;
                this.Pipeline.ComponentStartedEvent -= OnComponentStarted;
                this.Pipeline.ComponentStoppedEvent -= OnComponentStopped;
            }
        }

        private void BuildSubscriptions(IConsumer handler)
        {
            ISubscriptionRepository repository = _bus.Find<ISubscriptionRepository>();

            ICollection<Type> theInterfaces = (from theInterface in handler.GetType().GetInterfaces()
                                               where typeof(IConsumer).IsAssignableFrom(theInterface)
                                               select theInterface).ToList();

            foreach (Type theInterface in theInterfaces)
            {
                if (theInterface.GetGenericArguments().Length == 1)
                {
                    Type theMessage = theInterface.GetGenericArguments()[0];

                    ISubscription subscription = new Subscription();
                    subscription.Component = handler.GetType().AssemblyQualifiedName;
                    subscription.Uri = this.Uri;
                    subscription.IsActive = true;

                    if (theMessage != null)
                    {
                        if (theMessage.IsInterface == false)
                        {
                            subscription.Message = theMessage.FullName;
                        }

                        if (theMessage.IsInterface == true)
                        {
                            var message = _bus.Create(theMessage);
                            subscription.Message = message.GetType().FullName;
                        }

                    }

                    repository.Register(subscription);
                }
            }
        }

        private void OnMessageReceived(object sender, EndpointMessageReceivedEventArgs e)
        {
            if (this.OnServiceMessageReceived != null)
            {
                OnServiceMessageReceived(e.Envelope);
            }
        }

        private void OnComponentStarted(object sender, ComponentStartedEventArgs e)
        {
            EventHandler<ComponentStartedEventArgs> evt = this.ComponentStartedEvent;

            if (evt != null)
            {
                evt(this, e);
            }
        }

        private void OnComponentStopped(object sender, ComponentStoppedEventArgs e)
        {
            EventHandler<ComponentStoppedEventArgs> evt = this.ComponentStoppedEvent;

            if (evt != null)
            {
                evt(this, e);
            }
        }

        private void OnComponentError(object sender, ComponentErrorEventArgs e)
        {
            EventHandler<ComponentErrorEventArgs> evt = this.ComponentErrorEvent;

            if (evt != null)
            {
                evt(this, e);
            }
        }

        private bool OnServiceError(Exception exception)
        {
            EventHandler<ComponentErrorEventArgs> evt = this.ComponentErrorEvent;
            bool isHandlerAttached = (evt != null);

            if (isHandlerAttached = true)
            {
                evt(this, new ComponentErrorEventArgs(exception));
            }

            return isHandlerAttached;
        }

    }
}