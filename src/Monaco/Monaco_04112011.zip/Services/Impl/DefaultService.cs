namespace Monaco.Services.Impl
{
    public class DefaultService : BaseService
    {
        public DefaultService(IServiceBus bus) : base(bus)
        {
            this.Name = "Default Service";
        }
    }
}