using System.Collections.Generic;
using System.Linq;
using Monaco.Internals.Collections;

namespace Monaco.Services.Impl
{
    public class ServiceRepository : IServiceRepository
    {
        private bool _disposing;
        private static readonly object _services_lock = new object();
        private static IThreadSafeList<BaseService> _services;

        public ICollection<BaseService> Services { get { return _services; }}

        public ServiceRepository()
        {
            if(_services == null)
            {
                _services = new ThreadSafeList<BaseService>();
            }
        }

        public void Dispose()
        {
            _disposing = true;

            if(_services != null)
            {
                _services.Clear();
                _services = null;
            }
        }

        public BaseService FindByName(string name)
        {
            lock(_services_lock)
            {
                return (from service in this.Services
                        where service.Name.Trim().ToLower() == name.Trim().ToLower()
                        select service).FirstOrDefault();
            }
        }

        public BaseService FindByUri(string endpointUri)
        {
            lock (_services_lock)
            {
                return (from service in this.Services
                        where service.Uri.Trim().ToLower() == endpointUri.Trim().ToLower()
                        select service).FirstOrDefault();
            }
        }

        public void Register(BaseService service)
        {
            lock (_services_lock)
            {
                BaseService theService = this.FindByUri(service.Uri);

                if(theService == null)
                {
                    _services.Add(service);
                }
            }
        }
    }
}