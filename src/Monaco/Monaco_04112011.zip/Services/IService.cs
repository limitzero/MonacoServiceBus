using System;
using System.Collections.Generic;
using System.IO;
using Monaco.Configuration.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Internals;
using Monaco.Internals.Eventing;
using Monaco.Pipeline;
using Monaco.Transport;

namespace Monaco.Services
{
    /// <summary>
    /// Contract for grouping a set of components together for interaction on the message bus.
    /// </summary>
    public interface IService : IStartable, IStartableEventBroadcaster, IErrorEventBroadcaster
    {
        /// <summary>
        /// Event that is triggered when a message arrives from the service endpoint.
        /// </summary>
        event Action<IEnvelope> OnServiceMessageReceived;

        /// <summary>
        /// Gets or sets the name of the service.
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// Gets the current endpoint uri associated with the service.
        /// </summary>
        string Uri { get;  }

        /// <summary>
        /// Gets the current message handling pipeline to be 
        /// invoked for message delivery and receipt.
        /// </summary>
        BasePipeline Pipeline { get; }

        /// <summary>
        /// Gets the current endpoint associated with the service.
        /// </summary>
        BaseEndpoint Endpoint { get; }

        /// <summary>
        /// Gets the collection of message consumers logically attached to the service.
        /// </summary>
        ICollection<Type> Consumers { get; }

        /// <summary>
        /// This will register a concrete instance of a message 
        /// handing pipeline that will be responsible for transforming 
        /// the message a concrete instance that implements <seealso cref="IMessage"/>
        /// for received messages and transforming messages that are delivered
        /// to the <seealso cref="Stream"/> format for the endpoint implementation.
        /// </summary>
        /// <param name="pipeline"></param>
        void RegisterPipeline(BasePipeline pipeline);

        /// <summary>
        /// This will register an endpoint from the supplied configuration
        /// information and set the endpoint implemenation for the service.
        /// </summary>
        /// <param name="configuration">The configuration for the endpoint.</param>
        void RegisterEndpoint(IEndpointConfiguration configuration);

        /// <summary>
        /// This will set the endpoint for the service based on a
        /// concrete instance of an endpoint implementation.
        /// </summary>
        /// <param name="endpoint">The endpoint implementation to set on the service</param>
       // void RegisterEndpoint(BaseEndpoint endpoint);

        /// <summary>
        /// This will invoke the message handling pipeline for the service 
        /// before the message is dispatched to the local uri associated 
        /// with the service.
        /// </summary>
        /// <param name="envelope"></param>
        /// <returns></returns>
        IEnvelope InvokeForSend(IEnvelope envelope);

        /// <summary>
        /// This will invoke the message handling pipeline for the service
        /// after the message is received from the endpoint associated 
        /// with the service endpoint uri and after execution the message
        /// will be dispatched to the corresponding components for processing.
        /// </summary>
        /// <param name="envelope"></param>
        IEnvelope InvokeForReceive(IEnvelope envelope);
    }
}