using System.Collections.Generic;
using System;
using Monaco.Services.Impl;

namespace Monaco.Services
{
    public interface IServiceRepository : IDisposable
    {
        /// <summary>
        /// Gets all of the registered services on the bus instance.
        /// </summary>
        ICollection<BaseService> Services { get; }

        /// <summary>
        /// This will return a service instance based on the name supplied.
        /// </summary>
        /// <param name="name">Name of the service.</param>
        /// <returns></returns>
        BaseService FindByName(string name);

        /// <summary>
        /// This will return a service instance based on the endpoint supplied
        /// </summary>
        /// <param name="endpointUri">Endpoint that the service will receive/deliver messages</param>
        /// <returns></returns>
        BaseService FindByUri(string endpointUri);

        /// <summary>
        /// This will place a service in the local repository.
        /// </summary>
        /// <param name="service"></param>
        void Register(BaseService service);
    }
}