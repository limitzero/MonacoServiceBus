using Castle.Windsor;
using Castle.Windsor.Configuration.Interpreters;

namespace Monaco.Configuration
{
    public class MonacoContainer : WindsorContainer
    {
        private const string _default_config = @"monaco.config.xml";
        private readonly MonacoFacility _facility = new MonacoFacility();

		/// <summary>
		/// This will examine the contents of the app.config 
		/// and initialize the container from the settings.
		/// </summary>
        public MonacoContainer()
			: base(new XmlInterpreter())
        {
			this.InitializeContainer();
			this.RegisterFacility();
        }

		/// <summary>
		/// This will create a new instance of the container
		/// from the standalone configuration file not tied 
		/// to the app.config (default name = monaco.config.xml).
		/// </summary>
		/// <param name="configurationFile"></param>
        public MonacoContainer(string configurationFile)
            : base(configurationFile)
        {
            this.InitializeContainer();
            this.RegisterFacility();
        }

        public virtual void InitializeContainer()
        {
        }

        private void RegisterFacility()
        {
            base.AddFacility(MonacoFacility.FACILITY_ID, _facility);
        }
    }
}