using Castle.Core.Configuration;
using Monaco.Agents.Scheduler;
using Monaco.Endpoint.Health.Tasks;
using Monaco.Internals;

namespace Monaco.Configuration.Elements
{
    public class EndpointServiceManagerElementBuilder : BaseElementBuilder
    {
        private const string _elementname = "endpoint-service-manager";

        public override bool IsMatchFor(string name)
        {
            return name.Trim().ToLower() == _elementname.Trim().ToLower();
        }

        public override void Build(IConfiguration configuration)
        {
            string broadcastInterval = configuration.Attributes["broadcast-status-interval"] ?? Constants.EMPTY_TIME_INTERVAL;
            string recycleInterval = configuration.Attributes["recycle-statistics-interval"] ?? Constants.EMPTY_TIME_INTERVAL;

            IScheduler scheduler = Kernel.Resolve<IScheduler>();

            if(broadcastInterval != Constants.EMPTY_TIME_INTERVAL)
            {
                EndpointsStatusBroadcastTask task = new EndpointsStatusBroadcastTask();
                scheduler.CreateScheduledItem("Broadcast All Endpoint Status", broadcastInterval.Trim(), task, "Produce", true, false );
            }

            if (recycleInterval != Constants.EMPTY_TIME_INTERVAL)
            {
                EndpointRecycleStatisticsTask task = new EndpointRecycleStatisticsTask();
                scheduler.CreateScheduledItem("Recycle All Endpoint Statistics", recycleInterval.Trim(), task, "Produce", true, false);
            }

        }
    }
}