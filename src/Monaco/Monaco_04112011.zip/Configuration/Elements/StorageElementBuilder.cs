using System;
using System.Reflection;
using Castle.Core.Configuration;
using Monaco.Agents.Timeout;
using Monaco.Sagas;
using Monaco.Subscriptions;

namespace Monaco.Configuration.Elements
{
	public class StorageElementBuilder : BaseElementBuilder
	{
		private const string _element_name = "storage";

		public override bool IsMatchFor(string name)
		{
			return name.Trim().ToLower() == _element_name.Trim().ToLower();
		}

		public override void Build(IConfiguration configuration)
		{	
			for(int index = 0; index < configuration.Children.Count; index++)
			{
				var element = configuration.Children[index];

				switch (element.Name)
				{
					case "subscriptions":
						this.ConfigureSubscriptionStorage(element);
						break;

					case "sagas":
						this.ConfigureSagaStorage(element);
						break;

					case "saga-data":
						this.ConfigureSagaDataStorage(element);
						break;

					case "timeouts":
						this.ConfigureTimeoutsStorage(element);
						break;
				}
			}
		}

		private void ConfigureSubscriptionStorage(IConfiguration configuration)
		{
			string storageName = "Subscription Storage";

			string provider = this.InspectStorageProvider(storageName, configuration);
			Type providerType = this.ExtractProviderType(storageName, provider);

			try
			{
				this.Kernel.AddComponent(typeof(ISubscriptionRepository).Name, typeof(ISubscriptionRepository), providerType);
			}
			catch (Exception exception)
			{
				throw this.CouldNotRegisterStorageProviderException(storageName, provider, exception);
			}
		}

		private void ConfigureSagaStorage(IConfiguration configuration)
		{
			string storageName = "Saga Storage";

			string provider = this.InspectStorageProvider(storageName, configuration);
			Type providerType = this.ExtractProviderType(storageName, provider);

			try
			{
				this.Kernel.AddComponent(typeof(ISagaRepository).Name, typeof(ISagaRepository), providerType);
			}
			catch (Exception exception)
			{
				throw this.CouldNotRegisterStorageProviderException(storageName, provider, exception);
			}
		}

		private void ConfigureSagaDataStorage(IConfiguration configuration)
		{
			string storageName = "Saga Data Storage";

			string provider = this.InspectStorageProvider(storageName, configuration);
			Type providerType = this.ExtractProviderType(storageName, provider);

			try
			{
				this.Kernel.AddComponent(typeof(ISagaDataRepository<>).Name, typeof(ISagaDataRepository<>), providerType);
			}
			catch (Exception exception)
			{
				throw this.CouldNotRegisterStorageProviderException(storageName, provider, exception);
			}
		}

		private void ConfigureTimeoutsStorage(IConfiguration configuration)
		{
			string storageName = "Timeouts Storage";

			string provider = this.InspectStorageProvider(storageName, configuration);
			Type providerType = this.ExtractProviderType(storageName, provider);

			try
			{
				this.Kernel.AddComponent(typeof(ITimeoutsRepository).Name, typeof(ITimeoutsRepository), providerType);
			}
			catch (Exception exception)
			{
				throw this.CouldNotRegisterStorageProviderException(storageName, provider, exception);
			}
		}

		private string InspectStorageProvider(string storageType, IConfiguration configuration)
		{
			string provider = configuration.Attributes["provider"];

			if(string.IsNullOrEmpty(provider) == true)
			{
				throw new Exception("The provider type was not defined for storage " + storageType);
			}

			return provider;
		}

		private Type ExtractProviderType(string storageProviderName, string typeName)
		{
			Assembly asm = null;
			Type theType = null;

			string[] parts = typeName.Split(new string[] {","}, StringSplitOptions.RemoveEmptyEntries);

			if(parts.Length != 2)
			{
				throw this.StorageProviderNotFullyQualifiedException(storageProviderName);
			}

			try
			{
				asm = Assembly.Load(parts[1]);
			}
			catch (System.IO.FileLoadException fileLoadException)
			{
				throw this.CouldNotLoadProviderAssemblyException(storageProviderName, parts[1]);
			}

			try
			{
				var instance = asm.CreateInstance(parts[0]);
				theType = instance.GetType();
			}
			catch (Exception)
			{
				throw;
			}

			return theType;
		}
		
		private Exception CouldNotLoadProviderAssemblyException(string provider, string providerAssembly)
		{
			return new Exception(string.Format("The provider '{0}' could not be loaded from assembly '{1}", 
				provider, providerAssembly));
		}

		private Exception StorageProviderNotFullyQualifiedException(string storageProviderName)
		{
			return new Exception(string.Format("For the storage provider '{0}', please specify the fully qualified type of the object providing the storage.",
			storageProviderName));		
		}

		private Exception CouldNotRegisterStorageProviderException(string storageName, string provider, Exception exception)
		{
			return new Exception(string.Format("Could not register provider '{0}' for storage '{1}'. Reason: {2}", 
 				provider, storageName), exception);
		}
	}
}