using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Castle.Core.Configuration;
using Monaco.Internals.Reflection;
using Monaco.Internals.Serialization;

namespace Monaco.Configuration.Elements
{
    /// <summary>
    /// Configuration element for loading messages into 
    /// the serializer
    /// 
    /// Node Syntax:
    /// <messages>
    ///    <add name="{full namespace of assembly for messages}" />
    ///    ...
    /// </messages>
    /// </summary>
    public class MessagesElementBuilder : BaseElementBuilder
    {
        private const string _element = "messages";

        public override bool IsMatchFor(string name)
        {
            return _element.Trim() == name.Trim().ToLower();
        }

        public override void Build(IConfiguration configuration)
        {
            var messages = new List<Type>();
            Assembly asm = null;
            ISerializationProvider serializationProvider = Kernel.Resolve<ISerializationProvider>();

            for (int index = 0; index < configuration.Children.Count; index++)
            {
                IConfiguration msg = configuration.Children[index];
                string location = msg.Attributes["location"];
                string @namespace = msg.Attributes["name"];

                if (!string.IsNullOrEmpty(location))
                {
                    asm = Assembly.LoadFile(location);
                }

                if (string.IsNullOrEmpty(location))
                {
                    if (string.IsNullOrEmpty(@namespace) == false)
                    {
                        asm = Assembly.Load(@namespace);
                    }
                }

                //build the serializer for the messages:
                var publishableMessages = FindClientPublishableMessages(asm);
                messages.AddRange(publishableMessages);
            }

            // build the serializer based on client messages and interfaced-based messages:
            ICollection<Type> proxyTypes = this.BuildAssemblyForInterfaceBasedMessages(messages);

            foreach (Type type in proxyTypes)
            {
                serializationProvider.AddType(type);
            }

            ICollection<Type> nonProxies = messages.Where(x => x.IsInterface == false).ToList();

            foreach (Type type in nonProxies)
            {
                serializationProvider.AddType(type);
            }
           
            // find the publishable messages for the service bus:
            var busPublishableMessages = FindServerPublishableMessages(this.GetType().Assembly);

            foreach (Type type in busPublishableMessages)
            {
                serializationProvider.AddType(type);
            }

            serializationProvider.Initialize();
        }

        public static ICollection<Type> FindPublishableMessages(Type theType)
        {
            return FindServerPublishableMessages(theType.Assembly);
        }

        private static ICollection<Type> FindClientPublishableMessages(Assembly theAssembly)
        {
            List<Type> publishableMessages = new List<Type>();

            foreach (Type theType in theAssembly.GetTypes())
            {
                if (theType.IsInterface == true && typeof(IMessage).IsAssignableFrom(theType))
                {
                    publishableMessages.Add(theType);
                }

                if (theType.IsEnum == true)
                {
                    publishableMessages.Add(theType);
                }

                if (theType.IsClass == true && typeof(IMessage).IsAssignableFrom(theType))
                {
                    publishableMessages.Add(theType);
                }

            }

            return publishableMessages;
        }

        public static ICollection<Type> FindServerPublishableMessages(Assembly theAssembly)
        {
            List<Type> publishableMessages = new List<Type>();

            foreach (Type theType in theAssembly.GetTypes())
            {
                if (theType.IsEnum == true)
                {
                    publishableMessages.Add(theType);
                }

                if (theType.IsClass == true && typeof(IMessage).IsAssignableFrom(theType))
                {
                    publishableMessages.Add(theType);
                }
            }

            return publishableMessages.Distinct().ToList();
        }

        private ICollection<Type> BuildAssemblyForInterfaceBasedMessages(ICollection<Type> messages)
        {
            ICollection<Type> theInterfaceBasedMessages = (from message in messages
                                                           where message.IsInterface &&
                                                           message.Assembly != this.GetType().Assembly
                                                           select message).Distinct().ToList();

            var theProxiedTypes = Kernel.Resolve<IReflection>()
                .BuildProxyAssemblyForContracts(theInterfaceBasedMessages, true);

            return theProxiedTypes;
        }
    }
}