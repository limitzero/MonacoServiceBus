using Castle.Core.Configuration;
using Monaco.Endpoint;
using Monaco.Exceptions;
using Monaco.Internals.Reflection;

namespace Monaco.Configuration.Elements
{
    public class EndpointBuildersElementBuilder : BaseElementBuilder
    {
        private const string _element_name = "endpoint-builders";

        public override bool IsMatchFor(string name)
        {
            return _element_name.Trim().ToLower() == name.Trim().ToLower();
        }

        public override void Build(IConfiguration configuration)
        {
            IReflection reflection = Kernel.Resolve<IReflection>(); 

            // create a subscription for all builders and register 
            // the subscription in the builder subscription repository:
            for (int index = 0; index < configuration.Children.Count; index++)
            {
                IConfiguration builder = configuration.Children[index];
                
                if(builder != null)
                {
                    string builderType = builder.Attributes["type"];
                    object theBuilder = reflection.BuildInstance(builderType);

                    if(theBuilder == null)
                    {
                        throw new MonacoConfigurationException(
                            string.Format(
                                "The endpoint builder type '{0}' could not be created. Please check the type " +
                                "name for proper configuration.",
                                builderType));
                    }

                    IEndpointBuilderSubscription subscription = reflection.InvokeCreateSubscriptionForBuilder(theBuilder);
                    Kernel.Resolve<IEndpointBuilderSubscriptionRepository>().Add(subscription);
                }

            }

        }
    }
}