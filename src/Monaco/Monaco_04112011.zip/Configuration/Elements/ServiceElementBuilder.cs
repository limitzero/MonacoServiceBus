using System;
using System.Collections;
using Castle.Core.Configuration;
using Monaco.Configuration.Endpoint;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Exceptions;
using Monaco.Pipeline;
using Monaco.Services;
using Monaco.Services.Impl;

namespace Monaco.Configuration.Elements
{
    /* Example:
          <service name="my file service">
	            <implementation ref="my.file.service"  />
	            <pipeline ref="my.file.pipeline" />
	            <endpoint
                    uri="file://c:\orders"
                    concurrency="1"
                    max-retries="2"
                    status-interval="00:00:02"
                    status-interval-grace-period="00:00:05" />    
           </service>
     */
    public class ServiceElementBuilder : BaseElementBuilder
    {
        private const string _element_name = "service";

        public override bool IsMatchFor(string name)
        {
            return name.Trim().ToLower() == _element_name.Trim().ToLower();
        }

        public override void Build(IConfiguration configuration)
        {
            // build the service from the configuration information and register 
            // it with the service registry for endpoint message handling:

            DefaultService service = Kernel.Resolve<DefaultService>();

            string name  = configuration.Attributes["name"] ?? string.Concat("SERVICE-", Guid.NewGuid().ToString());
            service.Name = name; 

            for (int index = 0; index < configuration.Children.Count; index++)
            {
                IConfiguration node = configuration.Children[index];

                if(node.Name.Trim().ToLower() == "implementation")
                {
                    this.BuildServiceImplementation(node, service);
                }

                if (node.Name.Trim().ToLower() == "pipeline")
                {
                    this.BuildPipelineImplementation(node, service);
                }

                if (node.Name.Trim().ToLower() == "endpoint")
                {
                    this.BuildEndpointImplementation(node, service);
                }
            }

            Kernel.Resolve<IServiceRepository>().Register(service);
        }

        private void BuildServiceImplementation(IConfiguration configuration, BaseService service)
        {
            /*
             Example:
             <implementation>
                <add ref="service.component.1" />
                <add ref="service.component.2" />
                ...
             </implementation>
             */

            for(int index = 0; index < configuration.Children.Count; index++)
            {
                IConfiguration reference = configuration.Children[index];

                if(reference != null)
                {
                    string id = reference.Attributes["ref"] ?? string.Empty;

                    if (string.IsNullOrEmpty(id) == false)
                    {
                        try
                        {
                            //IHandler implemetation = Kernel.Resolve(id, new Hashtable()) as IHandler;
                        }
                        catch (Exception e)
                        {
                            throw new MonacoConfigurationException(
                                    string.Format("There was not a service implementation registered with the id " +
                                    "of '{0}' for handling the after it has been received from the endpoint and processed by " +
                                    "the message pipeline for the service '{1}'.", id, service.Name), e);
                        }
                    }  
                }
            }
        }

        private void BuildPipelineImplementation(IConfiguration configuration, BaseService service)
        {
            // example:  <pipeline ref="" />
            string reference = configuration.Attributes["ref"] ?? string.Empty;

            if(string.IsNullOrEmpty(reference) == false)
            {
                try
                {
                    BasePipeline pipeline = Kernel.Resolve(reference, new Hashtable()) as BasePipeline;

                    if(pipeline != null)
                    {
                        service.RegisterPipeline(pipeline);
                    }
                }
                catch (Exception e)
                {
                    throw new MonacoConfigurationException(string.Format("There was not a component registered with the id " + 
                        "of '{0}' for implementing the message pipeline for the service '{1}'.", reference, service.Name), e);                    
                }
            }
        }

        private void BuildEndpointImplementation(IConfiguration configuration, BaseService service)
        {
            /* Example:
              <endpoint
                    uri="msmq://localhost/monaco.esb"
                    concurrency="1"
                    max-retries="2"
                    status-interval="00:00:02"
                    status-interval-grace-period="00:00:05" />      
            */

            if (configuration == null)
            {
                throw new MonacoConfigurationException(
                    "There was not an 'endpoint' element defined under the service node" +
                    "to identify how to locate this service instance for message handling.");
            }

            string uri = configuration.Attributes["uri"] ?? string.Empty;
            string poisionUri = configuration.Attributes["poision-uri"] ?? string.Empty;
            string concurrency = configuration.Attributes["concurrency"] ?? "1";
            string retries = configuration.Attributes["max-retries"] ?? "1";
            string statusInterval = configuration.Attributes["status-interval"] ?? "00:00:05";
            string statusIntervalGracePeriod = configuration.Attributes["status-interval-grace-period"] ?? "00:00:05";

            if (uri == string.Empty)
            {
                throw new MonacoConfigurationException(
                    "For the service, the endpoint uri specifying its location was not specified. " +
                    "Please specify an endpoint location that is specific to the endpoint builder transports " +
                    "attached to this bus instance.");
            }

            // register the service endpoint for receiving messages:
            IEndpointConfiguration endpointConfiguration = new EndpointConfiguration();
            endpointConfiguration.Uri = uri;
            endpointConfiguration.Concurrency = Int32.Parse(concurrency);
            endpointConfiguration.MaxRetries = Int32.Parse(retries);
            endpointConfiguration.StatusInterval = statusInterval;
            endpointConfiguration.StatusIntervalGracePeriod = statusIntervalGracePeriod;
           
            service.RegisterEndpoint(endpointConfiguration);
        }
    }
}