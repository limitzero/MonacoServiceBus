using System;
using Castle.Core.Configuration;
using Monaco.Agents.Scheduler;
using Monaco.Agents.Scheduler.Tasks.Configuration;
using Monaco.Agents.Scheduler.Tasks.Configuration.Impl;
using Monaco.Endpoint;
using Monaco.Endpoint.Health.Tasks;
using Monaco.Endpoint.Impl;
using Monaco.Exceptions;
using Monaco.Internals;
using Monaco.Internals.Reflection;

namespace Monaco.Configuration.Elements
{
    /// <summary>
    /// Configuration element parser for the message bus node.
    /// 
    /// <![CDATA[
    /// <message-bus>
    ///    <endpoint
    ///        name="message bus"
    ///        uri="msmq://localhost/monaco.esb"
    ///        poision-uri="msmq://localhost/monaco.esb.poison"
    ///        concurrency="1"
    ///        max-retries="2"
    ///        status-interval="00:00:02"
    ///        status-interval-grace-period="00:00:05" />
    ///  </message-bus>
    ///  ]]>
    /// </summary>
    public class MessageBusElementBuilder : BaseElementBuilder
    {
        private const string _element = "message-bus";

        public override bool IsMatchFor(string name)
        {
            return _element.Trim() == name.Trim().ToLower();
        }

        public override void Build(IConfiguration configuration)
        {
            IConfiguration endpoint = configuration.Children[0];

            if(endpoint == null)
            {
                throw new MonacoConfigurationException(
                    "There was not an 'endpoint' element defined under the message-bus "+
                    "to identify how to locate this bus instance.");
            }

            //string name = configuration.Attributes["name"] ?? "BUS-" + Guid.NewGuid().ToString();
            //string description = configuration.Attributes["description"] ?? string.Empty;
            string uri = endpoint.Attributes["uri"] ?? string.Empty;
            string poisionUri = endpoint.Attributes["poision-uri"] ?? string.Empty;
            string concurrency = endpoint.Attributes["concurrency"] ?? "1";
            string retries = endpoint.Attributes["max-retries"] ?? "1";
            string statusInterval = endpoint.Attributes["status-interval"] ?? "00:00:20";
            string statusIntervalGracePeriod = endpoint.Attributes["status-interval-grace-period"] ?? "00:00:05";

            if(uri == string.Empty)
            {
                throw new MonacoConfigurationException(
                    "For the message bus, the endpoint uri specifying its location was not specified. " +
                    "Please specify an endpoint location that is specific to the endpoint builder transports " +
                    "attached to this bus instance.");
            }

            IReflection reflection = Kernel.Resolve<IReflection>();
            IEndpointBuilderSubscriptionRepository repository = 
                Kernel.Resolve<IEndpointBuilderSubscriptionRepository>();

            IEndpointBuilderSubscription subscription = repository.Find(uri);

            object builder = reflection.BuildInstance(subscription.Builder);

            // register the message bus endpoint for receiving messages:
            BaseEndpoint busEndpoint = reflection.InvokeBuildForEndpointBuilder(builder, uri);
            busEndpoint.Name = Constants.MESSAGE_BUS_ENDPOINT_NAME;
            busEndpoint.MaxRetries = Int32.Parse(retries);
            busEndpoint.Concurrency = Int32.Parse(concurrency);
            Kernel.Resolve<IEndpointRegistry>().Register(busEndpoint);

            // register the poision endpoint for storing failed messages:
            if(string.IsNullOrEmpty(poisionUri) == false)
            {
                BaseEndpoint poisionEndpoint = reflection.InvokeBuildForEndpointBuilder(builder, poisionUri);
                poisionEndpoint.Name = Constants.MESSAGE_BUS_ENDPOINT_NAME;
                poisionEndpoint.MaxRetries = Int32.Parse(retries);
                Kernel.Resolve<IEndpointRegistry>().Register(poisionEndpoint);
            }

            EndpointHeartBeatTask task = new EndpointHeartBeatTask(Guid.NewGuid().ToString(), uri, statusInterval, statusIntervalGracePeriod);
            IScheduler scheduler = Kernel.Resolve<IScheduler>();

            ITaskConfiguration taskConfiguration = new TaskConfiguration();
            taskConfiguration.TaskName = string.Format("Heartbeat task for endpoint <{0}>@<{1}>", uri, statusInterval);
            taskConfiguration.ComponentInstance = task;
            taskConfiguration.Interval = statusInterval;
            taskConfiguration.HaltOnError = false;

            // TODO: re-enable the heartbeat for the bus:
            //scheduler.CreateFromConfiguration(taskConfiguration);

        }

    }
}