using System;
using Castle.Core.Configuration;
using Monaco.Agents.Scheduler;
using Monaco.Agents.Scheduler.Tasks.Configuration;
using Monaco.Agents.Scheduler.Tasks.Configuration.Impl;
using Monaco.Endpoint;
using Monaco.Endpoint.Health.Tasks;
using Monaco.Endpoint.Impl;
using Monaco.Exceptions;
using Monaco.Internals.Reflection;

namespace Monaco.Configuration.Elements
{
    /// <summary>
    /// Configuration element parser for the message bus node.
    /// 
    /// <![CDATA[
    /// <endpoints>
    ///    <endpoint
    ///        name="name"
    ///        uri="..."
    ///        concurrency="1"
    ///        max-retries="2"
    ///        status-interval="00:00:02"
    ///        status-interval-grace-period="00:00:05" />
    ///  </endpoints>
    ///  ]]>
    /// </summary>
    public class EndpointsElementsBuilder : BaseElementBuilder
    {
        private const string _element = "endpoints";

        public override bool IsMatchFor(string name)
        {
            return _element.Trim() == name.Trim().ToLower();
        }

        public override void Build(IConfiguration configuration)
        {
            IConfiguration anEndpoint = configuration.Children[0];

            if(anEndpoint == null)
            {
                throw new MonacoConfigurationException(
                    "There was not an 'endpoint' element defined under the 'endpoints' "+
                    "to identify how to identify all client messaging endpoints.");
            }

            for(int index = 0; index < configuration.Children.Count; index ++)
            {
                IConfiguration endpoint = configuration.Children[0];
                this.BuildAndRegisterClientEndpoint(endpoint);
            }
        }

        private void BuildAndRegisterClientEndpoint(IConfiguration endpoint)
        {
            string name = endpoint.Attributes["name"] ?? string.Empty;
            string uri = endpoint.Attributes["uri"] ?? string.Empty;
            string concurrency = endpoint.Attributes["concurrency"] ?? "1";
            string retries = endpoint.Attributes["max-retries"] ?? "1";
            string statusInterval = endpoint.Attributes["status-interval"] ?? "00:00:20";
            string statusIntervalGracePeriod = endpoint.Attributes["status-interval-grace-period"] ?? "00:00:05";

            if (name == string.Empty)
            {
                throw new MonacoConfigurationException(
                    "For the current endpoint, a name must be supplied in order to " + 
                    "identify it within the repository.");
            }

            if (uri == string.Empty)
            {
                throw new MonacoConfigurationException(
                    "For the current endpoint, the endpoint uri specifying its location was not specified. " +
                    "Please specify an endpoint location that is specific to the transport " +
                    "that is needed to receive and/or send your desired set of messages.");
            }

            IReflection reflection = Kernel.Resolve<IReflection>();
            IEndpointBuilderSubscriptionRepository repository =
                Kernel.Resolve<IEndpointBuilderSubscriptionRepository>();

            IEndpointBuilderSubscription subscription = repository.Find(uri);

            object builder = reflection.BuildInstance(subscription.Builder);

            // register the endpoint for receiving/sending messages:
            BaseEndpoint anEndpoint = reflection.InvokeBuildForEndpointBuilder(builder, uri);
            anEndpoint.Name = name;
            anEndpoint.MaxRetries = Int32.Parse(retries);
            anEndpoint.Concurrency = Int32.Parse(concurrency);
            Kernel.Resolve<IEndpointRegistry>().Register(anEndpoint);

            if (string.IsNullOrEmpty(statusInterval) == false && string.IsNullOrEmpty(statusIntervalGracePeriod) == false)
            {
                EndpointHeartBeatTask task = new EndpointHeartBeatTask(Guid.NewGuid().ToString(), uri, statusInterval,
                                                                       statusIntervalGracePeriod);
                IScheduler scheduler = Kernel.Resolve<IScheduler>();

                ITaskConfiguration taskConfiguration = new TaskConfiguration();
                taskConfiguration.TaskName = string.Format("Heartbeat task for endpoint <{0}>@<{1}>", uri,
                                                           statusInterval);
                taskConfiguration.ComponentInstance = task;
                taskConfiguration.Interval = statusInterval;
                taskConfiguration.HaltOnError = false;
            }
        }
    }
}