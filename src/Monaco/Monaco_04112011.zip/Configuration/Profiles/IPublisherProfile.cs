using Monaco.Configuration.Profiles.Options;

namespace Monaco.Configuration.Profiles
{
    public interface IPublisherProfile : IProfile, ICanPublishMessages
    {
        
    }
}