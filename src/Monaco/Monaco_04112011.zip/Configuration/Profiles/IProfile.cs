namespace Monaco.Configuration.Profiles
{
    /// <summary>
    /// Role interface for profiles that the service bus can run under.
    /// </summary>
    public interface IProfile
    {}
}