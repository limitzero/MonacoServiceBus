﻿using Castle.MicroKernel.Registration;
using Monaco.Agents.Timeout;
using Monaco.Agents.Timeout.Impl;
using Monaco.Configuration.Bootstrapper.Roles;
using Monaco.Configuration.Profiles;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Exceptions;
using Monaco.Internals;
using Monaco.Internals.Agent;
using Monaco.Services;
using Monaco.Services.Impl;
using Monaco.Subscriptions;
using Monaco.Subscriptions.Impl;

namespace Monaco.Configuration
{
    /// <summary>
    /// Base class for registering a series of message consumers as a logical service.
    /// </summary>
    public abstract class BaseServiceEndpointConfiguration : 
        BaseBusCustomExternalBootstrapper
    {
        private EndpointConfigurator _endpoint;
        private ServiceConfigurator _service;

		protected BaseServiceEndpointConfiguration()
		{
			this.IsActive = true;
		}

    	/// <summary>
        /// This will regiser a service implementation on the current 
        /// message bus instance according to the message handling 
        /// pipeline and endpoint reference for receiving and sending 
        /// messages.
        /// </summary>
        /// <param name="configurators"></param>
        public void RegisterServices(params ServiceConfigurator[] configurators)
        {
            foreach (var configurator in configurators)
            {
                // create the service from the configuration:
                configurator.Configuration.Endpoint = _endpoint.Configuration;

                // configure and register the service:
                BaseService service = ConfigureService(configurator);
                this.RegisterService(service);

                // setup the environment based on profile:
                DoClientProfileSetup(configurator);
                DoServerProfileSetup(configurator);
                DoControlProfileSetup(configurator);
                DoPublisherProfileSetup(configurator);              
            }
        }

        /// <summary>
        /// This will return a configuration object for creating a logical service definition.
        /// </summary>
        /// <returns></returns>
        public ServiceConfigurator GetServiceConfiguration()
        {
            _service = new ServiceConfigurator(Kernel);
            return _service;
        }

        /// <summary>
        /// This will create a configuration object for defining the logical service endpoint.
        /// </summary>
        /// <returns></returns>
        public EndpointConfigurator GetEndpointConfiguration()
        {
            _endpoint = new EndpointConfigurator();
            return _endpoint;
        }

        private void DoClientProfileSetup(ServiceConfigurator configuration)
        {
            IEndpointRegistry registry = Kernel.Resolve<IEndpointRegistry>();

            if (typeof(IClientProfile).IsAssignableFrom(GetType()))
            {
                // make the endpoint be non-recoverable:
                ConfigureForLocalSubscriptions();
                BaseEndpoint theEndpoint = registry.Find(_endpoint.Configuration.Name);
                theEndpoint.Transport.IsRecoverable = false;
            }
        }

        private void DoServerProfileSetup(ServiceConfigurator configuration)
        {
            if (typeof(IServerProfile).IsAssignableFrom(GetType()))
            {
                // make the endpoint be recoverable:
                ConfigureForLocalSubscriptions();
                ConfigureEndpointForRecovery();
            }
        }

        private void DoControlProfileSetup(ServiceConfigurator configuration)
        {
            if (typeof(IConsoleProfile).IsAssignableFrom(GetType()))
            {
                ConfigureEndpointForRecovery();

                // make sure that the subscriptions repository is registered here and 
                // it is not the in-memory version:
                ISubscriptionRepository subscriptionRepository = Kernel.Resolve<ISubscriptionRepository>();

                if (typeof(LocalSubscriptionRepository).IsAssignableFrom(subscriptionRepository.GetType()))
                {
                    throw new MonacoConfigurationException(
                        "For the control profile, the in-memory version of the subscriptions repository can not be used.");
                }

                ITimeoutsRepository timeoutsRepository = Kernel.Resolve<ITimeoutsRepository>();

                if (typeof(LocalTimeoutsRepository).IsAssignableFrom(timeoutsRepository.GetType()))
                {
                    throw new MonacoConfigurationException(
                        "For the control profile, the in-memory version of the timeouts repository can not be used.");
                }

                // make sure to remove the timeouts agent implementation (no need to care about timeouts):
                IAgentRegistry manager = Kernel.Resolve<IAgentRegistry>();
                manager.Unregister<TimeoutsAgent>();
            }
        }

        private void DoPublisherProfileSetup(ServiceConfigurator configuration)
        {
        }

        private BaseService ConfigureService(ServiceConfigurator configurator)
        {
            BaseService service = null;

            if (configurator.Endpoint != null)
            {
                service = configurator.Configuration.Create(configurator.Endpoint);
            }
            else
            {
                 service = configurator.Configuration.Create();
            }

            return service;
        }

        private void ConfigureEndpointForRecovery()
        {
            IEndpointRegistry registry = Kernel.Resolve<IEndpointRegistry>();
            BaseEndpoint theEndpoint = registry.Find(_endpoint.Configuration.Name);
            theEndpoint.Transport.IsRecoverable = true;
        }

        private void ConfigureForLocalSubscriptions()
        {
            try
            {
                Kernel.Register(Component.For<ISubscriptionRepository>()
                                  .ImplementedBy<LocalSubscriptionRepository>()
                                  .Named(Constants.SUBSCRIPTION_REPOSITORY_CONTAINER_KEY)
                                  .LifeStyle.Singleton);
            }
            catch
            {
              
            }
        }

		private void ConfigureSagaStorage()
		{

		}

    	private void RegisterService(BaseService service)
        {
            // register the service in the local repository:
            IServiceRepository repository = Kernel.Resolve<IServiceRepository>();

            if (repository != null)
            {
                repository.Register(service);
            }
        }
    }
}