﻿using Monaco.Configuration.Endpoint;

namespace Monaco.Configuration
{
    public class EndpointConfigurator
    {
        public IEndpointConfiguration Configuration { get; private set; }

        public EndpointConfigurator()
        {
            Configuration = new EndpointConfiguration();
        }

        /// <summary>
        /// This will set the name of the endpoint instance for the logical service.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public EndpointConfigurator Named(string name)
        {
            Configuration.Name = name;
            return this;
        }

        /// <summary>
        /// This will set the uri instance of the endpoint that represents the logical service.
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        public EndpointConfigurator Uri(string uri)
        {
            Configuration.Uri = uri;
            return this;
        }

        /// <summary>
        /// This will set the concurrency (or number of processing instances) for retrieving 
        /// messages from the endpoint location.
        /// </summary>
        /// <param name="concurrency"></param>
        /// <returns></returns>
        public EndpointConfigurator Concurrency(int concurrency)
        {
            Configuration.Concurrency = concurrency;
            return this;
        }

        /// <summary>
        /// This will set the number of retries that the endpoint will attempt 
        /// in the case of an error on delivering a message to the endpoint uri location.
        /// </summary>
        /// <param name="retries"></param>
        /// <returns></returns>
        public EndpointConfigurator MaxRetries(int retries)
        {
            Configuration.MaxRetries = retries;
            return this;
        }
        /// <summary>
        /// This will set the interval (format: 00:00:00 => hours:minutes:seconds)
        /// in which a "heartbeat" message will be sent to the endpoint location 
        /// for periodic health checking.
        /// </summary>
        /// <param name="interval"></param>
        /// <returns></returns>
        public EndpointConfigurator HeartbeatInterval(string interval)
        {
            Configuration.StatusInterval = interval;
            return this;
        }

        /// <summary>
        /// This will set the interval (format: 00:00:00 => hours:minutes:seconds)
        /// in which a "heartbeat" message will allowed to still be valid after the initial 
        /// interval is set for health checking.
        /// </summary>
        /// <param name="interval"></param>
        /// <returns></returns>
        public EndpointConfigurator GracePeriod(string interval)
        {
            Configuration.StatusIntervalGracePeriod = interval;
            return this;
        }
    }
}