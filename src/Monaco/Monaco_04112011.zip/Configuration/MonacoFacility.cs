using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Castle.Core.Configuration;
using Castle.MicroKernel.Facilities;
using Castle.MicroKernel.Registration;
using Monaco.Agents.Scheduler;
using Monaco.Configuration.Bootstrapper;
using Monaco.Configuration.Bootstrapper.Roles;
using Monaco.Configuration.Elements;
using Monaco.Configuration.Service;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Impl;
using Monaco.Internals;
using Monaco.Internals.Agent;
using Monaco.Internals.Agent.Impl;
using Monaco.Internals.Dispatcher;
using Monaco.Internals.Dispatcher.Impl;
using Monaco.Internals.Logging;
using Monaco.Internals.Logging.Impl;
using Monaco.Internals.Reflection;
using Monaco.Internals.Serialization;
using Monaco.Pipeline.Impl.Pipelines.Default;
using Monaco.Services;
using Monaco.Services.Impl;
using Monaco.Transport.Bootstrapper;
using Monaco.Transport.Virtual;

namespace Monaco.Configuration
{
    public class MonacoFacility : AbstractFacility
    {
        public const string FACILITY_ID = "monaco";
        private object[] _elementBuilders = { };

        protected override void Init()
        {
            #region -- register all of the default components --

            Kernel.Register(Component.For<DefaultPipeline>()
                .ImplementedBy<DefaultPipeline>()
                .LifeStyle.Transient);

            Kernel.Register(Component.For<DefaultService>()
                .ImplementedBy<DefaultService>()
                .LifeStyle.Transient);

            Kernel.Register(Component.For<IEndpointBuilderSubscriptionRepository>()
                 .ImplementedBy<LocalEndpointBuilderSubscriptionRepository>()
                 .LifeStyle.Transient);

            Kernel.Register(Component.For<IServiceConfiguration>()
                   .ImplementedBy<ServiceConfiguration>()
                   .LifeStyle.Transient);

            Kernel.Register(Component.For<IAgentRegistry>()
                .ImplementedBy<AgentRegistry>()
                .LifeStyle.Singleton);

            Kernel.Register(Component.For<IAgentManager>()
                .ImplementedBy<AgentManager>()
                .LifeStyle.Transient);

            Kernel.Register(Component.For<IEndpointAdapter>()
                .ImplementedBy<EndpointAdapter>()
                .LifeStyle.Transient);

            Kernel.Register(Component.For<IEndpointRegistry>()
                                .ImplementedBy<LocalEndpointRegistry>()
                                .LifeStyle.Singleton);

            Kernel.Register(Component.For<IServiceRepository>()
                               .ImplementedBy<ServiceRepository>()
                               .LifeStyle.Singleton);

            Kernel.Register(Component.For<ISerializationProvider>()
                                .ImplementedBy<SharpSerializationProvider>()
                                .LifeStyle.Transient);

            Kernel.Register(Component.For<IReflection>()
                                .ImplementedBy<DefaultReflection>());

            Kernel.Register(Component.For<IServiceBus>()
                                .ImplementedBy<ServiceBus>());

            Kernel.Register(Component.For<IDispatcher>()
                                .ImplementedBy<InternalDispatcher>());

            Kernel.Register(Component.For<IScheduler>()
                                .ImplementedBy<Scheduler>()
                                .LifeStyle.Singleton);

            Kernel.Register(Component.For<ILogger>()
                                .ImplementedBy<Log4NetLogger>()
                                .LifeStyle.Transient);
            #endregion

            // find all of the element builders for parsing the configuration file:
            _elementBuilders = Kernel.Resolve<IReflection>()
                .FindConcreteTypesImplementingInterfaceAndBuild(typeof(BaseElementBuilder),
                                                                GetType().Assembly);

            // need to register all messages before building the services!!!
            BuildInfrastructureVia<MessagesElementBuilder>();

            // boot all of the transports, internally and then externally:
            RegisterAllTransports();

            // boot all of the definitions for storing data related to the message bus(es):
            RegisterAllStorageProviders();

            // register all of the message consumers:
            RegisterConsumers();

            // boot all of the profiles for the bus and corresponding services for message consumers:
            RunAllBusConfigurations(); 

            // configure the infrastructure:
            //BuildInfrastructureVia<EndpointBuildersElementBuilder>();
            BuildInfrastructureVia<ControlBusElementBuilder>();
            BuildInfrastructureVia<MessageBusElementBuilder>();
            BuildInfrastructureVia<EndpointsElementsBuilder>();
            BuildInfrastructureVia<MessagesElementBuilder>();
            //BuildInfrastructureVia<ServiceElementBuilder>();
            //BuildInfrastructureVia<TasksElementBuilder>();
            BuildInfrastructureVia<EndpointServiceManagerElementBuilder>();
            BuildInfrastructureVia<SubscriptionManagerElementBuilder>();

            // boot-up the internals for the bus:
            RunInternalBootstrappers();

            // configure all of the custom components via bootstrappers:
            RunExternalBootStrappers();
        }


        private void RegisterAllStorageProviders()
        {
            string[] files = Directory.GetFiles(Environment.CurrentDirectory, "*.dll");

            foreach (string file in files)
            {
                try
                {
                    Assembly asm = Assembly.LoadFile(file);

                    // skip the bootstrappers in the bus environment:
                    if (asm == this.GetType().Assembly) continue;

                    object[] items = Kernel.Resolve<IReflection>()
                        .FindConcreteTypesImplementingInterfaceAndBuild(typeof(BaseBusStorageProviderBootstrapper), asm);

                    if (items.Length == 0) continue;

                    foreach (object item in items)
                    {
                        var bootstrapper = item as BaseBootstrapper;
                        ExecuteBootstrapper(bootstrapper);
                    }
                }
                catch (Exception e)
                {
                }
            }
        }

        private void RunAllBusConfigurations()
        {
            string[] files = Directory.GetFiles(Environment.CurrentDirectory, "*.dll");

            foreach (string file in files)
            {
                try
                {
                    Assembly asm = Assembly.LoadFile(file);

                    // skip the bootstrappers in the bus environment:
                    if (asm == this.GetType().Assembly) continue;

                    List<object> configurations = new List<object>();

                    object[] items = Kernel.Resolve<IReflection>()
                        .FindConcreteTypesImplementingInterfaceAndBuild(typeof(BaseBusEnvironmentBootstrapper), asm);

                   // configurations.AddRange(items);

                   //items = Kernel.Resolve<IReflection>()
                   //     .FindConcreteTypesImplementingInterfaceAndBuild(typeof(BaseServerServiceProfileConfiguration), asm);

                   configurations.AddRange(items);

                    if (configurations.Count == 0) continue;

                    foreach (object item in configurations)
                    {
                        var bootstrapper = item as BaseBootstrapper;
                        ExecuteBootstrapper(bootstrapper);
                    }
                }
                catch (Exception e)
                {
                }
            }
        }

        private void RegisterConsumers()
        {
            string[] files = Directory.GetFiles(Environment.CurrentDirectory, "*.dll");

            foreach (string file in files)
            {
                try
                {
                    Assembly asm = Assembly.LoadFile(file);

                    Kernel.Register(AllTypes.FromAssembly(asm)
                                        .Where(
                                        x =>
                                        x.IsClass == true && x.IsAbstract == false &&
                                        typeof(IConsumer).IsAssignableFrom(x)));
                }
                catch
                {
                    continue;
                }
            }
        }

        private void RegisterAllTransports()
        {
            // forcibly boot the internal in-memory transport:
            Kernel.Resolve<IEndpointBuilderSubscriptionRepository>()
                .Add(new VirtualEndpointBuilder().CreateSubscription());

            // boot all external transport implementations:
            string[] files = Directory.GetFiles(Environment.CurrentDirectory, "*.dll");

            foreach (string file in files)
            {
                try
                {
                    Assembly asm = Assembly.LoadFile(file);

                    // skip the bootstrappers in the bus environment:
                    if (asm == this.GetType().Assembly) continue;

                    object[] items = Kernel.Resolve<IReflection>()
                        .FindConcreteTypesImplementingInterfaceAndBuild(typeof(BaseTransportBootstrapper), asm);

                    if (items.Length == 0) continue;

                    foreach (object item in items)
                    {
                        var bootstrapper = item as BaseBootstrapper;
                        ExecuteBootstrapper(bootstrapper);
                    }
                }
                catch (Exception e)
                {
                }
            }
        }

        private void RunExternalBootStrappers()
        {
            string[] files = Directory.GetFiles(Environment.CurrentDirectory, "*.dll");

            foreach (string file in files)
            {
                try
                {
                    Assembly asm = Assembly.LoadFile(file);

                    // skip the bootstrappers in the bus environment:
                    if (asm == this.GetType().Assembly) continue;

                    object[] items = Kernel.Resolve<IReflection>()
                        .FindConcreteTypesImplementingInterfaceAndBuild(typeof(BaseBusCustomExternalBootstrapper), asm);  //BaseBootstrapper

                    if (items.Length == 0) continue;

                    foreach (object item in items)
                    {
                        var bootstrapper = item as BaseBootstrapper;
                        ExecuteBootstrapper(bootstrapper);
                    }
                }
                catch (Exception e)
                {
                }
            }
        }

        private void RunInternalBootstrappers()
        {
            object[] items = Kernel.Resolve<IReflection>()
                .FindConcreteTypesImplementingInterfaceAndBuild(typeof(BaseBusCustomInternalBootstrapper),
                                                                this.GetType().Assembly);

            if (items.Length == 0) return;

            foreach (object item in items)
            {
                try
                {
                    var bootstrapper = item as BaseBootstrapper;
                    ExecuteBootstrapper(bootstrapper);
                }
                catch
                {
                    continue;
                }
            }

        }

        private void BuildInfrastructureVia<TElementBuilder>() where TElementBuilder : BaseElementBuilder
        {
            var builder = (from b in _elementBuilders
                           where b.GetType() == typeof(TElementBuilder)
                           select b).FirstOrDefault() as BaseElementBuilder;

            for (int index = 0; index < FacilityConfig.Children.Count; index++)
            {
                IConfiguration element = FacilityConfig.Children[index];

                if (element == null)
                    continue;

                if (builder.IsMatchFor(element.Name))
                {
                    builder.Kernel = Kernel;
                    builder.Build(element);
                    break;
                }
            }
        }

        private void ExecuteBootstrapper(BaseBootstrapper bootstrapper)
        {
            try
            {
                if (bootstrapper.IsActive == false) return;
                bootstrapper.Kernel = Kernel;
                bootstrapper.Configure();
            }
            catch (Exception e)
            {
                ILogger logger = Kernel.Resolve<ILogger>();

                if (logger != null)
                {
                    string msg = string.Format("The following boot-strapper '{0}' failed to execute. Reason: {1}",
                                               bootstrapper.GetType().Name, e.Message);
                    logger.LogWarnMessage(msg, e);
                }
            }
        }
    }
}