using Castle.MicroKernel;

namespace Monaco.Configuration.Bootstrapper
{
    /// <summary>
    /// Base class for extending the configuration of the framework via custom components.
    /// </summary>
    public abstract class BaseBootstrapper
    {
        /// <summary>
        /// Gets or sets the flag to indicate whether or not the current 
        /// configuration bootstrapper instance is active for registering
        /// or configuring the environment according to user preferences
        /// (default : IsActive = true)
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the instance of the current component registration kernel.
        /// </summary>
        public IKernel Kernel { get; set; }

        public string WorkingDirectory { get; set; }

        protected BaseBootstrapper()
        {
            IsActive = true;
        }

        /// <summary>
        /// This will be called and user-defined preferences can be configured here.
        /// </summary>
        public abstract void Configure();
    }
}