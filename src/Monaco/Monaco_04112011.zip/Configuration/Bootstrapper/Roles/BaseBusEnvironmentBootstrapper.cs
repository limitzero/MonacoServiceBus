using System;
using Castle.MicroKernel.Registration;
using Monaco.Agents.Timeout;
using Monaco.Agents.Timeout.Impl;
using Monaco.Configuration.Bootstrapper.Impl;
using Monaco.Configuration.Service;
using Monaco.Internals;
using Monaco.Sagas;
using Monaco.Sagas.Impl;
using Monaco.Services;
using Monaco.Services.Impl;
using Monaco.Subscriptions;
using Monaco.Subscriptions.Impl;

namespace Monaco.Configuration.Bootstrapper.Roles
{
    /// <summary>
    /// This is the client  profile for a message bus configuration. It will 
    /// configure the services and consumers in the message bus and also
    /// purge the underlying endpoint contents when started. This configuration 
    /// is not meant to have messages survive restarts of the message bus.
    /// </summary>
    /// <example>
    /// <![CDATA[
    /// public class MyLocalBusEnvironment : BaseBusEnvironmentBootstrapper
    /// {
    ///    public override void SetProfile(ProfileOptions profile)
    ///    {
    ///        profile = ProfileOptions.AsClient;
    ///    }
    ///    
    ///    public override void ConfigureServices()
    ///    {
    ///          IServiceConfiguration configuration = this.GetServiceConfiguration();
    /// 
    ///           // the pipeline that will be used is the standard serialization/de-serialization pipeline
    ///           configuration.Name = "my first service";
    ///           configuration.Endpoint.Uri = "msmq://localhost/service1";
    ///           configuration.Endpoint.Concurrency = 1;
    ///           configuration.Endpoint.MaxRetries = 2;
    ///           configuration.Endpoint.StatusInterval = "00:00:02";
    ///           configuration.Endpoint.StatusIntervalGracePeriod = "00:00:10";
    ///           configuration.RegisterConsumer(typeof(MyFirstMessageConsumer));
    ///
    ///            // use default serialization filter for msmq messages:
    ///           configuration.RegisterPipeline<SerializationPipeline>();
    ///          
    ///           // make sure to register the configuration:
    ///           base.RegisterServiceConfiguration(configuration);
    /// 
    ///           // more services can be defined here....
    ///    } 
    /// }
    /// ]]>
    /// </example>
    public abstract class BaseBusEnvironmentBootstrapper : BaseBootstrapper
    {
        /// <summary>
        /// Gets or sets the <seealso cref="ProfileOptions">profile</seealso>
        /// of the message bus for the current message bus environment.
        /// </summary>
        protected ProfileOptions Profile { get; private set; }

        public override void Configure()
        {
            this.BootEnvironmentStorage();
            this.SetProfile(this.Profile);
            this.ConfigureServices();
        }

        /// <summary>
        /// This will set the current profile option for the message 
        /// bus and configure supporting services and components
        /// accordingly. 
        /// </summary>
        /// <param name="profile"></param>
        public abstract void SetProfile(ProfileOptions profile);

        /// <summary>
        /// This will provide a method for the local services for the message
        /// bus instance to be created via configuration and registered for implementation.
        /// </summary>
        public abstract void ConfigureServices(); 

        /// <summary>
        /// This will instantiate a new instance of a service configuration for configuring 
        /// a message bus service and subsequently registering the instance.
        /// </summary>
        /// <returns></returns>
        protected IServiceConfiguration GetServiceConfiguration()
        {
            IServiceConfiguration configuration = Kernel.Resolve<IServiceConfiguration>();
            return configuration;
        }

        /// <summary>
        /// This will regsiter the service in the local message bus service registry
        /// for use on handling messages when they are received or delivered to/from 
        /// an endpoint location with the corresponding message handling pipeline 
        /// for transformation(s).
        /// </summary>
        /// <param name="configuration"></param>
        protected void RegisterService(IServiceConfiguration configuration)
        {
            if (configuration != null)
            {
                BaseService service = configuration.Create();

                if (service != null)
                {
                    IServiceRepository repository = Kernel.Resolve<IServiceRepository>();

                    if (repository != null)
                    {
                        if (this.Profile == ProfileOptions.AsClient)
                        {
                            service.Endpoint.Transport.IsRecoverable = false;
                        }
                        else
                        {
                            service.Endpoint.Transport.IsRecoverable = true;
                        }

                        repository.Register(service);
                    }
                }
            }
        }

        /// <summary>
        /// This will set the current configuration for the environment storage.
        /// </summary>
        private void BootEnvironmentStorage()
        {
            // use local in-memory implementations (if the global storage has not already been configured):

            try
            {
                var repository = Kernel.Resolve<ITimeoutsRepository>(Constants.TIMEOUTS_REPOSITORY_CONTAINER_KEY);
            }
            catch
            {
                Kernel.Register(Component.For<ITimeoutsRepository>()
                                    .ImplementedBy<LocalTimeoutsRepository>()
                                    .Named(Constants.TIMEOUTS_REPOSITORY_CONTAINER_KEY));
            }

            try
            {
                var repository = Kernel.Resolve<ISubscriptionRepository>(Constants.SUBSCRIPTION_REPOSITORY_CONTAINER_KEY);
            }
            catch
            {
                Kernel.Register(Component.For<ISubscriptionRepository>()
                                    .ImplementedBy<LocalSubscriptionRepository>()
                                    .Named(Constants.SUBSCRIPTION_REPOSITORY_CONTAINER_KEY));
            }

            try
            {
                var repository = Kernel.Resolve<ISagaRepository>(Constants.SAGA_REPOSITORY_CONTAINER_KEY);
            }
            catch
            {
                Kernel.Register(Component.For<ISagaRepository>()
                                    .ImplementedBy<LocalSagaRepository>()
                                    .Named(Constants.SAGA_REPOSITORY_CONTAINER_KEY));
            }

            try
            {
                Type theType = typeof(ISagaDataRepository<>).MakeGenericType(typeof(BootStrapSagaData));
                var theDataFinder = Kernel.Resolve(theType);
            }
            catch
            {
                Kernel.AddComponent(Constants.SAGA_DATA_REPOSITORY_CONTAINER_KEY,
                                    typeof(ISagaDataRepository<>),
                                    typeof(LocalSagaDataFinder<>));
            }
        }

    }
}