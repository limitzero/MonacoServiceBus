using System;
using Castle.Core;
using Castle.MicroKernel.Registration;
using Monaco.Agents.Timeout;
using Monaco.Agents.Timeout.Impl;
using Monaco.Configuration.Bootstrapper.Impl;
using Monaco.Configuration.Service;
using Monaco.Internals;
using Monaco.Sagas;
using Monaco.Sagas.Impl;
using Monaco.Services;
using Monaco.Services.Impl;
using Monaco.Subscriptions;
using Monaco.Subscriptions.Impl;

namespace Monaco.Configuration.Bootstrapper.Roles
{
    /// <summary>
    /// This is the client  profile for a message bus configuration. It will 
    /// configure the services and consumers in the message bus and also
    /// purge the underlying endpoint contents when started. This configuration 
    /// is not meant to have messages survive restarts of the message bus.
    /// </summary>
    /// <example>
    /// <![CDATA[
    /// public class MyClientBusConfiguration : BaseClientBusConfiguration
    /// {
    ///    public override void ConfigureBus()
    ///    {
    ///          IServiceConfiguration configuration = this.GetServiceConfiguration();
    /// 
    ///           // the pipeline that will be used is the standard serialization/de-serialization pipeline
    ///           configuration.Name = "my first service";
    ///           configuration.Endpoint.Uri = "msmq://localhost/service1";
    ///           configuration.Endpoint.Concurrency = 1;
    ///           configuration.Endpoint.MaxRetries = 2;
    ///           configuration.Endpoint.StatusInterval = "00:00:02";
    ///           configuration.Endpoint.StatusIntervalGracePeriod = "00:00:10";
    ///           configuration.RegisterConsumer(typeof(MyFirstMessageConsumer));
   ///
   ///            // use default serialization filter for msmq messages:
    ///           configuration.RegisterPipeline<SerializationPipeline>();
    ///          
    ///           base.RegisterServiceConfiguration(configuration);
    /// 
    ///           // more services can be defined here....
    ///    } 
    /// }
    /// ]]>
    /// </example>
    public abstract class BaseClientBusEnvironmentBootStrapper : BaseBootstrapper
    {
        public override void Configure()
        {
            this.ConfigureStorage();
            this.ConfigureBus();
        }

        public abstract void ConfigureBus();
        
        public IServiceConfiguration GetServiceConfiguration()
        {
            IServiceConfiguration configuration = Kernel.Resolve<IServiceConfiguration>();
            return configuration;
        }

        public void RegisterServiceFromConfiguration(IServiceConfiguration configuration)
        {
            BaseService service = configuration.Create();

            if (service != null)
            {
                IServiceRepository repository = Kernel.Resolve<IServiceRepository>();

                if (repository != null)
                {
                    // force the endpoint to not persist messages:
                    service.Endpoint.Transport.IsRecoverable = false;
                    repository.Register(service);
                }
            }
        }

        private void ConfigureStorage()
        {
            // use local in-memory implementations (if the global storage has not already been configured):

            try
            {
                var repository = Kernel.Resolve<ITimeoutsRepository>(Constants.TIMEOUTS_REPOSITORY_CONTAINER_KEY);
            }
            catch
            {
                Kernel.Register(Component.For<ITimeoutsRepository>()
                                    .ImplementedBy<LocalTimeoutsRepository>()
                                    .Named(Constants.TIMEOUTS_REPOSITORY_CONTAINER_KEY)
                                    .LifeStyle.Singleton);                
            }

            try
            {
                var repository = Kernel.Resolve<ISubscriptionRepository>(Constants.SUBSCRIPTION_REPOSITORY_CONTAINER_KEY);
            }
            catch 
            {
                Kernel.Register(Component.For<ISubscriptionRepository>()
                            .ImplementedBy<LocalSubscriptionRepository>()
                            .Named(Constants.SUBSCRIPTION_REPOSITORY_CONTAINER_KEY)
                            .LifeStyle.Singleton);
            }

            try
            {
                var repository = Kernel.Resolve<ISagaRepository>(Constants.SAGA_REPOSITORY_CONTAINER_KEY);
            }
            catch 
            {
                Kernel.Register(Component.For<ISagaRepository>()
                                      .ImplementedBy<LocalSagaRepository>()
                                      .Named(Constants.SAGA_REPOSITORY_CONTAINER_KEY)
                                      .LifeStyle.Singleton);  
            }


            try
            {
                Type theType = typeof(ISagaDataRepository<>).MakeGenericType(typeof(BootStrapSagaData));
                var theDataFinder = Kernel.Resolve(theType);
            }
            catch
            {
                Kernel.AddComponent(Constants.SAGA_DATA_REPOSITORY_CONTAINER_KEY,
                    typeof(ISagaDataRepository<>),
                    typeof(LocalSagaDataFinder<>), 
                    LifestyleType.Singleton);
            }
        }
    }
}