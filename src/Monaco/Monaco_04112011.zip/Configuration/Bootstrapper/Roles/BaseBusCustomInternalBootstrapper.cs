namespace Monaco.Configuration.Bootstrapper.Roles
{
    /// <summary>
    /// Base class for configuring internal dependencies for needed run-time dependencies.
    /// </summary>
    public abstract class BaseBusCustomInternalBootstrapper : BaseBootstrapper
    {
    }
}