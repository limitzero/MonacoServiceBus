namespace Monaco.Configuration.Bootstrapper.Roles
{
    /// <summary>
    /// Enumeration for the profile options that can be assigned to a message bus implementation.
    /// </summary>
    public enum ProfileOptions
    {
        /// <summary>
        /// This is the client  profile for a message bus configuration. It will 
        /// configure the services and consumers in the message bus and also
        /// purge the underlying endpoint contents when started. This configuration 
        /// is not meant to have messages survive restarts of the message bus.
        /// </summary>
        AsClient,

        /// <summary>
        /// This is the server profile for a message bus configuration. It will 
        /// configure the services and consumers in the message bus and also
        /// not purge the underlying endpoint contents when started. This configuration 
        /// is meant to have messages survive restarts of the message bus.
        /// </summary>
        AsServer,

        /// <summary>
        /// This is the console profile for a message bus configuration. It will 
        /// configure the services and consumers in the message bus and also
        /// not purge the underlying endpoint contents when started. This configuration 
        /// is meant to have messages survive restarts of the message bus and also 
        /// be the sole provider of globally used data, alerting and control for other 
        /// bus instances.
        /// </summary>
        AsConsole,
    }
}