using Castle.MicroKernel.Registration;
using Monaco.Configuration.Bootstrapper.Roles;
using Monaco.Internals;

namespace Monaco.Configuration.Bootstrapper.Impl
{
    public class LocalBusMessageConsumersBootstrapper : BaseBusCustomInternalBootstrapper
    {
        public override void Configure()
        {
            Kernel.Register(AllTypes.FromAssembly(this.GetType().Assembly)
                                            .BasedOn<IConsumer>());
        }
    }

}