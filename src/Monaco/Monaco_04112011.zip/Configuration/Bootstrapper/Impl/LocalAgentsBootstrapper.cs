﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Castle.MicroKernel.Registration;
using Monaco.Configuration.Bootstrapper.Roles;
using Monaco.Internals.Agent;

namespace Monaco.Configuration.Bootstrapper.Impl
{
    public class LocalAgentsBootstrapper : BaseBusCustomInternalBootstrapper
    {
        public override void Configure()
        {
            string[] files = Directory.GetFiles(Environment.CurrentDirectory, "*.dll");

            foreach (string file in files)
            {
                try
                {
                    Assembly asm = Assembly.LoadFile(file);

                    Kernel.Register(AllTypes.FromAssembly(asm)
                                            .BasedOn<BaseAgent>());
                }
                catch
                {
                    continue;
                }

            }

            try
            {
                ICollection<BaseAgent> agents = Kernel.ResolveAll<BaseAgent>();
                IAgentRegistry registry = Kernel.Resolve<IAgentRegistry>();

                foreach (BaseAgent agent in agents)
                {
                    registry.Register(agent);
                }
            }
            catch
            {
            }
        }
    }
}
