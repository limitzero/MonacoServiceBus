﻿using System;
using Monaco.Configuration.Bootstrapper.Roles;
using Monaco.Sagas;
using Monaco.Sagas.Impl;

namespace Monaco.Configuration.Bootstrapper.Impl
{
    public class LocalSagaDataRepositoryBootstrapper : BaseBusCustomInternalBootstrapper
	{
        public LocalSagaDataRepositoryBootstrapper()
        {
            // TODO: make this active again for saga persistance
            // this.IsActive = false;
        }

        public override void Configure()
        {
            try
            {
                Type theType = typeof (ISagaDataRepository<>).MakeGenericType(typeof (BootStrapSagaData));
                var theDataFinder = Kernel.Resolve(theType);
            }
            catch 
            {
                Kernel.AddComponent("saga.data.repository", 
                    typeof(ISagaDataRepository<>), 
                    typeof(LocalSagaDataFinder<>));
            }
        }
	}

    public class BootStrapSagaData : ISagaData
    {
        public Guid CorrelationId { get; set;}
    }
}
