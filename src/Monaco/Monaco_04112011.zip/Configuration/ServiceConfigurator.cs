﻿using System;
using System.Linq;
using System.Reflection;
using Castle.MicroKernel;
using Monaco.Configuration.Service;
using Monaco.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Internals;
using Monaco.Pipeline;
using Monaco.Pipeline.Impl.Pipelines.Default;

namespace Monaco.Configuration
{
    public class ServiceConfigurator
    {
        private readonly IKernel _kernel;
        public IServiceConfiguration Configuration { get; private set; }

        public BaseEndpoint Endpoint { get; private set; }

        public ServiceConfigurator(IKernel kernel)
        {
            _kernel = kernel;
            Configuration = new ServiceConfiguration(kernel);
        }

        /// <summary>
        /// This will set the name of the logical service.
        /// </summary>
        /// <param name="named"></param>
        /// <returns></returns>
        public ServiceConfigurator Named(string named)
        {
            Configuration.Name = named;
            return this;
        }

        /// <summary>
        /// This will configure the endpoint characteristics associated with the logical service,
        /// </summary>
        /// <param name="configurator"></param>
        /// <returns></returns>
        public ServiceConfigurator WithEndpoint(EndpointConfigurator configurator)
        {
            this.Configuration.Endpoint = configurator.Configuration;
            return this;
        }

        /// <summary>
        /// This will configure the service instance with the named endpoint 
        /// in the configuration file.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public ServiceConfigurator WithEndpointName(string name)
        {
            // find the endpoint with the name and store it for service creation:
            BaseEndpoint anEndpoint = _kernel.Resolve<IEndpointRegistry>().Find(name);

            if (anEndpoint == null)
                throw new ArgumentException(string.Format("There was not an externally defined endpoint with name \'{0}\"",
                                                      name));

            this.Endpoint = anEndpoint;

            return this;
        }

        /// <summary>
        /// This will associate a series of message consumers to a logical service instance.
        /// </summary>
        /// <param name="consumers"></param>
        /// <returns></returns>
        public ServiceConfigurator HavingConsumersOf(params Type[] consumers)
        {
            foreach (Type consumer in consumers)
            {
                Configuration.RegisterConsumer(consumer);
            }

            return this;
        }

        /// <summary>
        /// This will associate a series of message consumers in an assembly to a logical service instance.
        /// </summary>
        /// <param name="assembly"></param>
        /// <returns></returns>
        public ServiceConfigurator HavingConsumersInAssembly(Assembly assembly)
        {
            var consumers = (from type in assembly.GetTypes()
                             where typeof (IConsumer).IsAssignableFrom(type)
                             select type).Distinct().ToList();

            foreach (Type consumer in consumers)
            {
                Configuration.RegisterConsumer(consumer);
            }

            return this;
        }

        /// <summary>
        /// This will configure the service with an empty pipeline configuration
        /// </summary>
        /// <returns></returns>
        public ServiceConfigurator WithADefaultPipeline()
        {
            var pipeline = _kernel.Resolve<DefaultPipeline>();
            return this;
        }

        /// <summary>
        /// This will configure the service with an empty pipeline configuration
        /// </summary>
        /// <param name="name">Name of the pipeline</param>
        /// <returns></returns>
        public ServiceConfigurator WithADefaultPipelineNamed(string name)
        {
            var pipeline = _kernel.Resolve<DefaultPipeline>();

            if(string.IsNullOrEmpty(name))
            {
                name = "DEFAULT-PIPELINE:" + Guid.NewGuid().ToString();
            }

            pipeline.Name = name;

            this.Configuration.RegisterPipeline(pipeline);

            return this;
        }
        /// <summary>
        /// This will associate a custom message processing pipeline to the service instance
        /// for handling the messages as they arrive from the transport and as they are sent 
        /// to the transport.
        /// </summary>
        /// <typeparam name="TPIPELINE"></typeparam>
        /// <returns></returns>
        public ServiceConfigurator HavingPipeline<TPIPELINE>() where TPIPELINE : BasePipeline, new()
        {
            Configuration.RegisterPipeline<TPIPELINE>();
            return this;
        }

        /// <summary>
        /// This will associate a series of receive filters to a base pipeline implementation.
        /// </summary>
        /// <param name="filters"></param>
        /// <returns></returns>
        public ServiceConfigurator HavingReceiveFiltersOf(params IPipelineFilter[] filters)
        {
           if(this.Configuration.Pipeline == null)
               throw new ArgumentException("The pipeline must first be defined before any receive filters can be added.");

            this.Configuration.Pipeline.RegisterReceiveFilters(filters);

            return this;
        }

        /// <summary>
        /// This will associate a series of send filters to a base pipeline implementation.
        /// </summary>
        /// <param name="filters"></param>
        /// <returns></returns>
        public ServiceConfigurator HavingSendFiltersOf(params IPipelineFilter[] filters)
        {
            if (this.Configuration.Pipeline == null)
                throw new ArgumentException("The pipeline must first be defined before any send filters can be added.");

            this.Configuration.Pipeline.RegisterReceiveFilters(filters);

            return this;
        }
    }
}