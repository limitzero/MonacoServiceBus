namespace Monaco.Configuration
{
    /// <summary>
    /// Base class for implementing the configuration of the endpoint on the message bus.
    /// </summary>
    public class BaseEndpointConfiguration
    {
        
    }
}