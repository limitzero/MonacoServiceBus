using System;
using System.Collections.Generic;
using Monaco.Configuration.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Internals;
using Monaco.Pipeline;
using Monaco.Pipeline.Impl.Pipelines.Default;
using Monaco.Services.Impl;

namespace Monaco.Configuration.Service
{
    /// <summary>
    /// Contract for constructing a <seealso cref="BaseService">basic service definitiion</seealso>.
    /// </summary>
    public interface IServiceConfiguration
    {
        /// <summary>
        /// Gets or sets the name of the service.
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// Gets the series of message consumers tied to the 
        /// service instance for processing the message 
        /// received from the service endpoint and applying 
        /// any business related logic to the message.
        /// </summary>
        ICollection<IConsumer> Consumers { get; }

        /// <summary>
        /// Gets the message transformation pipeline 
        /// for handling the message as it is received 
        /// from the endpoint or being sent to the endpoint.
        /// </summary>
        BasePipeline Pipeline { get; }

        /// <summary>
        /// Gets or sets the current configuration of the endpoint for the service.
        /// </summary>
        IEndpointConfiguration Endpoint { get; set; }

        /// <summary>
        /// This will register the mesasge handling pipeline 
        /// for the service when a series of message transformations
        /// is needed to handle the message as it is received from 
        /// the endpoint and sending the message to the endpoint 
        /// for the service. The constructed pipeline will automatically
        /// halt processing on any error encountered.
        /// </summary>
        /// <typeparam name="TPIPELINE">Concrete instance of the pipeline for handling the messages.</typeparam>
        void RegisterPipeline<TPIPELINE>() where TPIPELINE : BasePipeline, new();

        /// <summary>
        /// This will register the mesasge handling pipeline 
        /// for the service when a series of message transformations
        /// is needed to handle the message as it is received from 
        /// the endpoint and sending the message to the endpoint 
        /// for the service. The constructed pipeline will automatically
        /// halt processing on any error encountered.
        /// </summary>
        /// <param name="name">The name of the pipeline</param>
        /// <param name="receiveFilters">The collection of filters to run in sequence when a message is received from an endpoint</param>
        /// <param name="sendFilters">The collectoin of filters to run in sequence when a message is delivered to an endpoint</param>
        void RegisterPipeline(string name, IEnumerable<BasePipelineFilter> receiveFilters,
                              IEnumerable<BasePipelineFilter> sendFilters);

        /// <summary>
        /// This will register a pipeline implementation.
        /// </summary>
        /// <param name="pipeline"></param>
        void RegisterPipeline(BasePipeline pipeline);

        /// <summary>
        /// This will register a message consumer on the service for 
        /// handling the message in the transformed format as it 
        /// relates to any business related processing logic.
        /// </summary>
        /// <typeparam name="TCONSUMER">Type of the message consumer</typeparam>
        void RegisterConsumer<TCONSUMER>() where TCONSUMER : IConsumer;

        /// <summary>
        /// This will register a message consumer on the service for 
        /// handling the message in the transformed format as it 
        /// relates to any business related processing logic.
        /// </summary>
        /// <param name="consumer">The type that will conduct business logic on the transformed message. Must be derivable from <seealso cref="IConsumer"/></param>
        void RegisterConsumer(Type consumer);

        /// <summary>
        /// This will create a service implementation based on the current configuration parameters.
        /// </summary>
        /// <returns></returns>
        BaseService Create();

        /// <summary>
        /// This will create a service implementation based on the current configuration 
        /// and use the existing endpoint implementation.
        /// </summary>
        /// <returns></returns>
        BaseService Create(BaseEndpoint endpoint);

    }
}