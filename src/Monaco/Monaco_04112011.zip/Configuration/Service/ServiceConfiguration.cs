using System;
using System.Collections.Generic;
using Castle.MicroKernel;
using Monaco.Configuration.Endpoint;
using Monaco.Endpoint.Impl;
using Monaco.Internals;
using Monaco.Pipeline;
using Monaco.Pipeline.Impl.Pipelines.Default;
using Monaco.Pipeline.Impl.Pipelines.Serialization;
using Monaco.Services.Impl;

namespace Monaco.Configuration.Service
{
    /// <summary>
    /// Concrete implementation of a configuration for a service.
    /// </summary>
    public class ServiceConfiguration : IServiceConfiguration
    {
        private readonly IKernel _kernel;
        public string Name { get; set; }
        public ICollection<IConsumer> Consumers { get; private set; }
        
        public BasePipeline Pipeline { get; private set; }

        public IEndpointConfiguration Endpoint { get; set; }

        public ServiceConfiguration(IKernel kernel)
        {
            _kernel = kernel;
            this.Name = string.Format("SERVICE<{0}>", Guid.NewGuid().ToString());
            this.Endpoint = new EndpointConfiguration();
            this.Consumers = new List<IConsumer>();
        }

        public void RegisterPipeline<TPIPELINE>() where TPIPELINE :BasePipeline, new()
        {
            this.Pipeline = new TPIPELINE();
        }

        public void RegisterPipeline(string name, IEnumerable<BasePipelineFilter> receiveFilters,  IEnumerable<BasePipelineFilter> sendFilters)
        {
            this.Pipeline = _kernel.Resolve<DefaultPipeline>();

            this.Pipeline.Name = name;
            this.Pipeline.HaltOnError = true;

            if(receiveFilters == null && sendFilters == null)
            {
                throw new Exception(string.Format("The pipeline '<{0}>' can not be constructed without any receive or send filters.", name));
            }

            if (receiveFilters != null)
            {
                this.Pipeline.RegisterReceiveFilters(new List<BasePipelineFilter>(receiveFilters).ToArray());
            }

            if (sendFilters != null)
            {
                this.Pipeline.RegisterSendFilters(new List<BasePipelineFilter>(sendFilters).ToArray());
            }
        }

        public void RegisterPipeline(BasePipeline pipeline)
        {
            this.Pipeline = pipeline;
        }

        public void RegisterConsumer<TCONSUMER>() where TCONSUMER : IConsumer
        {
            this.RegisterConsumer(typeof(TCONSUMER));
        }

        public void RegisterConsumer(Type consumer)
        {
            object theConsumer = _kernel.Resolve(consumer);
            IConsumer aConsumer = theConsumer as IConsumer;

            if(typeof(IConsumer).IsAssignableFrom(consumer))
            {
                if(!this.Consumers.Contains(aConsumer))
                {
                    this.Consumers.Add(aConsumer);
                }
            }
        }

        public BaseService Create()
        {
            DefaultService service = _kernel.Resolve<DefaultService>();

            if (this.Pipeline == null)
            {
                this.Pipeline = new SerializationPipeline();
            }

            service.Name = this.Name;
            service.RegisterEndpoint(this.Endpoint);
            service.RegisterPipeline(this.Pipeline);

            foreach (IConsumer consumer in this.Consumers)
            {
                service.RegisterHandler(consumer.GetType());
            }

            return service;
        }

        public BaseService Create(BaseEndpoint endpoint)
        {
            DefaultService service = _kernel.Resolve<DefaultService>();

            if (this.Pipeline == null)
            {
                this.Pipeline = new SerializationPipeline();
            }

            service.Name = this.Name;
            service.RegisterEndpoint(endpoint);

            service.RegisterPipeline(this.Pipeline);

            foreach (IConsumer consumer in this.Consumers)
            {
                service.RegisterHandler(consumer.GetType());
            }

            return service;
        }
    }
}